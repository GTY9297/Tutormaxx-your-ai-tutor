import React, { useState } from 'react';
import { FAQS } from '../data';
import { ChevronDown, MessageSquare, HelpCircle } from 'lucide-react';

interface FAQProps {
  onOpenChat: (initialPrompt?: string) => void;
}

export const FAQ: React.FC<FAQProps> = ({ onOpenChat }) => {
  const [openId, setOpenId] = useState<string | null>('faq-1');

  const toggle = (id: string) => {
    setOpenId(openId === id ? null : id);
  };

  return (
    <section id="faq" className="py-20 bg-slate-950 text-slate-100 border-b border-slate-800/80">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-12">
        <div className="text-center mb-16">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full border border-indigo-500/30 bg-indigo-500/10 text-indigo-300 text-xs font-mono uppercase tracking-widest mb-3">
            <HelpCircle className="w-3.5 h-3.5 text-indigo-400" />
            <span>Knowledge Base</span>
          </div>
          <h2 className="text-3xl sm:text-5xl font-extrabold text-white tracking-tight">
            Frequently Asked Questions
          </h2>
          <p className="mt-4 text-xs sm:text-sm text-slate-400 leading-relaxed">
            Click any entry to expand or ask the AI assistant for personalized answers.
          </p>
        </div>

        <div className="space-y-4">
          {FAQS.map((faq) => {
            const isOpen = openId === faq.id;
            return (
              <div key={faq.id} className="rounded-2xl border border-slate-800 bg-slate-900/60 ai-glass-card overflow-hidden transition-all">
                <button
                  type="button"
                  onClick={() => toggle(faq.id)}
                  className="w-full p-6 text-left flex items-center justify-between gap-4 hover:bg-slate-800/40 transition-colors cursor-pointer"
                >
                  <span className="text-sm sm:text-base font-bold text-white">
                    {faq.question}
                  </span>
                  <div
                    className={`p-2 rounded-xl border border-slate-800 bg-slate-950 text-slate-300 shrink-0 transition-transform duration-200 ${
                      isOpen ? 'rotate-180 bg-indigo-600 text-white border-indigo-500' : ''
                    }`}
                  >
                    <ChevronDown className="w-4 h-4" />
                  </div>
                </button>

                {isOpen && (
                  <div className="px-6 pb-6 text-xs sm:text-sm leading-relaxed border-t border-slate-800/60 pt-4 text-slate-300">
                    <p>{faq.answer}</p>
                    <div className="mt-4">
                      <button
                        type="button"
                        onClick={() =>
                          onOpenChat(
                            `Can you elaborate more on this question: "${faq.question}"?`
                          )
                        }
                        className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold transition-all cursor-pointer shadow-md shadow-indigo-600/30"
                      >
                        <MessageSquare className="w-3.5 h-3.5" />
                        <span>Ask AI Assistant To Elaborate</span>
                      </button>
                    </div>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};


