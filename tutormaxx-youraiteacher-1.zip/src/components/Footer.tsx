import React from 'react';
import { Sparkles, Shield } from 'lucide-react';

interface FooterProps {
  onOpenChat: (initialPrompt?: string) => void;
}

export const Footer: React.FC<FooterProps> = ({ onOpenChat }) => {
  return (
    <footer className="bg-slate-950 text-slate-100 border-t border-slate-800 py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-12">
          {/* Brand Info */}
          <div className="md:col-span-2">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-indigo-500 to-purple-500 text-white flex items-center justify-center font-extrabold text-sm shadow-lg shadow-indigo-500/20">
                A
              </div>
              <span className="text-xl font-extrabold text-white tracking-tight">
                Aura<span className="text-indigo-400">AI</span>
              </span>
            </div>
            <p className="text-slate-400 max-w-md text-xs leading-relaxed font-mono">
              FULL-STACK AI WORKSTATION POWERED BY EXPRESS & GEMINI 3.6 FLASH. INCLUDES SERVER-SIDE PROXY & SITUATIONAL REASONING TOOLS.
            </p>
            <div className="mt-4">
              <button
                type="button"
                onClick={() => onOpenChat()}
                className="px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold transition-all cursor-pointer shadow-md shadow-indigo-600/30 flex items-center gap-2"
              >
                <Sparkles className="w-3.5 h-3.5" />
                <span>Launch AI Assistant</span>
              </button>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="text-indigo-400 text-xs font-mono uppercase tracking-widest mb-4">
              Navigation
            </h4>
            <ul className="space-y-2 text-xs font-medium text-slate-400">
              <li>
                <a href="#prompt-workspace" className="hover:text-white transition-colors">
                  Prompt Workstation
                </a>
              </li>
              <li>
                <a href="#why-aura" className="hover:text-white transition-colors text-indigo-400">
                  Why Aura AI
                </a>
              </li>
              <li>
                <a href="#features" className="hover:text-white transition-colors">
                  Features
                </a>
              </li>
              <li>
                <a href="#demo" className="hover:text-white transition-colors">
                  API Playground
                </a>
              </li>
              <li>
                <a href="#faq" className="hover:text-white transition-colors">
                  System FAQ
                </a>
              </li>
            </ul>
          </div>

          {/* Technology Stack */}
          <div>
            <h4 className="text-indigo-400 text-xs font-mono uppercase tracking-widest mb-4">
              Architecture
            </h4>
            <ul className="space-y-2 text-xs font-mono text-slate-400">
              <li>• @google/genai TypeScript SDK</li>
              <li>• Express API Proxy Backend</li>
              <li>• React 19 & Tailwind CSS</li>
              <li>• Dark Glassmorphic Studio Theme</li>
            </ul>
          </div>
        </div>

        <div className="pt-8 border-t border-slate-800/80 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs font-mono text-slate-500">
          <div>
            &copy; {new Date().getFullYear()} Aura AI Studio. Built with Google AI Studio.
          </div>
          <div className="flex items-center gap-2 text-indigo-400">
            <Shield className="w-3.5 h-3.5 text-indigo-400" />
            <span>Server-Side Secret Key Proxy</span>
          </div>
        </div>
      </div>
    </footer>
  );
};


