import React, { useState, useEffect, useRef } from 'react';
import { ChatMessage } from '../types';
import {
  X,
  Send,
  Bot,
  User,
  Trash2,
  Minimize2,
  Maximize2,
  Copy,
  Check,
  ArrowDown,
  Sparkles,
  GraduationCap,
  Lightbulb,
  Zap,
  ChevronDown,
  ChevronUp,
} from 'lucide-react';

interface FloatingChatWidgetProps {
  isOpen: boolean;
  onToggle: () => void;
  pendingPrompt?: string | null;
  onClearPendingPrompt?: () => void;
}

export const FloatingChatWidget: React.FC<FloatingChatWidgetProps> = ({
  isOpen,
  onToggle,
  pendingPrompt,
  onClearPendingPrompt,
}) => {
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 'welcome',
      role: 'assistant',
      content:
        'Hello. I am **Aura AI Copilot**, your floating assistant. Ask me anything about this platform, pricing, tech stack, or general coding questions.',
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    },
  ]);
  const [inputText, setInputText] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [isExpanded, setIsExpanded] = useState(false);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [showScrollBottom, setShowScrollBottom] = useState(false);
  const [unreadCount, setUnreadCount] = useState(0);
  const [isTeacherMode, setIsTeacherMode] = useState(false);
  const [isSimpleMode, setIsSimpleMode] = useState(false);
  const [expandedMsgIds, setExpandedMsgIds] = useState<Record<string, boolean>>({});

  const toggleMsgExpand = (id: string) => {
    setExpandedMsgIds((prev) => ({
      ...prev,
      [id]: !prev[id],
    }));
  };

  const handleShortenAnswer = (msgText: string) => {
    handleSendMessage(`[SHORTEN RESPONSE]\nSummarize this explanation in 3 concise bullet points under 50 words: "${msgText.slice(0, 800)}"`);
  };

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const chatContainerRef = useRef<HTMLDivElement>(null);

  const [position, setPosition] = useState<{ x: number; y: number } | null>(null);
  const [isDragging, setIsDragging] = useState(false);
  const dragRef = useRef<{ startX: number; startY: number; posX: number; posY: number }>({
    startX: 0,
    startY: 0,
    posX: 0,
    posY: 0,
  });

  const handleMouseDown = (e: React.MouseEvent) => {
    if ((e.target as HTMLElement).closest('button')) return;

    setIsDragging(true);
    const currentX = position ? position.x : 0;
    const currentY = position ? position.y : 0;

    dragRef.current = {
      startX: e.clientX,
      startY: e.clientY,
      posX: currentX,
      posY: currentY,
    };

    const handleMouseMove = (moveEvent: MouseEvent) => {
      const dx = moveEvent.clientX - dragRef.current.startX;
      const dy = moveEvent.clientY - dragRef.current.startY;
      setPosition({
        x: dragRef.current.posX + dx,
        y: dragRef.current.posY + dy,
      });
    };

    const handleMouseUp = () => {
      setIsDragging(false);
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('mouseup', handleMouseUp);
    };

    window.addEventListener('mousemove', handleMouseMove);
    window.addEventListener('mouseup', handleMouseUp);
  };

  const resetPosition = () => {
    setPosition(null);
  };

  const scrollToBottom = (smooth = true) => {
    messagesEndRef.current?.scrollIntoView({ behavior: smooth ? 'smooth' : 'auto' });
  };

  useEffect(() => {
    if (isOpen) {
      scrollToBottom();
      setUnreadCount(0);
    }
  }, [messages, isOpen]);

  useEffect(() => {
    if (pendingPrompt && pendingPrompt.trim()) {
      if (!isOpen) {
        onToggle();
      }
      handleSendMessage(pendingPrompt.trim());
      if (onClearPendingPrompt) {
        onClearPendingPrompt();
      }
    }
  }, [pendingPrompt]);

  const handleScroll = () => {
    if (!chatContainerRef.current) return;
    const { scrollTop, scrollHeight, clientHeight } = chatContainerRef.current;
    const isUp = scrollHeight - scrollTop - clientHeight > 100;
    setShowScrollBottom(isUp);
  };

  const handleSendMessage = async (textToSend?: string) => {
    const text = textToSend || inputText;
    if (!text || !text.trim() || isLoading) return;

    const userMessageText = text.trim();
    if (!textToSend) setInputText('');

    const userMsg: ChatMessage = {
      id: `usr_${Date.now()}`,
      role: 'user',
      content: userMessageText,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setMessages((prev) => [...prev, userMsg]);
    setIsLoading(true);

    try {
      const historyPayload = messages.map((m) => ({
        role: m.role,
        text: m.content,
      }));

      let activeSysInst: string | undefined = undefined;
      if (isSimpleMode) {
        activeSysInst = 'You are Tutormaxx in SIMPLE MODE (ELI5). Explain complex, tough questions simply in easy-to-understand plain English with a relatable everyday analogy, 3 simple steps with zero jargon, and 1 quick takeaway.';
      } else if (isTeacherMode) {
        activeSysInst = 'You are Tutormaxx in TEACHER MODE inside the floating copilot. Provide a brief, highly structured, 4-step teacher explanation for the provided topic or question (1. Core Summary, 2. Key Points, 3. Simple Example, 4. Quick Self-Check Question). Keep explanations brief, engaging, and easy to grasp.';
      }

      const response = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: userMessageText,
          history: historyPayload,
          systemInstruction: activeSysInst,
        }),
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || 'Failed to connect to backend AI server.');
      }

      const assistantMsg: ChatMessage = {
        id: `ast_${Date.now()}`,
        role: 'assistant',
        content: data.reply || 'I processed your request, but no text response was generated.',
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        isFallback: data.isFallback,
      };

      setMessages((prev) => [...prev, assistantMsg]);

      if (!isOpen) {
        setUnreadCount((c) => c + 1);
      }
    } catch (err: any) {
      console.error('Chat error:', err);
      const errorMsg: ChatMessage = {
        id: `err_${Date.now()}`,
        role: 'assistant',
        content: `⚠️ **Connection Notice**: ${
          err.message || 'Unable to reach backend /api/chat route.'
        }\n\nPlease check your backend server and \`GEMINI_API_KEY\` configuration.`,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        isError: true,
      };
      setMessages((prev) => [...prev, errorMsg]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  const copyToClipboard = (id: string, text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const clearChat = () => {
    setMessages([
      {
        id: 'welcome_reset',
        role: 'assistant',
        content: 'Chat history cleared. What else can I assist you with?',
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      },
    ]);
  };

  const quickTopics = [
    'Overview',
    'Express Backend',
    'Pricing',
    'Ask Anything',
  ];

  const handleChipClick = (topic: string) => {
    const promptMap: Record<string, string> = {
      Overview: 'What are the main capabilities of Aura AI?',
      'Express Backend': 'Explain how the Express backend proxies Gemini requests.',
      Pricing: 'Can you summarize the Starter vs Pro vs Enterprise pricing tiers?',
      'Ask Anything': 'Give me a quick 3-step guide on building full-stack web applications.',
    };
    handleSendMessage(promptMap[topic] || topic);
  };

  const renderFormattedContent = (content: string) => {
    const lines = content.split('\n');
    let inCodeBlock = false;
    let codeBuffer: string[] = [];
    const elements: React.ReactNode[] = [];

    lines.forEach((line, index) => {
      if (line.trim().startsWith('```')) {
        if (inCodeBlock) {
          elements.push(
            <pre
              key={`code_${index}`}
              className="my-2 p-3 bg-slate-950 text-indigo-300 border border-slate-800 rounded-xl font-mono text-[11px] overflow-x-auto whitespace-pre-wrap select-text"
            >
              <code>{codeBuffer.join('\n')}</code>
            </pre>
          );
          codeBuffer = [];
          inCodeBlock = false;
        } else {
          inCodeBlock = true;
        }
        return;
      }

      if (inCodeBlock) {
        codeBuffer.push(line);
        return;
      }

      const formattedLine = line.split(/(\*\*.*?\*\*|`.*?`)/g).map((part, pIdx) => {
        if (part.startsWith('**') && part.endsWith('**')) {
          return (
            <strong key={pIdx} className="font-extrabold text-white">
              {part.slice(2, -2)}
            </strong>
          );
        }
        if (part.startsWith('`') && part.endsWith('`')) {
          return (
            <code
              key={pIdx}
              className="px-1 py-0.5 border border-slate-800 rounded font-mono text-[11px] bg-slate-950 text-indigo-300"
            >
              {part.slice(1, -1)}
            </code>
          );
        }
        return part;
      });

      elements.push(
        <p key={index} className="min-h-[1.2rem] my-0.5 leading-relaxed text-slate-200">
          {formattedLine}
        </p>
      );
    });

    return elements;
  };

  return (
    <div className="fixed bottom-6 right-6 z-[9999] flex flex-col items-end pointer-events-none">
      {/* Floating Chat Window Overlay */}
      {isOpen && (
        <div
          style={
            position
              ? {
                  transform: `translate(${position.x}px, ${position.y}px)`,
                }
              : undefined
          }
          className={`pointer-events-auto mb-4 bg-slate-900/90 border border-slate-800 rounded-3xl ai-glass-card shadow-2xl flex flex-col overflow-hidden transition-all duration-300 backdrop-blur-2xl ${
            isExpanded
              ? 'w-[calc(100vw-2.5rem)] sm:w-[640px] h-[calc(100vh-6rem)] max-h-[750px]'
              : 'w-[calc(100vw-2.5rem)] sm:w-[420px] h-[580px] max-h-[calc(100vh-6rem)]'
          } ${isDragging ? 'opacity-95 shadow-indigo-500/20 scale-[1.01]' : ''}`}
        >
          {/* Draggable Header */}
          <div
            onMouseDown={handleMouseDown}
            className="p-4 border-b border-zinc-800 flex items-center justify-between bg-zinc-950 text-white shrink-0 select-none cursor-grab active:cursor-grabbing"
            title="Click and drag header to float window anywhere over other components"
          >
            <div className="flex items-center gap-3">
              <div className="w-2.5 h-2.5 bg-red-500 rounded-full shadow-[0_0_8px_rgba(239,68,68,0.8)] animate-pulse" />
              <div className="font-bold text-xs tracking-wide text-white flex items-center gap-1.5">
                <span>Tutormaxx Copilot Overlay</span>
              </div>
            </div>

            <div className="flex items-center gap-2 text-zinc-400">
              <button
                type="button"
                onClick={() => {
                  const next = !isSimpleMode;
                  setIsSimpleMode(next);
                  if (next) setIsTeacherMode(false);
                }}
                className={`px-2 py-0.5 text-[10px] font-bold rounded-md border transition-all flex items-center gap-1 cursor-pointer ${
                  isSimpleMode
                    ? 'bg-amber-600 border-amber-500 text-white'
                    : 'bg-zinc-900 border-zinc-800 text-zinc-300 hover:text-white'
                }`}
                title="Toggle Simple Mode (ELI5) for easy plain English explanations"
              >
                <Lightbulb className="w-3 h-3 text-amber-400" />
                <span>Simple: {isSimpleMode ? 'ON' : 'OFF'}</span>
              </button>

              <button
                type="button"
                onClick={() => {
                  const next = !isTeacherMode;
                  setIsTeacherMode(next);
                  if (next) setIsSimpleMode(false);
                }}
                className={`px-2 py-0.5 text-[10px] font-bold rounded-md border transition-all flex items-center gap-1 cursor-pointer ${
                  isTeacherMode
                    ? 'bg-red-600 border-red-500 text-white'
                    : 'bg-zinc-900 border-zinc-800 text-zinc-300 hover:text-white'
                }`}
                title="Toggle Teacher Mode for brief structured explanations"
              >
                <GraduationCap className="w-3 h-3 text-red-400" />
                <span>Teacher: {isTeacherMode ? 'ON' : 'OFF'}</span>
              </button>

              {position && (
                <button
                  type="button"
                  onClick={resetPosition}
                  title="Reset window position"
                  className="px-2 py-0.5 text-[10px] font-mono bg-zinc-800 hover:bg-zinc-700 text-zinc-300 rounded-md border border-zinc-700 transition-colors cursor-pointer"
                >
                  Reset Pos
                </button>
              )}
              <button
                type="button"
                onClick={clearChat}
                title="Clear Chat"
                className="p-1 hover:text-white transition-colors cursor-pointer"
              >
                <Trash2 className="w-4 h-4" />
              </button>
              <button
                type="button"
                onClick={() => setIsExpanded(!isExpanded)}
                title={isExpanded ? 'Collapse' : 'Expand'}
                className="hidden sm:block p-1 hover:text-white transition-colors cursor-pointer"
              >
                {isExpanded ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
              </button>
              <button
                type="button"
                onClick={onToggle}
                title="Close Window"
                className="p-1 hover:text-white transition-colors cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
          </div>

          {/* Quick Topic Chips */}
          <div className="px-3 py-2 bg-slate-950/60 border-b border-slate-800 flex items-center justify-between gap-1.5 overflow-x-auto shrink-0">
            <div className="flex items-center gap-1.5 overflow-x-auto">
              {quickTopics.map((topic, i) => (
                <button
                  key={i}
                  type="button"
                  onClick={() => handleChipClick(topic)}
                  className="px-2.5 py-1 border border-slate-800 rounded-lg bg-slate-900 text-slate-300 text-[10px] font-semibold hover:bg-slate-800 hover:text-white transition-colors cursor-pointer shrink-0"
                >
                  {topic}
                </button>
              ))}
            </div>
            <button
              type="button"
              onClick={() => setIsTeacherMode(!isTeacherMode)}
              className={`px-2 py-1 rounded-lg border text-[10px] font-bold shrink-0 cursor-pointer flex items-center gap-1 ${
                isTeacherMode ? 'bg-red-600 border-red-500 text-white' : 'bg-zinc-900 border-zinc-800 text-zinc-400 hover:text-white'
              }`}
            >
              <GraduationCap className="w-3 h-3 text-red-400" />
              <span>Teacher Mode</span>
            </button>
          </div>

          {isSimpleMode && (
            <div className="px-3 py-1.5 bg-amber-950/60 border-b border-amber-500/30 text-amber-300 text-[11px] font-medium flex items-center justify-between shrink-0">
              <span className="flex items-center gap-1.5">
                <Lightbulb className="w-3.5 h-3.5 text-amber-400 animate-pulse" />
                <span><strong>Simple Mode Active:</strong> Plain English ELI5 explanations.</span>
              </span>
              <button
                type="button"
                onClick={() => setIsSimpleMode(false)}
                className="text-[10px] font-mono text-amber-400 hover:underline cursor-pointer"
              >
                Disable
              </button>
            </div>
          )}

          {isTeacherMode && (
            <div className="px-3 py-1.5 bg-red-950/60 border-b border-red-500/30 text-red-300 text-[11px] font-medium flex items-center justify-between shrink-0">
              <span className="flex items-center gap-1.5">
                <GraduationCap className="w-3.5 h-3.5 text-red-400 animate-pulse" />
                <span><strong>Teacher Mode Active:</strong> Brief topic explanations.</span>
              </span>
              <button
                type="button"
                onClick={() => setIsTeacherMode(false)}
                className="text-[10px] font-mono text-red-400 hover:underline cursor-pointer"
              >
                Disable
              </button>
            </div>
          )}

          {/* Messages Feed */}
          <div
            ref={chatContainerRef}
            onScroll={handleScroll}
            className="flex-1 p-4 overflow-y-auto space-y-4 text-xs bg-slate-950/50 relative"
          >
            {messages.map((msg) => {
              const isUser = msg.role === 'user';
              const isLong = msg.content.length > 240;
              const isExpanded = expandedMsgIds[msg.id];

              return (
                <div
                  key={msg.id}
                  className={`flex flex-col ${isUser ? 'items-end' : 'items-start'}`}
                >
                  <div className="text-[10px] font-mono text-slate-500 mb-1 px-1 flex items-center gap-2">
                    <span>{isUser ? 'YOU' : 'COPILOT'} • {msg.timestamp}</span>
                    {isLong && (
                      <button
                        type="button"
                        onClick={() => toggleMsgExpand(msg.id)}
                        className="text-[9px] font-bold text-amber-400 hover:underline cursor-pointer flex items-center gap-0.5"
                      >
                        {isExpanded ? <ChevronUp className="w-2.5 h-2.5" /> : <ChevronDown className="w-2.5 h-2.5" />}
                        <span>{isExpanded ? 'Collapse' : 'Expand'}</span>
                      </button>
                    )}
                  </div>

                  <div
                    className={`p-4 text-xs leading-relaxed max-w-[88%] rounded-2xl border ${
                      isUser
                        ? 'bg-slate-950 border-slate-800 text-white font-medium'
                        : 'bg-indigo-950/30 text-slate-100 border-indigo-500/30'
                    }`}
                  >
                    {!isExpanded && isLong ? (
                      <div className="relative">
                        <div className="max-h-28 overflow-hidden space-y-1 opacity-90">
                          {renderFormattedContent(msg.content)}
                        </div>
                        <div className="absolute inset-x-0 bottom-0 h-16 bg-gradient-to-t from-slate-950 via-slate-950/90 to-transparent flex items-end justify-center pb-0.5">
                          <button
                            type="button"
                            onClick={() => toggleMsgExpand(msg.id)}
                            className="px-3 py-0.5 rounded-full bg-indigo-600 hover:bg-indigo-500 text-white text-[10px] font-extrabold shadow-md flex items-center gap-1 cursor-pointer"
                          >
                            <ChevronDown className="w-3 h-3" />
                            <span>Show Full Answer</span>
                          </button>
                        </div>
                      </div>
                    ) : (
                      <div className="space-y-1">
                        {renderFormattedContent(msg.content)}
                        {isLong && (
                          <div className="pt-1 flex justify-end">
                            <button
                              type="button"
                              onClick={() => toggleMsgExpand(msg.id)}
                              className="text-[10px] text-slate-400 hover:text-white flex items-center gap-0.5 cursor-pointer"
                            >
                              <ChevronUp className="w-3 h-3 text-amber-400" />
                              <span>Show Less</span>
                            </button>
                          </div>
                        )}
                      </div>
                    )}

                    {!isUser && (
                      <div className="mt-2 pt-2 border-t border-slate-800/60 flex items-center justify-between gap-2">
                        <button
                          type="button"
                          onClick={() => handleShortenAnswer(msg.content)}
                          className="text-[10px] font-bold text-amber-400 hover:text-amber-300 flex items-center gap-1 cursor-pointer bg-amber-950/40 px-2 py-0.5 rounded border border-amber-500/30"
                          title="Shorten answer to 3 bullet points"
                        >
                          <Zap className="w-3 h-3 text-amber-400" />
                          <span>Shorten</span>
                        </button>

                        <button
                          type="button"
                          onClick={() => copyToClipboard(msg.id, msg.content)}
                          className="text-[10px] font-mono text-indigo-400 hover:text-indigo-300 flex items-center gap-1 cursor-pointer"
                        >
                          {copiedId === msg.id ? (
                            <>
                              <Check className="w-3 h-3 text-emerald-400" /> COPIED
                            </>
                          ) : (
                            <>
                              <Copy className="w-3 h-3" /> COPY
                            </>
                          )}
                        </button>
                      </div>
                    )}
                  </div>
                </div>
              );
            })}

            {/* Loading Indicator */}
            {isLoading && (
              <div className="flex flex-col items-start">
                <div className="text-[10px] font-mono text-slate-500 mb-1 px-1">
                  COPILOT THINKING...
                </div>
                <div className="bg-indigo-950/30 border border-indigo-500/30 text-white p-4 rounded-2xl text-xs flex items-center gap-2">
                  <span className="font-mono text-[10px] uppercase tracking-widest text-indigo-300">
                    Inferencing Gemini 3.6 Flash
                  </span>
                  <div className="flex items-center gap-1">
                    <div className="w-1.5 h-1.5 rounded-full bg-indigo-400 animate-bounce [animation-delay:-0.3s]" />
                    <div className="w-1.5 h-1.5 rounded-full bg-indigo-400 animate-bounce [animation-delay:-0.15s]" />
                    <div className="w-1.5 h-1.5 rounded-full bg-indigo-400 animate-bounce" />
                  </div>
                </div>
              </div>
            )}

            <div ref={messagesEndRef} />
          </div>

          {/* Scroll Bottom Button */}
          {showScrollBottom && (
            <button
              type="button"
              onClick={() => scrollToBottom()}
              className="absolute bottom-24 right-6 p-2 rounded-xl bg-slate-900 border border-slate-700 text-slate-200 shadow-xl hover:bg-indigo-600 hover:text-white transition-all pointer-events-auto cursor-pointer"
            >
              <ArrowDown className="w-4 h-4" />
            </button>
          )}

          {/* Form Input */}
          <form
            onSubmit={(e) => {
              e.preventDefault();
              handleSendMessage();
            }}
            className="p-4 border-t border-slate-800 bg-slate-950/90 shrink-0 flex flex-col gap-3"
          >
            <textarea
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              onKeyDown={handleKeyDown}
              placeholder="Ask anything... (Enter to send)"
              rows={1}
              className="bg-transparent text-xs font-medium focus:outline-none placeholder-slate-500 text-white resize-none max-h-20"
            />

            <div className="flex items-center justify-between pt-2 border-t border-slate-800/80">
              <span className="text-[10px] font-mono text-slate-500">
                Shift+Enter for newline
              </span>

              <button
                type="submit"
                disabled={!inputText.trim() || isLoading}
                className="bg-red-600 hover:bg-red-500 text-white px-4 py-1.5 rounded-xl text-xs font-bold transition-all disabled:opacity-40 disabled:cursor-not-allowed cursor-pointer flex items-center gap-1.5 shadow-md shadow-red-600/30"
              >
                <span>Send</span>
                <Send className="w-3 h-3" />
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Floating Action Toggle Button */}
      <button
        type="button"
        onClick={onToggle}
        className="pointer-events-auto w-14 h-14 rounded-2xl bg-red-600 hover:bg-red-500 text-white border border-red-500/50 shadow-2xl shadow-red-600/50 flex items-center justify-center hover:scale-105 transition-all cursor-pointer relative"
        title={isOpen ? 'Close Assistant' : 'Open Tutormaxx AI Floating Chatbot'}
      >
        {isOpen ? (
          <X className="w-6 h-6 text-white" />
        ) : (
          <>
            <Bot className="w-7 h-7 text-white" />
            {unreadCount > 0 && (
              <span className="absolute -top-1 -right-1 w-5 h-5 bg-red-500 text-white font-bold text-[10px] rounded-full border border-slate-900 flex items-center justify-center animate-bounce">
                {unreadCount}
              </span>
            )}
          </>
        )}
      </button>
    </div>
  );
};


