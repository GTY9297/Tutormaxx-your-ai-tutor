import React, { useState } from 'react';
import { PRESET_PROMPTS } from '../data';
import { Sparkles, Bot, CreditCard, Code2, Cpu, PenTool, Send, MessageSquareText, Terminal, Copy, Check } from 'lucide-react';

interface LiveDemoProps {
  onOpenChat: (initialPrompt?: string) => void;
}

export const LiveDemo: React.FC<LiveDemoProps> = ({ onOpenChat }) => {
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [copiedCurl, setCopiedCurl] = useState(false);

  const categories = ['All', 'Website', 'Coding', 'Knowledge', 'Creative'];

  const filteredPrompts =
    selectedCategory === 'All'
      ? PRESET_PROMPTS
      : PRESET_PROMPTS.filter((p) => p.category === selectedCategory);

  const getCategoryIcon = (iconName: string) => {
    switch (iconName) {
      case 'Sparkles':
        return <Sparkles className="w-4 h-4 text-indigo-400" />;
      case 'Bot':
        return <Bot className="w-4 h-4 text-indigo-400" />;
      case 'CreditCard':
        return <CreditCard className="w-4 h-4 text-indigo-400" />;
      case 'Code2':
        return <Code2 className="w-4 h-4 text-indigo-400" />;
      case 'Cpu':
        return <Cpu className="w-4 h-4 text-indigo-400" />;
      case 'PenTool':
        return <PenTool className="w-4 h-4 text-indigo-400" />;
      default:
        return <MessageSquareText className="w-4 h-4 text-indigo-400" />;
    }
  };

  const curlExample = `curl -X POST https://your-domain.com/api/chat \\
  -H "Content-Type: application/json" \\
  -d '{"messages": [{"role": "user", "content": "Explain Gemini server proxy"}], "temperature": 0.7}'`;

  const copyCurl = () => {
    navigator.clipboard.writeText(curlExample);
    setCopiedCurl(true);
    setTimeout(() => setCopiedCurl(false), 2000);
  };

  return (
    <section id="demo" className="py-20 bg-slate-950 text-slate-100 border-b border-slate-800/80">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-12">
        <div className="text-center max-w-3xl mx-auto mb-12">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full border border-indigo-500/30 bg-indigo-500/10 text-indigo-300 text-xs font-mono uppercase tracking-widest mb-3">
            <Terminal className="w-3.5 h-3.5 text-indigo-400" />
            <span>Interactive API Console</span>
          </div>
          <h2 className="text-3xl sm:text-5xl font-extrabold text-white tracking-tight">
            Live Prompt & API Explorer
          </h2>
          <p className="mt-4 text-xs sm:text-sm text-slate-400 leading-relaxed">
            Test pre-configured prompts or trigger requests to the secure backend Express endpoint.
          </p>

          {/* Category Tabs */}
          <div className="mt-8 flex flex-wrap items-center justify-center gap-2">
            {categories.map((cat) => (
              <button
                key={cat}
                type="button"
                onClick={() => setSelectedCategory(cat)}
                className={`px-4 py-2 rounded-xl border text-xs font-semibold transition-all cursor-pointer ${
                  selectedCategory === cat
                    ? 'bg-indigo-600 border-indigo-500 text-white shadow-lg shadow-indigo-950/50'
                    : 'bg-slate-900/60 border-slate-800 text-slate-400 hover:text-white hover:bg-slate-800/50'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>
        </div>

        {/* cURL Request Snippet Card */}
        <div className="mb-12 rounded-3xl bg-slate-900/80 border border-slate-800 p-6 ai-glass-card">
          <div className="flex items-center justify-between pb-3 mb-3 border-b border-slate-800 text-xs font-mono text-slate-400">
            <span className="flex items-center gap-2 text-indigo-400">
              <Terminal className="w-4 h-4" /> Endpoint: POST /api/chat
            </span>
            <button
              onClick={copyCurl}
              className="text-indigo-400 hover:text-indigo-300 flex items-center gap-1 cursor-pointer"
            >
              {copiedCurl ? (
                <>
                  <Check className="w-3.5 h-3.5 text-emerald-400" /> Copied cURL
                </>
              ) : (
                <>
                  <Copy className="w-3.5 h-3.5" /> Copy cURL Snippet
                </>
              )}
            </button>
          </div>
          <pre className="font-mono text-xs text-slate-300 overflow-x-auto leading-relaxed p-2">
            <code>{curlExample}</code>
          </pre>
        </div>

        {/* Prompt Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredPrompts.map((prompt) => (
            <div
              key={prompt.id}
              onClick={() => onOpenChat(prompt.prompt)}
              className="group p-6 rounded-3xl bg-slate-900/60 border border-slate-800 ai-glass-card hover:border-indigo-500/50 transition-all cursor-pointer flex flex-col justify-between"
            >
              <div>
                <div className="flex items-center justify-between mb-4">
                  <div className="p-2.5 rounded-xl bg-slate-950 border border-slate-800">
                    {getCategoryIcon(prompt.icon)}
                  </div>
                  <span className="text-[10px] font-mono text-indigo-300 border border-indigo-500/30 bg-indigo-500/10 px-2.5 py-0.5 rounded-full">
                    {prompt.category}
                  </span>
                </div>

                <h3 className="text-base font-bold text-white group-hover:text-indigo-300 transition-colors">
                  {prompt.title}
                </h3>

                <p className="mt-3 text-xs font-mono bg-slate-950/80 p-3 rounded-xl border-l-2 border-indigo-500 leading-relaxed text-slate-300">
                  "{prompt.prompt}"
                </p>
              </div>

              <div className="mt-5 pt-3 border-t border-slate-800/80 flex items-center justify-between text-xs font-semibold text-indigo-400 group-hover:text-indigo-300 transition-colors">
                <span>Dispatch To Copilot</span>
                <Send className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};


