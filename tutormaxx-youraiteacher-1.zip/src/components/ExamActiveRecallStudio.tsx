import React, { useState, useEffect } from 'react';
import {
  GraduationCap,
  Sparkles,
  HelpCircle,
  CheckCircle2,
  XCircle,
  Award,
  Timer,
  Layers,
  FileCheck2,
  Code,
  Copy,
  Check,
  Download,
  RefreshCw,
  Lightbulb,
  ArrowRight,
  ArrowLeft,
  RotateCcw,
  BookOpen,
  Brain,
  Target,
  Zap,
  BarChart3,
  AlertTriangle,
  ChevronRight,
  Send
} from 'lucide-react';

export interface ExamQuestion {
  id: string;
  question: string;
  options: string[];
  correctAnswer: number;
  hint: string;
  explanation: string;
}

export interface Flashcard {
  id: string;
  front: string;
  back: string;
  hint?: string;
  category?: string;
}

export interface RubricItem {
  criteria: string;
  score: number;
  feedback: string;
}

export interface EssayEvaluation {
  predictedGrade: string;
  overallScore: number;
  summary: string;
  rubric: RubricItem[];
  strengths: string[];
  areasToImprove: string[];
  actionableRewrite: string;
}

export const ExamActiveRecallStudio: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'exam' | 'flashcards' | 'essay' | 'sourcecode'>('exam');

  // ================= EXAM SIMULATOR STATE =================
  const [examTopic, setExamTopic] = useState('Photosynthesis & Cellular Respiration');
  const [difficulty, setDifficulty] = useState('Medium');
  const [isGeneratingExam, setIsGeneratingExam] = useState(false);
  const [examQuestions, setExamQuestions] = useState<ExamQuestion[]>([
    {
      id: 'q1',
      question: 'Where do the light-dependent reactions of photosynthesis primary take place?',
      options: [
        'Thylakoid membranes inside chloroplasts',
        'Stroma of the chloroplast',
        'Mitochondrial matrix',
        'Cytoplasm of plant cell'
      ],
      correctAnswer: 0,
      hint: 'Think about where the chlorophyll pigments and light-absorbing reaction centers are embedded.',
      explanation: 'Light-dependent reactions occur in thylakoid membranes where chlorophyll absorbs light energy to split water molecules and produce ATP + NADPH.'
    },
    {
      id: 'q2',
      question: 'Which enzyme is responsible for primary carbon fixation in the Calvin Cycle?',
      options: ['RuBisCO', 'ATP Synthase', 'DNA Polymerase', 'Amylase'],
      correctAnswer: 0,
      hint: 'It is considered the most abundant enzyme on Earth and attaches CO2 to RuBP.',
      explanation: 'RuBisCO (Ribulose-1,5-bisphosphate carboxylase-oxygenase) catalyzes the initial major step of carbon fixation.'
    },
    {
      id: 'q3',
      question: 'What is the net gain of ATP molecules produced during aerobic cellular respiration per glucose molecule?',
      options: ['2 ATP', '30 to 32 ATP', '4 ATP', '100 ATP'],
      correctAnswer: 1,
      hint: 'Glycolysis yields 2, Krebs cycle yields 2, and Oxidative Phosphorylation produces the vast majority (~26-28).',
      explanation: 'Aerobic respiration yields approximately 30 to 32 net ATP molecules per glucose molecule in eukaryotic cells.'
    }
  ]);

  const [userAnswers, setUserAnswers] = useState<Record<number, number>>({});
  const [revealedHints, setRevealedHints] = useState<Record<number, boolean>>({});
  const [examSubmitted, setExamSubmitted] = useState(false);
  const [examTimeLeft, setExamTimeLeft] = useState(600); // 10 minutes in seconds
  const [timerActive, setTimerActive] = useState(false);

  // Timer effect
  useEffect(() => {
    let interval: any = null;
    if (timerActive && examTimeLeft > 0 && !examSubmitted) {
      interval = setInterval(() => {
        setExamTimeLeft((prev) => prev - 1);
      }, 1000);
    } else if (examTimeLeft === 0 && !examSubmitted && timerActive) {
      setExamSubmitted(true);
      setTimerActive(false);
    }
    return () => clearInterval(interval);
  }, [timerActive, examTimeLeft, examSubmitted]);

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs < 10 ? '0' : ''}${secs}`;
  };

  const handleGenerateExam = async () => {
    if (!examTopic.trim() || isGeneratingExam) return;
    setIsGeneratingExam(true);
    setExamSubmitted(false);
    setUserAnswers({});
    setRevealedHints({});
    setExamTimeLeft(600);

    try {
      const res = await fetch('/api/exam/generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ topic: examTopic, difficulty, count: 5 })
      });
      const data = await res.json();
      if (data.questions && data.questions.length > 0) {
        setExamQuestions(data.questions);
      }
    } catch (e) {
      console.error('Failed to generate exam:', e);
    } finally {
      setIsGeneratingExam(false);
      setTimerActive(true);
    }
  };

  const calculateScore = () => {
    let correctCount = 0;
    examQuestions.forEach((q, idx) => {
      if (userAnswers[idx] === q.correctAnswer) {
        correctCount++;
      }
    });
    return {
      score: correctCount,
      total: examQuestions.length,
      percentage: Math.round((correctCount / examQuestions.length) * 100)
    };
  };

  // ================= FLASHCARDS STATE =================
  const [cardTopic, setCardTopic] = useState('Newtonian Mechanics & Physics');
  const [isGeneratingCards, setIsGeneratingCards] = useState(false);
  const [flashcards, setFlashcards] = useState<Flashcard[]>([
    {
      id: 'fc1',
      front: "State Newton's Second Law of Motion and its mathematical formula.",
      back: 'The acceleration of an object is directly proportional to the net force acting on it and inversely proportional to its mass. Formula: F = m · a',
      hint: 'Relates force, mass, and acceleration.',
      category: 'Physics Principle'
    },
    {
      id: 'fc2',
      front: 'What is Inertia?',
      back: 'The inherent tendency of a body to resist any change in its state of rest or uniform motion in a straight line.',
      hint: "Exemplified by Newton's First Law.",
      category: 'Core Definition'
    },
    {
      id: 'fc3',
      front: 'What is the law of Conservation of Linear Momentum?',
      back: 'In an isolated system (no external forces), the total momentum before collision equals total momentum after collision (m1v1 + m2v2 = constant).',
      hint: 'Think about billiard balls or rocket propulsion.',
      category: 'Conservation Law'
    }
  ]);
  const [currentCardIdx, setCurrentCardIdx] = useState(0);
  const [isCardFlipped, setIsCardFlipped] = useState(false);
  const [cardShowHint, setCardShowHint] = useState(false);
  const [cardRatings, setCardRatings] = useState<Record<string, 'mastered' | 'review' | 'hard'>>({});

  const handleGenerateFlashcards = async () => {
    if (!cardTopic.trim() || isGeneratingCards) return;
    setIsGeneratingCards(true);
    setCurrentCardIdx(0);
    setIsCardFlipped(false);
    setCardShowHint(false);

    try {
      const res = await fetch('/api/flashcards/generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ topic: cardTopic, count: 6 })
      });
      const data = await res.json();
      if (data.flashcards && data.flashcards.length > 0) {
        setFlashcards(data.flashcards);
      }
    } catch (e) {
      console.error('Failed to generate flashcards:', e);
    } finally {
      setIsGeneratingCards(false);
    }
  };

  const currentCard = flashcards[currentCardIdx] || flashcards[0];

  const markCardRating = (rating: 'mastered' | 'review' | 'hard') => {
    if (!currentCard) return;
    setCardRatings((prev) => ({ ...prev, [currentCard.id]: rating }));
    setIsCardFlipped(false);
    setCardShowHint(false);
    if (currentCardIdx < flashcards.length - 1) {
      setCurrentCardIdx((prev) => prev + 1);
    }
  };

  const masteredCount = Object.values(cardRatings).filter((r) => r === 'mastered').length;
  const masteryPercentage = flashcards.length > 0 ? Math.round((masteredCount / flashcards.length) * 100) : 0;

  // ================= ESSAY EVALUATOR STATE =================
  const [essayContent, setEssayContent] = useState(
    'Artificial Intelligence is rapidly transforming modern education. AI tools provide personalized learning pathways for students, allowing them to learn at their own pace. However, educators must balance technological adoption with academic integrity and critical thinking.'
  );
  const [isEvaluatingEssay, setIsEvaluatingEssay] = useState(false);
  const [essayEvaluation, setEssayEvaluation] = useState<EssayEvaluation | null>({
    predictedGrade: 'A-',
    overallScore: 91,
    summary: 'Well-structured thesis with engaging points regarding AI integration and academic integrity.',
    rubric: [
      { criteria: 'Structure & Thesis', score: 94, feedback: 'Strong opening statement with clear logical transition between paragraphs.' },
      { criteria: 'Depth of Argumentation', score: 88, feedback: 'Good balance of benefits versus challenges, could cite 1 concrete example.' },
      { criteria: 'Academic Tone & Grammar', score: 92, feedback: 'Formal, concise academic vocabulary used throughout.' }
    ],
    strengths: ['Clear thesis statement in the opening sentence', 'Engaging, modern academic subject choice'],
    areasToImprove: ['Incorporate specific empirical statistics or case study citations', 'Expand conclusion with policy recommendations'],
    actionableRewrite: "Refined Conclusion: 'In conclusion, while AI empowers tailored learning, establishing robust institutional guardrails is paramount to safeguarding critical analytical reasoning.'"
  });

  const handleEvaluateEssay = async () => {
    if (!essayContent.trim() || isEvaluatingEssay) return;
    setIsEvaluatingEssay(true);

    try {
      const res = await fetch('/api/essay/evaluate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ content: essayContent })
      });
      const data = await res.json();
      if (data.predictedGrade) {
        setEssayEvaluation(data);
      }
    } catch (e) {
      console.error('Failed to evaluate essay:', e);
    } finally {
      setIsEvaluatingEssay(false);
    }
  };

  // ================= SOURCE CODE INSPECTOR STATE =================
  const [copiedCodeSnippet, setCopiedCodeSnippet] = useState(false);
  const [activeCodeTab, setActiveCodeTab] = useState<'client' | 'server'>('client');

  const CLIENT_SOURCE_CODE = `// ExamActiveRecallStudio.tsx (Socratic Exam & Active Recall Engine)
import React, { useState } from 'react';

export const ExamSimulator = () => {
  const [topic, setTopic] = useState('Photosynthesis');
  const [questions, setQuestions] = useState([]);
  
  const generateExam = async () => {
    const res = await fetch('/api/exam/generate', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ topic, count: 5 })
    });
    const data = await res.json();
    setQuestions(data.questions);
  };

  return (
    <div className="exam-container">
      <h2>Socratic Exam Simulator</h2>
      <button onClick={generateExam}>Build Exam with Gemini</button>
      {/* Renders Questions + Socratic Hints + Instant AI Grading */}
    </div>
  );
};`;

  const SERVER_SOURCE_CODE = `// server.ts (Gemini 3.6 Flash Server-Side Proxy Endpoint)
app.post("/api/exam/generate", async (req, res) => {
  const { topic, difficulty, count } = req.body;
  const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });

  const sysPrompt = \`You are an academic exam creator. Create a test for "\${topic}".
Return ONLY raw JSON with schema: { "questions": [{ "question": "...", "options": [...], "correctAnswer": 0, "hint": "Socratic clue" }] }\`;

  const response = await ai.models.generateContent({
    model: "gemini-3.6-flash",
    contents: [{ role: "user", parts: [{ text: \`Generate \${count} questions\` }] }],
    config: { systemInstruction: sysPrompt, temperature: 0.3 }
  });

  res.json(JSON.parse(response.text.replace(/\\\`\\\`\\\`json/g, "").replace(/\\\`\\\`\\\`/g, "")));
});`;

  const copySourceCode = (code: string) => {
    navigator.clipboard.writeText(code);
    setCopiedCodeSnippet(true);
    setTimeout(() => setCopiedCodeSnippet(false), 2000);
  };

  return (
    <section id="exam-active-recall-studio" className="py-12 bg-zinc-950 border-t border-b border-zinc-800 relative">
      {/* Background Red Glow */}
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 w-3/4 h-96 bg-red-600/10 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-6xl mx-auto px-4 sm:px-6 relative z-10">
        {/* Header Title Banner */}
        <div className="text-center max-w-3xl mx-auto mb-10">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full border border-red-500/30 bg-red-950/40 text-red-400 text-xs font-mono font-bold mb-3 shadow-inner">
            <Sparkles className="w-3.5 h-3.5 text-red-500" />
            <span>KILLER FEATURE • STUDENT MASTERY ENGINE</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-black text-white tracking-tight">
            AI Exam & Active Recall Studio
          </h2>
          <p className="text-xs sm:text-sm text-zinc-400 mt-2 font-medium leading-relaxed">
            The ultimate reason students choose TutorMaxx: Socratic Exam Simulator, 3D Memory Flashcards, Rubric Essay Evaluator, and Open Source Code.
          </p>
        </div>

        {/* Studio Navigation Tabs */}
        <div className="flex items-center justify-center gap-2 mb-10 overflow-x-auto pb-2">
          <button
            type="button"
            onClick={() => setActiveTab('exam')}
            className={`px-5 py-3 rounded-2xl border text-xs font-extrabold flex items-center gap-2 transition-all cursor-pointer ${
              activeTab === 'exam'
                ? 'bg-red-600 border-red-500 text-white shadow-lg shadow-red-600/30'
                : 'bg-zinc-900 border-zinc-800 text-zinc-400 hover:text-white hover:bg-zinc-800'
            }`}
          >
            <Target className="w-4 h-4 text-red-300" />
            <span>Socratic Exam Simulator</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('flashcards')}
            className={`px-5 py-3 rounded-2xl border text-xs font-extrabold flex items-center gap-2 transition-all cursor-pointer ${
              activeTab === 'flashcards'
                ? 'bg-red-600 border-red-500 text-white shadow-lg shadow-red-600/30'
                : 'bg-zinc-900 border-zinc-800 text-zinc-400 hover:text-white hover:bg-zinc-800'
            }`}
          >
            <Layers className="w-4 h-4 text-emerald-400" />
            <span>3D Flashcards & Retention</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('essay')}
            className={`px-5 py-3 rounded-2xl border text-xs font-extrabold flex items-center gap-2 transition-all cursor-pointer ${
              activeTab === 'essay'
                ? 'bg-red-600 border-red-500 text-white shadow-lg shadow-red-600/30'
                : 'bg-zinc-900 border-zinc-800 text-zinc-400 hover:text-white hover:bg-zinc-800'
            }`}
          >
            <FileCheck2 className="w-4 h-4 text-amber-400" />
            <span>Essay & Rubric Evaluator</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('sourcecode')}
            className={`px-5 py-3 rounded-2xl border text-xs font-extrabold flex items-center gap-2 transition-all cursor-pointer ${
              activeTab === 'sourcecode'
                ? 'bg-red-600 border-red-500 text-white shadow-lg shadow-red-600/30'
                : 'bg-zinc-900 border-zinc-800 text-zinc-400 hover:text-white hover:bg-zinc-800'
            }`}
          >
            <Code className="w-4 h-4 text-cyan-400" />
            <span>Get Source Code</span>
          </button>
        </div>

        {/* TAB 1: SOCRATIC EXAM SIMULATOR */}
        {activeTab === 'exam' && (
          <div className="p-6 sm:p-8 rounded-3xl bg-zinc-900/90 border border-zinc-800 shadow-2xl">
            {/* Exam Setup Bar */}
            <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 pb-6 mb-6 border-b border-zinc-800">
              <div className="flex-1">
                <label className="block text-xs font-extrabold text-zinc-300 mb-2">
                  Enter Subject or Exam Topic:
                </label>
                <input
                  type="text"
                  value={examTopic}
                  onChange={(e) => setExamTopic(e.target.value)}
                  placeholder="e.g. Photosynthesis, Trigonometry, World War II, Python Data Structures..."
                  className="w-full px-4 py-3 rounded-xl bg-zinc-950 border border-zinc-800 text-xs sm:text-sm text-white font-medium focus:outline-none focus:border-red-500"
                />
              </div>

              <div>
                <label className="block text-xs font-extrabold text-zinc-300 mb-2">
                  Difficulty Level:
                </label>
                <select
                  value={difficulty}
                  onChange={(e) => setDifficulty(e.target.value)}
                  className="w-full px-4 py-3 rounded-xl bg-zinc-950 border border-zinc-800 text-xs text-white font-semibold focus:outline-none focus:border-red-500"
                >
                  <option value="Easy">Easy (High School)</option>
                  <option value="Medium">Medium (College Prep)</option>
                  <option value="Hard">Hard (Undergraduate)</option>
                  <option value="Competitive Exam">Competitive Exam (SAT/GRE/JEE)</option>
                </select>
              </div>

              <button
                type="button"
                onClick={handleGenerateExam}
                disabled={!examTopic.trim() || isGeneratingExam}
                className="px-6 py-3 rounded-xl bg-red-600 hover:bg-red-500 text-white text-xs font-extrabold transition-all cursor-pointer flex items-center justify-center gap-2 shadow-md shadow-red-600/30 shrink-0 disabled:opacity-50"
              >
                {isGeneratingExam ? (
                  <RefreshCw className="w-4 h-4 animate-spin" />
                ) : (
                  <Sparkles className="w-4 h-4" />
                )}
                <span>{isGeneratingExam ? 'Building Exam...' : 'Generate New Exam'}</span>
              </button>
            </div>

            {/* Exam Live Info Bar */}
            <div className="flex flex-wrap items-center justify-between gap-4 p-4 rounded-2xl bg-zinc-950 border border-zinc-800 mb-8 text-xs font-mono">
              <div className="flex items-center gap-2">
                <Target className="w-4 h-4 text-red-500" />
                <span className="text-zinc-300 font-bold">Topic: {examTopic}</span>
              </div>

              <div className="flex items-center gap-4">
                <div className="flex items-center gap-1.5 text-zinc-400">
                  <Timer className="w-4 h-4 text-amber-400" />
                  <span>Time Left: <strong className="text-white font-bold">{formatTime(examTimeLeft)}</strong></span>
                </div>

                <div className="flex items-center gap-1.5 text-zinc-400">
                  <Award className="w-4 h-4 text-emerald-400" />
                  <span>Questions: <strong className="text-white font-bold">{examQuestions.length}</strong></span>
                </div>
              </div>
            </div>

            {/* Questions List */}
            <div className="space-y-6">
              {examQuestions.map((q, qIdx) => {
                const selectedOption = userAnswers[qIdx];
                const isHintRevealed = revealedHints[qIdx];

                return (
                  <div
                    key={q.id || qIdx}
                    className="p-6 rounded-2xl bg-zinc-950 border border-zinc-800/80 hover:border-zinc-700 transition-all"
                  >
                    <div className="flex items-start justify-between gap-3 mb-4">
                      <h3 className="font-bold text-sm sm:text-base text-zinc-100 leading-snug">
                        <span className="text-red-500 mr-2">Q{qIdx + 1}.</span>
                        {q.question}
                      </h3>

                      {/* Socratic Hint Trigger */}
                      <button
                        type="button"
                        onClick={() =>
                          setRevealedHints((prev) => ({ ...prev, [qIdx]: !prev[qIdx] }))
                        }
                        className="px-3 py-1.5 rounded-xl border border-amber-500/30 bg-amber-950/40 hover:bg-amber-900/40 text-amber-400 text-[11px] font-bold transition-colors flex items-center gap-1.5 shrink-0 cursor-pointer"
                        title="Get Socratic clue without revealing answer"
                      >
                        <Lightbulb className="w-3.5 h-3.5 text-amber-400 animate-pulse" />
                        <span>{isHintRevealed ? 'Hide Clue' : 'Socratic Hint'}</span>
                      </button>
                    </div>

                    {/* Socratic Hint Box */}
                    {isHintRevealed && (
                      <div className="p-3.5 rounded-xl bg-amber-950/30 border border-amber-500/30 mb-4 text-xs text-amber-200 leading-relaxed font-medium flex items-start gap-2">
                        <Lightbulb className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                        <div>
                          <strong className="block text-amber-400 font-extrabold mb-0.5">Socratic Thinking Clue:</strong>
                          {q.hint}
                        </div>
                      </div>
                    )}

                    {/* Options Grid */}
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mb-4">
                      {q.options.map((opt, optIdx) => {
                        const isSelected = selectedOption === optIdx;
                        const isCorrect = q.correctAnswer === optIdx;

                        let style = 'bg-zinc-900 border-zinc-800 text-zinc-300 hover:border-zinc-700 hover:bg-zinc-800';

                        if (examSubmitted) {
                          if (isCorrect) {
                            style = 'bg-emerald-950/60 border-emerald-500 text-emerald-200 font-bold';
                          } else if (isSelected && !isCorrect) {
                            style = 'bg-red-950/60 border-red-500 text-red-200';
                          }
                        } else if (isSelected) {
                          style = 'bg-red-950/50 border-red-500 text-white font-bold shadow-sm';
                        }

                        return (
                          <button
                            key={optIdx}
                            type="button"
                            disabled={examSubmitted}
                            onClick={() =>
                              setUserAnswers((prev) => ({ ...prev, [qIdx]: optIdx }))
                            }
                            className={`p-3.5 rounded-xl border text-left text-xs font-medium transition-all flex items-center justify-between cursor-pointer ${style}`}
                          >
                            <span>{opt}</span>
                            {examSubmitted && isCorrect && (
                              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 ml-2" />
                            )}
                            {examSubmitted && isSelected && !isCorrect && (
                              <XCircle className="w-4 h-4 text-red-400 shrink-0 ml-2" />
                            )}
                          </button>
                        );
                      })}
                    </div>

                    {/* Explanation Box (Post submission) */}
                    {examSubmitted && (
                      <div className="p-4 rounded-xl bg-zinc-900 border border-zinc-800 text-xs text-zinc-300 font-medium leading-relaxed">
                        <strong className="block text-red-400 font-extrabold mb-1">
                          Professor Explanation:
                        </strong>
                        {q.explanation}
                      </div>
                    )}
                  </div>
                );
              })}
            </div>

            {/* Submit / Score Action Footer */}
            <div className="mt-8 pt-6 border-t border-zinc-800 flex flex-col sm:flex-row items-center justify-between gap-4">
              {!examSubmitted ? (
                <button
                  type="button"
                  onClick={() => {
                    setExamSubmitted(true);
                    setTimerActive(false);
                  }}
                  disabled={Object.keys(userAnswers).length === 0}
                  className="w-full sm:w-auto px-8 py-3.5 rounded-2xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-black tracking-wider uppercase transition-all shadow-lg shadow-emerald-600/30 cursor-pointer disabled:opacity-40"
                >
                  Submit Practice Exam & Grade Now
                </button>
              ) : (
                <div className="w-full p-6 rounded-2xl bg-gradient-to-r from-red-950/80 via-zinc-900 to-zinc-950 border border-red-500/40 flex flex-col md:flex-row items-center justify-between gap-4">
                  <div>
                    <span className="text-xs font-mono font-bold text-red-400 uppercase tracking-wider block mb-1">
                      EXAM PERFORMANCE REPORT
                    </span>
                    <h4 className="text-2xl font-black text-white">
                      Your Score: {calculateScore().score} / {calculateScore().total} ({calculateScore().percentage}%)
                    </h4>
                    <p className="text-xs text-zinc-400 mt-1">
                      {calculateScore().percentage >= 80
                        ? '🎉 Mastery Level Achieved! You are exam ready for this topic.'
                        : '💡 Good practice run! Review explanations above and try again.'}
                    </p>
                  </div>

                  <button
                    type="button"
                    onClick={() => {
                      setExamSubmitted(false);
                      setUserAnswers({});
                      setRevealedHints({});
                      setExamTimeLeft(600);
                      setTimerActive(true);
                    }}
                    className="px-6 py-3 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-white text-xs font-bold transition-all flex items-center gap-2 cursor-pointer shrink-0 border border-zinc-700"
                  >
                    <RotateCcw className="w-4 h-4 text-red-400" />
                    <span>Retake Exam</span>
                  </button>
                </div>
              )}
            </div>
          </div>
        )}

        {/* TAB 2: ACTIVE RECALL 3D FLASHCARDS */}
        {activeTab === 'flashcards' && (
          <div className="p-6 sm:p-8 rounded-3xl bg-zinc-900/90 border border-zinc-800 shadow-2xl">
            {/* Flashcard Header Bar */}
            <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 pb-6 mb-6 border-b border-zinc-800">
              <div className="flex-1">
                <label className="block text-xs font-extrabold text-zinc-300 mb-2">
                  Flashcard Subject / Lecture Notes Topic:
                </label>
                <input
                  type="text"
                  value={cardTopic}
                  onChange={(e) => setCardTopic(e.target.value)}
                  placeholder="e.g. Newtonian Physics, Organic Chemistry, Indian Constitution, Foreign Vocabulary..."
                  className="w-full px-4 py-3 rounded-xl bg-zinc-950 border border-zinc-800 text-xs sm:text-sm text-white font-medium focus:outline-none focus:border-emerald-500"
                />
              </div>

              <button
                type="button"
                onClick={handleGenerateFlashcards}
                disabled={!cardTopic.trim() || isGeneratingCards}
                className="px-6 py-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-extrabold transition-all cursor-pointer flex items-center justify-center gap-2 shadow-md shadow-emerald-600/30 shrink-0 disabled:opacity-50"
              >
                {isGeneratingCards ? (
                  <RefreshCw className="w-4 h-4 animate-spin" />
                ) : (
                  <Layers className="w-4 h-4" />
                )}
                <span>{isGeneratingCards ? 'Creating Deck...' : 'Generate AI Flashcard Deck'}</span>
              </button>
            </div>

            {/* Active Recall Stats Bar */}
            <div className="flex flex-wrap items-center justify-between gap-4 p-4 rounded-2xl bg-zinc-950 border border-zinc-800 mb-8 text-xs font-mono">
              <div className="flex items-center gap-2">
                <Brain className="w-4 h-4 text-emerald-400" />
                <span className="text-zinc-300 font-bold">Retention Mastery: {masteryPercentage}%</span>
              </div>

              <div className="flex items-center gap-4">
                <span className="text-zinc-400">Card <strong>{currentCardIdx + 1}</strong> of <strong>{flashcards.length}</strong></span>
                <span className="text-emerald-400 font-bold">Mastered: {masteredCount}</span>
              </div>
            </div>

            {/* 3D Interactive Flip Flashcard Canvas */}
            <div className="max-w-xl mx-auto my-8">
              <div
                onClick={() => setIsCardFlipped(!isCardFlipped)}
                className={`min-h-[260px] p-8 rounded-3xl border transition-all duration-500 cursor-pointer flex flex-col justify-between shadow-2xl relative select-none ${
                  isCardFlipped
                    ? 'bg-zinc-950 border-emerald-500/60 shadow-emerald-500/10'
                    : 'bg-gradient-to-br from-zinc-900 via-zinc-950 to-black border-zinc-800 hover:border-red-500/50 shadow-red-600/10'
                }`}
              >
                {/* Category Badge */}
                <div className="flex items-center justify-between gap-2">
                  <span className="px-3 py-1 rounded-full border border-zinc-800 bg-zinc-900 text-[10px] font-mono font-bold text-red-400">
                    {currentCard?.category || 'Active Recall Card'}
                  </span>

                  <span className="text-[10px] font-mono font-bold text-zinc-500 uppercase tracking-widest">
                    {isCardFlipped ? 'Answer (Click to Flip)' : 'Question (Click to Flip)'}
                  </span>
                </div>

                {/* Main Content */}
                <div className="my-6 text-center">
                  {!isCardFlipped ? (
                    <h3 className="text-lg sm:text-xl font-black text-white leading-relaxed">
                      {currentCard?.front}
                    </h3>
                  ) : (
                    <div className="space-y-2">
                      <p className="text-sm sm:text-base font-bold text-emerald-300 leading-relaxed">
                        {currentCard?.back}
                      </p>
                    </div>
                  )}
                </div>

                {/* Flip Prompt Footer */}
                <div className="flex items-center justify-between text-xs font-mono text-zinc-500 pt-4 border-t border-zinc-800/80">
                  <span className="flex items-center gap-1 text-red-400 font-bold">
                    <RotateCcw className="w-3.5 h-3.5" />
                    <span>Flip Card</span>
                  </span>

                  {currentCard?.hint && (
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        setCardShowHint(!cardShowHint);
                      }}
                      className="text-amber-400 hover:underline flex items-center gap-1 font-bold"
                    >
                      <Lightbulb className="w-3.5 h-3.5" />
                      <span>{cardShowHint ? 'Hide Hint' : 'Show Hint'}</span>
                    </button>
                  )}
                </div>

                {/* Hint Dropdown */}
                {cardShowHint && currentCard?.hint && (
                  <div className="mt-2 p-3 rounded-xl bg-amber-950/40 border border-amber-500/30 text-xs text-amber-200">
                    💡 Memory Hint: {currentCard.hint}
                  </div>
                )}
              </div>

              {/* Confidence Rating Bar */}
              <div className="mt-8 grid grid-cols-3 gap-3">
                <button
                  type="button"
                  onClick={() => markCardRating('hard')}
                  className="p-3.5 rounded-2xl bg-zinc-950 border border-red-500/30 hover:bg-red-950/40 text-red-400 text-xs font-extrabold transition-all cursor-pointer flex items-center justify-center gap-1.5"
                >
                  <XCircle className="w-4 h-4" />
                  <span>Hard (Review Again)</span>
                </button>

                <button
                  type="button"
                  onClick={() => markCardRating('review')}
                  className="p-3.5 rounded-2xl bg-zinc-950 border border-amber-500/30 hover:bg-amber-950/40 text-amber-400 text-xs font-extrabold transition-all cursor-pointer flex items-center justify-center gap-1.5"
                >
                  <AlertTriangle className="w-4 h-4" />
                  <span>Good (Review Soon)</span>
                </button>

                <button
                  type="button"
                  onClick={() => markCardRating('mastered')}
                  className="p-3.5 rounded-2xl bg-zinc-950 border border-emerald-500/30 hover:bg-emerald-950/40 text-emerald-400 text-xs font-extrabold transition-all cursor-pointer flex items-center justify-center gap-1.5"
                >
                  <CheckCircle2 className="w-4 h-4" />
                  <span>Mastered</span>
                </button>
              </div>

              {/* Deck Navigation Controls */}
              <div className="flex items-center justify-between mt-6">
                <button
                  type="button"
                  onClick={() => {
                    if (currentCardIdx > 0) {
                      setCurrentCardIdx((prev) => prev - 1);
                      setIsCardFlipped(false);
                      setCardShowHint(false);
                    }
                  }}
                  disabled={currentCardIdx === 0}
                  className="px-4 py-2 rounded-xl border border-zinc-800 bg-zinc-950 hover:bg-zinc-800 text-zinc-300 text-xs font-bold transition-all disabled:opacity-30 cursor-pointer flex items-center gap-1.5"
                >
                  <ArrowLeft className="w-3.5 h-3.5" />
                  <span>Previous</span>
                </button>

                <span className="text-xs font-mono text-zinc-500 font-bold">
                  Deck Progress: {currentCardIdx + 1} / {flashcards.length}
                </span>

                <button
                  type="button"
                  onClick={() => {
                    if (currentCardIdx < flashcards.length - 1) {
                      setCurrentCardIdx((prev) => prev + 1);
                      setIsCardFlipped(false);
                      setCardShowHint(false);
                    }
                  }}
                  disabled={currentCardIdx === flashcards.length - 1}
                  className="px-4 py-2 rounded-xl border border-zinc-800 bg-zinc-950 hover:bg-zinc-800 text-zinc-300 text-xs font-bold transition-all disabled:opacity-30 cursor-pointer flex items-center gap-1.5"
                >
                  <span>Next Card</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          </div>
        )}

        {/* TAB 3: ESSAY & RUBRIC EVALUATOR */}
        {activeTab === 'essay' && (
          <div className="p-6 sm:p-8 rounded-3xl bg-zinc-900/90 border border-zinc-800 shadow-2xl">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              {/* Input Column */}
              <div>
                <label className="block text-xs font-extrabold text-zinc-300 mb-2">
                  Paste Essay, Homework Solution, or Code:
                </label>
                <textarea
                  value={essayContent}
                  onChange={(e) => setEssayContent(e.target.value)}
                  rows={10}
                  placeholder="Paste your paragraph, essay thesis, or code logic here for instant professor feedback..."
                  className="w-full p-4 rounded-2xl bg-zinc-950 border border-zinc-800 text-xs sm:text-sm text-white font-medium focus:outline-none focus:border-amber-500 resize-none leading-relaxed"
                />

                <button
                  type="button"
                  onClick={handleEvaluateEssay}
                  disabled={!essayContent.trim() || isEvaluatingEssay}
                  className="w-full mt-4 py-3.5 rounded-2xl bg-amber-600 hover:bg-amber-500 text-white text-xs font-black tracking-wider uppercase transition-all shadow-lg shadow-amber-600/30 flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
                >
                  {isEvaluatingEssay ? (
                    <RefreshCw className="w-4 h-4 animate-spin" />
                  ) : (
                    <FileCheck2 className="w-4 h-4" />
                  )}
                  <span>{isEvaluatingEssay ? 'Evaluating Academic Rubric...' : 'Evaluate & Predict Grade'}</span>
                </button>
              </div>

              {/* Output Column */}
              {essayEvaluation ? (
                <div className="p-6 rounded-2xl bg-zinc-950 border border-zinc-800 space-y-6">
                  <div className="flex items-center justify-between pb-4 border-b border-zinc-800">
                    <div>
                      <span className="text-[10px] font-mono font-bold text-amber-400 uppercase tracking-widest block mb-0.5">
                        ACADEMIC RUBRIC EVALUATION
                      </span>
                      <h4 className="text-xl font-extrabold text-white">Overall Professor Critique</h4>
                    </div>

                    <div className="p-3 rounded-2xl bg-amber-950/60 border border-amber-500/40 text-center">
                      <span className="text-[10px] font-mono font-bold text-amber-300 block">Grade</span>
                      <span className="text-2xl font-black text-amber-400">{essayEvaluation.predictedGrade}</span>
                    </div>
                  </div>

                  <p className="text-xs text-zinc-300 leading-relaxed font-medium">
                    {essayEvaluation.summary}
                  </p>

                  {/* Rubric Criteria Breakdown */}
                  <div className="space-y-3">
                    <h5 className="text-xs font-mono font-bold text-zinc-400 uppercase">Rubric Criteria Scores:</h5>
                    {essayEvaluation.rubric.map((r, idx) => (
                      <div key={idx} className="p-3 rounded-xl bg-zinc-900 border border-zinc-800">
                        <div className="flex items-center justify-between text-xs font-bold text-zinc-200 mb-1">
                          <span>{r.criteria}</span>
                          <span className="text-amber-400">{r.score} / 100</span>
                        </div>
                        <p className="text-[11px] text-zinc-400">{r.feedback}</p>
                      </div>
                    ))}
                  </div>

                  {/* Strengths & Weaknesses */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div className="p-3 rounded-xl bg-emerald-950/30 border border-emerald-500/30 text-xs">
                      <strong className="block text-emerald-400 font-bold mb-1">Key Strengths:</strong>
                      <ul className="space-y-1 list-disc list-inside text-emerald-200 text-[11px]">
                        {essayEvaluation.strengths.map((s, idx) => (
                          <li key={idx}>{s}</li>
                        ))}
                      </ul>
                    </div>

                    <div className="p-3 rounded-xl bg-red-950/30 border border-red-500/30 text-xs">
                      <strong className="block text-red-400 font-bold mb-1">Areas to Improve:</strong>
                      <ul className="space-y-1 list-disc list-inside text-red-200 text-[11px]">
                        {essayEvaluation.areasToImprove.map((w, idx) => (
                          <li key={idx}>{w}</li>
                        ))}
                      </ul>
                    </div>
                  </div>

                  {/* Actionable Rewrite */}
                  {essayEvaluation.actionableRewrite && (
                    <div className="p-4 rounded-xl bg-zinc-900 border border-zinc-800 text-xs">
                      <strong className="block text-amber-400 font-extrabold mb-1">
                        Actionable Rewrite Recommendation:
                      </strong>
                      <p className="text-zinc-300 font-mono text-[11px] leading-relaxed">
                        {essayEvaluation.actionableRewrite}
                      </p>
                    </div>
                  )}
                </div>
              ) : (
                <div className="p-8 rounded-2xl bg-zinc-950 border border-zinc-800 flex flex-col items-center justify-center text-center text-zinc-500 text-xs">
                  <FileCheck2 className="w-8 h-8 text-zinc-600 mb-2" />
                  <span>Paste text on the left and click Evaluate to see grade prediction & rubric feedback.</span>
                </div>
              )}
            </div>
          </div>
        )}

        {/* TAB 4: GET SOURCE CODE HUB */}
        {activeTab === 'sourcecode' && (
          <div className="p-6 sm:p-8 rounded-3xl bg-zinc-900/90 border border-zinc-800 shadow-2xl">
            <div className="flex flex-col sm:flex-row items-center justify-between gap-4 pb-6 mb-6 border-b border-zinc-800">
              <div>
                <div className="inline-flex items-center gap-2 text-cyan-400 text-xs font-mono font-bold uppercase tracking-widest mb-1">
                  <Code className="w-4 h-4" />
                  <span>OPEN SOURCE IMPLEMENTATION</span>
                </div>
                <h3 className="text-2xl font-black text-white">Full Source Code Reference</h3>
                <p className="text-xs text-zinc-400 mt-1 font-medium">
                  Copy or inspect the exact React TypeScript & Server Express endpoints powering this student AI tool.
                </p>
              </div>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setActiveCodeTab('client')}
                  className={`px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                    activeCodeTab === 'client'
                      ? 'bg-cyan-600 text-white shadow-md'
                      : 'bg-zinc-950 text-zinc-400 border border-zinc-800'
                  }`}
                >
                  React Component TSX
                </button>
                <button
                  type="button"
                  onClick={() => setActiveCodeTab('server')}
                  className={`px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                    activeCodeTab === 'server'
                      ? 'bg-cyan-600 text-white shadow-md'
                      : 'bg-zinc-950 text-zinc-400 border border-zinc-800'
                  }`}
                >
                  Server Route TS
                </button>
              </div>
            </div>

            {/* Code Display Area */}
            <div className="relative rounded-2xl bg-zinc-950 border border-zinc-800 overflow-hidden">
              <div className="flex items-center justify-between px-4 py-3 bg-zinc-900 border-b border-zinc-800 text-xs font-mono text-zinc-400">
                <span>{activeCodeTab === 'client' ? 'src/components/ExamActiveRecallStudio.tsx' : 'server.ts'}</span>
                <button
                  type="button"
                  onClick={() =>
                    copySourceCode(activeCodeTab === 'client' ? CLIENT_SOURCE_CODE : SERVER_SOURCE_CODE)
                  }
                  className="px-3 py-1 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-cyan-400 font-bold transition-colors flex items-center gap-1.5 cursor-pointer"
                >
                  {copiedCodeSnippet ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copiedCodeSnippet ? 'Copied to Clipboard' : 'Copy Source Code'}</span>
                </button>
              </div>

              <pre className="p-6 overflow-x-auto text-xs font-mono text-zinc-200 leading-relaxed max-h-[400px]">
                <code>{activeCodeTab === 'client' ? CLIENT_SOURCE_CODE : SERVER_SOURCE_CODE}</code>
              </pre>
            </div>
          </div>
        )}
      </div>
    </section>
  );
};
