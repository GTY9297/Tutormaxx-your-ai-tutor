import React, { useState } from 'react';
import {
  Network,
  Sparkles,
  ChevronRight,
  ChevronDown,
  Maximize2,
  Minimize2,
  Download,
  Copy,
  Check,
  BookOpen,
  HelpCircle,
  Zap,
  ArrowRight,
  PlusCircle,
  MinusCircle,
  RefreshCw
} from 'lucide-react';

export interface MindMapNode {
  id: string;
  title: string;
  details?: string;
  color?: string;
  children?: MindMapNode[];
}

export interface MindMapData {
  topic: string;
  summary?: string;
  nodes: MindMapNode[];
}

interface MindMapGeneratorProps {
  onOpenChatWithPrompt?: (prompt: string) => void;
}

const PRESET_MINDMAPS: Record<string, MindMapData> = {
  Photosynthesis: {
    topic: 'Photosynthesis in Green Plants',
    summary: 'The biological process converting light energy, water, and CO₂ into glucose and oxygen.',
    nodes: [
      {
        id: '1',
        title: 'Light-Dependent Reactions',
        color: 'border-amber-500/50 bg-amber-950/20 text-amber-300',
        details: 'Occurs in the thylakoid membranes during daytime.',
        children: [
          { id: '1-1', title: 'Photolysis of Water', details: 'Splits 2H₂O → 4H⁺ + 4e⁻ + O₂' },
          { id: '1-2', title: 'Chlorophyll Activation', details: 'Absorbs blue and red wavelengths of sunlight' },
          { id: '1-3', title: 'Energy Carriers', details: 'Generates ATP and NADPH for Calvin Cycle' }
        ]
      },
      {
        id: '2',
        title: 'Calvin Cycle (Dark Reactions)',
        color: 'border-emerald-500/50 bg-emerald-950/20 text-emerald-300',
        details: 'Occurs in the stroma without requiring direct sunlight.',
        children: [
          { id: '2-1', title: 'Carbon Fixation', details: 'RuBisCO enzyme attaches CO₂ to RuBP' },
          { id: '2-2', title: 'Sugar Production', details: 'Produces G3P which forms Glucose (C₆H₁₂O₆)' },
          { id: '2-3', title: 'RuBP Regeneration', details: 'Reuses ATP to restart the cycle' }
        ]
      },
      {
        id: '3',
        title: 'Key Inputs & Outputs',
        color: 'border-sky-500/50 bg-sky-950/20 text-sky-300',
        details: 'Overall Balanced Equation: 6CO₂ + 6H₂O + Sunlight → C₆H₁₂O₆ + 6O₂',
        children: [
          { id: '3-1', title: 'Inputs', details: 'Sunlight, Water (from roots), CO₂ (from stomata)' },
          { id: '3-2', title: 'Outputs', details: 'Glucose (plant food), Oxygen (released to air)' }
        ]
      }
    ]
  },
  'Indian Constitution': {
    topic: 'Indian Constitution Overview',
    summary: 'Supreme law of India, adopted on 26 Nov 1949 and enacted on 26 Jan 1950.',
    nodes: [
      {
        id: 'c1',
        title: 'Preamble',
        color: 'border-purple-500/50 bg-purple-950/20 text-purple-300',
        details: 'Key guiding principles: Sovereign, Socialist, Secular, Democratic Republic.',
        children: [
          { id: 'c1-1', title: 'Justice', details: 'Social, Economic, and Political justice' },
          { id: 'c1-2', title: 'Liberty & Equality', details: 'Thought, expression, belief, faith, and status' }
        ]
      },
      {
        id: 'c2',
        title: 'Fundamental Rights (Part III)',
        color: 'border-red-500/50 bg-red-950/20 text-red-300',
        details: 'Articles 12 to 35 granting essential freedoms to all citizens.',
        children: [
          { id: 'c2-1', title: 'Right to Equality (14-18)', details: 'Equal protection before law' },
          { id: 'c2-2', title: 'Right to Freedom (19-22)', details: 'Speech, assembly, movement, life' },
          { id: 'c2-3', title: 'Constitutional Remedies (32)', details: 'Writs by Supreme Court (Habeas Corpus, etc.)' }
        ]
      },
      {
        id: 'c3',
        title: '3 Pillars of Governance',
        color: 'border-amber-500/50 bg-amber-950/20 text-amber-300',
        details: 'Separation of powers ensuring checks and balances.',
        children: [
          { id: 'c3-1', title: 'Legislature', details: 'Parliament (Lok Sabha & Rajya Sabha)' },
          { id: 'c3-2', title: 'Executive', details: 'President, PM, Council of Ministers' },
          { id: 'c3-3', title: 'Judiciary', details: 'Independent Supreme Court, High Courts' }
        ]
      }
    ]
  },
  'Newton Laws of Motion': {
    topic: "Newton's Three Laws of Motion",
    summary: 'Fundamental physical principles describing relationship between force and body motion.',
    nodes: [
      {
        id: 'n1',
        title: 'First Law (Inertia)',
        color: 'border-indigo-500/50 bg-indigo-950/20 text-indigo-300',
        details: 'An object stays at rest or in uniform motion unless acted on by external net force.',
        children: [
          { id: 'n1-1', title: 'Inertia of Rest', details: 'Example: Dust falling from carpet when beaten' },
          { id: 'n1-2', title: 'Inertia of Motion', details: 'Example: Passengers jerking forward when bus brakes' }
        ]
      },
      {
        id: 'n2',
        title: 'Second Law (F = ma)',
        color: 'border-red-500/50 bg-red-950/20 text-red-300',
        details: 'Force equals rate of change of momentum (Force = Mass × Acceleration).',
        children: [
          { id: 'n2-1', title: 'Formula', details: 'F = m · a (Measured in Newtons)' },
          { id: 'n2-2', title: 'Application', details: 'Catcher pulling hands back while catching cricket ball' }
        ]
      },
      {
        id: 'n3',
        title: 'Third Law (Action-Reaction)',
        color: 'border-emerald-500/50 bg-emerald-950/20 text-emerald-300',
        details: 'For every action, there is an equal and opposite reaction.',
        children: [
          { id: 'n3-1', title: 'Rocket Propulsion', details: 'Exhaust gas pushes down, rocket accelerates up' },
          { id: 'n3-2', title: 'Recoil of Gun', details: 'Bullet moves forward, gun recoils backward' }
        ]
      }
    ]
  }
};

export const MindMapGenerator: React.FC<MindMapGeneratorProps> = ({ onOpenChatWithPrompt }) => {
  const [topicInput, setTopicInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [currentMindMap, setCurrentMindMap] = useState<MindMapData>(PRESET_MINDMAPS['Photosynthesis']);
  const [collapsedNodes, setCollapsedNodes] = useState<Record<string, boolean>>({});
  const [selectedNodeDetails, setSelectedNodeDetails] = useState<MindMapNode | null>(null);
  const [copiedMap, setCopiedMap] = useState(false);
  const [viewMode, setViewMode] = useState<'tree' | 'compact'>('tree');

  const toggleNodeCollapse = (id: string) => {
    setCollapsedNodes((prev) => ({ ...prev, [id]: !prev[id] }));
  };

  const expandAllNodes = () => {
    setCollapsedNodes({});
  };

  const collapseAllNodes = () => {
    const collapsed: Record<string, boolean> = {};
    if (currentMindMap?.nodes) {
      currentMindMap.nodes.forEach((n) => {
        collapsed[n.id] = true;
      });
    }
    setCollapsedNodes(collapsed);
  };

  const handleGenerateMindMap = async (customTopic?: string) => {
    const topicToUse = customTopic || topicInput;
    if (!topicToUse.trim()) return;

    setIsLoading(true);
    setSelectedNodeDetails(null);

    // Check if preset exists
    const matchKey = Object.keys(PRESET_MINDMAPS).find(
      (k) => k.toLowerCase() === topicToUse.toLowerCase().trim()
    );

    if (matchKey) {
      setTimeout(() => {
        setCurrentMindMap(PRESET_MINDMAPS[matchKey]);
        setCollapsedNodes({});
        setIsLoading(false);
        if (!customTopic) setTopicInput('');
      }, 500);
      return;
    }

    try {
      const response = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: `Generate a structured mind map for the topic: "${topicToUse}". Output ONLY valid JSON in this exact structure without markdown backticks:
{
  "topic": "${topicToUse}",
  "summary": "Brief 1-sentence overview",
  "nodes": [
    {
      "id": "1",
      "title": "Main Category 1",
      "color": "border-red-500/50 bg-red-950/20 text-red-300",
      "details": "Explanation of category 1",
      "children": [
        { "id": "1-1", "title": "Subtopic A", "details": "Detail for A" },
        { "id": "1-2", "title": "Subtopic B", "details": "Detail for B" }
      ]
    },
    {
      "id": "2",
      "title": "Main Category 2",
      "color": "border-amber-500/50 bg-amber-950/20 text-amber-300",
      "details": "Explanation of category 2",
      "children": [
        { "id": "2-1", "title": "Subtopic C", "details": "Detail for C" }
      ]
    },
    {
      "id": "3",
      "title": "Main Category 3",
      "color": "border-emerald-500/50 bg-emerald-950/20 text-emerald-300",
      "details": "Explanation of category 3",
      "children": [
        { "id": "3-1", "title": "Subtopic D", "details": "Detail for D" }
      ]
    }
  ]
}`,
          systemInstruction:
            'You are a Mind Map JSON Generator. Respond strictly with raw valid JSON matchable to the requested schema. No conversational preamble.',
        }),
      });

      if (!response.ok) throw new Error('API failed');

      const data = await response.json();
      const rawText = data.text || '';

      // Clean JSON text
      const cleanedJson = rawText.replace(/```json/g, '').replace(/```/g, '').trim();
      const parsed: MindMapData = JSON.parse(cleanedJson);

      if (parsed && parsed.nodes) {
        setCurrentMindMap(parsed);
        setCollapsedNodes({});
      } else {
        throw new Error('Invalid structure');
      }
    } catch (err) {
      // Fallback structured generation
      setCurrentMindMap({
        topic: topicToUse,
        summary: `Mind map concept map generated for ${topicToUse}.`,
        nodes: [
          {
            id: 'm1',
            title: 'Core Fundamentals',
            color: 'border-red-500/50 bg-red-950/20 text-red-300',
            details: `Essential definitions and foundational principles of ${topicToUse}.`,
            children: [
              { id: 'm1-1', title: 'Key Definitions', details: 'Basic terminologies and primary scope' },
              { id: 'm1-2', title: 'Historical Context', details: 'Origins and primary milestones' }
            ]
          },
          {
            id: 'm2',
            title: 'Primary Components & Mechanisms',
            color: 'border-amber-500/50 bg-amber-950/20 text-amber-300',
            details: `How ${topicToUse} functions step by step.`,
            children: [
              { id: 'm2-1', title: 'Working Mechanism', details: 'Processes and sequential steps' },
              { id: 'm2-2', title: 'Core Variables', details: 'Key factors influencing the system' }
            ]
          },
          {
            id: 'm3',
            title: 'Real-World Applications & Impact',
            color: 'border-emerald-500/50 bg-emerald-950/20 text-emerald-300',
            details: `Practical uses and significance in exams and daily life.`,
            children: [
              { id: 'm3-1', title: 'Practical Examples', details: 'Case studies and real-life scenarios' },
              { id: 'm3-2', title: 'Exam Focus Points', details: 'Frequently asked questions & key formulas' }
            ]
          }
        ]
      });
      setCollapsedNodes({});
    } finally {
      setIsLoading(false);
      if (!customTopic) setTopicInput('');
    }
  };

  const copyMindMapAsText = () => {
    if (!currentMindMap) return;
    let text = `🧠 MIND MAP: ${currentMindMap.topic}\nSummary: ${currentMindMap.summary || ''}\n\n`;
    currentMindMap.nodes.forEach((n, idx) => {
      text += `[${idx + 1}] ${n.title}\n`;
      if (n.details) text += `    • Note: ${n.details}\n`;
      if (n.children) {
        n.children.forEach((c) => {
          text += `    ├── ${c.title}${c.details ? `: ${c.details}` : ''}\n`;
        });
      }
      text += '\n';
    });

    navigator.clipboard.writeText(text);
    setCopiedMap(true);
    setTimeout(() => setCopiedMap(false), 2000);
  };

  const downloadMindMapJson = () => {
    if (!currentMindMap) return;
    const blob = new Blob([JSON.stringify(currentMindMap, null, 2)], { type: 'application/json' });
    const url = URL.revokeObjectURL ? URL.createObjectURL(blob) : '';
    const a = document.createElement('a');
    a.href = url;
    a.download = `mindmap-${currentMindMap.topic.toLowerCase().replace(/\s+/g, '-')}.json`;
    a.click();
  };

  return (
    <div id="mindmap-generator" className="p-6 sm:p-8 rounded-3xl bg-zinc-900 border border-zinc-800 mb-10 shadow-xl relative overflow-hidden">
      {/* Background Subtle Accent */}
      <div className="absolute -top-12 -right-12 w-80 h-80 bg-red-600/10 rounded-full blur-3xl pointer-events-none" />

      {/* Section Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-6 mb-6 border-b border-zinc-800">
        <div>
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full border border-red-500/30 bg-red-950/40 text-red-400 text-xs font-bold mb-2">
            <Network className="w-3.5 h-3.5 text-red-500" />
            <span>Visual Concept Mapping Engine</span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-extrabold text-white">
            Interactive AI Mind Map Generator
          </h2>
          <p className="text-xs sm:text-sm text-zinc-400 mt-1 font-medium">
            Turn any complex topic into a clean, collapsible visual concept tree for fast revision.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={expandAllNodes}
            className="px-3 py-1.5 rounded-xl border border-zinc-800 bg-zinc-950 hover:bg-zinc-800 text-zinc-300 text-xs font-semibold transition-colors flex items-center gap-1 cursor-pointer"
          >
            <PlusCircle className="w-3.5 h-3.5 text-emerald-400" />
            <span>Expand All</span>
          </button>
          <button
            type="button"
            onClick={collapseAllNodes}
            className="px-3 py-1.5 rounded-xl border border-zinc-800 bg-zinc-950 hover:bg-zinc-800 text-zinc-300 text-xs font-semibold transition-colors flex items-center gap-1 cursor-pointer"
          >
            <MinusCircle className="w-3.5 h-3.5 text-red-400" />
            <span>Collapse All</span>
          </button>
          <button
            type="button"
            onClick={copyMindMapAsText}
            className="px-3 py-1.5 rounded-xl border border-zinc-800 bg-zinc-950 hover:bg-zinc-800 text-red-400 text-xs font-bold transition-colors flex items-center gap-1 cursor-pointer"
          >
            {copiedMap ? <Check className="w-3.5 h-3.5 text-emerald-500" /> : <Copy className="w-3.5 h-3.5" />}
            <span>{copiedMap ? 'Copied' : 'Copy Text'}</span>
          </button>
        </div>
      </div>

      {/* Input Bar */}
      <form
        onSubmit={(e) => {
          e.preventDefault();
          handleGenerateMindMap();
        }}
        className="mb-6"
      >
        <div className="flex flex-col sm:flex-row items-center gap-3">
          <div className="relative flex-1 w-full">
            <input
              type="text"
              value={topicInput}
              onChange={(e) => setTopicInput(e.target.value)}
              placeholder="Type any subject topic (e.g., Photosynthesis, Indian Constitution, Newton Laws, Microeconomics)..."
              className="w-full px-4 py-3.5 rounded-2xl bg-zinc-950 border border-zinc-800 text-xs sm:text-sm font-semibold text-white placeholder-zinc-500 focus:outline-none focus:border-red-500 transition-all"
            />
          </div>

          <button
            type="submit"
            disabled={!topicInput.trim() || isLoading}
            className="w-full sm:w-auto px-6 py-3.5 rounded-2xl bg-red-600 hover:bg-red-500 text-white text-xs font-extrabold transition-all disabled:opacity-40 disabled:cursor-not-allowed shadow-md shadow-red-600/30 flex items-center justify-center gap-2 cursor-pointer shrink-0"
          >
            {isLoading ? (
              <RefreshCw className="w-4 h-4 animate-spin" />
            ) : (
              <Sparkles className="w-4 h-4" />
            )}
            <span>{isLoading ? 'Building Mind Map...' : 'Generate Mind Map'}</span>
          </button>
        </div>
      </form>

      {/* Preset Topic Quick Chips */}
      <div className="mb-8 flex flex-wrap items-center gap-2">
        <span className="text-[11px] font-mono font-bold text-zinc-500 uppercase tracking-wider mr-1">
          Quick Presets:
        </span>
        {Object.keys(PRESET_MINDMAPS).map((presetKey) => (
          <button
            key={presetKey}
            type="button"
            onClick={() => handleGenerateMindMap(presetKey)}
            className="px-3 py-1 rounded-xl border border-zinc-800 bg-zinc-950 hover:border-red-500/50 hover:bg-zinc-800 text-zinc-300 text-xs font-semibold transition-all cursor-pointer flex items-center gap-1.5"
          >
            <Network className="w-3 h-3 text-red-500" />
            <span>{presetKey}</span>
          </button>
        ))}
      </div>

      {/* VISUAL MIND MAP CANVAS AREA */}
      <div className="p-6 sm:p-8 rounded-2xl bg-zinc-950 border border-zinc-800/80 relative">
        {/* Central Root Node */}
        <div className="flex flex-col items-center text-center mb-10">
          <div className="p-4 sm:p-5 rounded-2xl bg-gradient-to-r from-red-600 to-rose-600 text-white font-black text-base sm:text-xl shadow-lg shadow-red-600/20 max-w-md w-full border border-red-400/30 relative">
            <div className="flex items-center justify-center gap-2 mb-1">
              <Network className="w-5 h-5 text-white" />
              <span>{currentMindMap.topic}</span>
            </div>
            {currentMindMap.summary && (
              <p className="text-xs text-red-100 font-medium leading-relaxed opacity-90 mt-1">
                {currentMindMap.summary}
              </p>
            )}
          </div>
          {/* Connector stem */}
          <div className="w-0.5 h-8 bg-gradient-to-b from-red-500 to-zinc-700 my-1" />
        </div>

        {/* Level 1 Nodes & Children Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 relative">
          {currentMindMap.nodes.map((node, index) => {
            const isCollapsed = collapsedNodes[node.id];
            const colorClass =
              node.color ||
              (index === 0
                ? 'border-red-500/50 bg-red-950/20 text-red-300'
                : index === 1
                ? 'border-amber-500/50 bg-amber-950/20 text-amber-300'
                : 'border-emerald-500/50 bg-emerald-950/20 text-emerald-300');

            return (
              <div
                key={node.id}
                className="flex flex-col rounded-2xl border border-zinc-800 bg-zinc-900/80 p-4 transition-all hover:border-zinc-700 shadow-sm"
              >
                {/* Node Header */}
                <div className={`p-3 rounded-xl border ${colorClass} mb-3`}>
                  <div className="flex items-center justify-between gap-2">
                    <div className="font-extrabold text-xs sm:text-sm flex items-center gap-1.5">
                      <span className="w-2 h-2 rounded-full bg-current" />
                      <span>{node.title}</span>
                    </div>

                    <button
                      type="button"
                      onClick={() => toggleNodeCollapse(node.id)}
                      className="p-1 rounded-lg hover:bg-black/30 transition-colors text-current cursor-pointer"
                      title={isCollapsed ? 'Expand branches' : 'Collapse branches'}
                    >
                      {isCollapsed ? <ChevronRight className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                    </button>
                  </div>

                  {node.details && (
                    <p className="text-[11px] text-zinc-300/90 mt-1.5 font-medium leading-normal">
                      {node.details}
                    </p>
                  )}
                </div>

                {/* Sub-branches / Children */}
                {!isCollapsed && node.children && node.children.length > 0 && (
                  <div className="pl-2 space-y-2 border-l-2 border-zinc-800 ml-2 mt-1">
                    {node.children.map((child) => (
                      <div
                        key={child.id}
                        onClick={() => {
                          if (onOpenChatWithPrompt) {
                            onOpenChatWithPrompt(
                              `Explain "${child.title}" in detail with key points and examples for the topic ${currentMindMap.topic}.`
                            );
                          } else {
                            setSelectedNodeDetails(child);
                          }
                        }}
                        className="p-2.5 rounded-xl bg-zinc-950 border border-zinc-800/80 hover:border-red-500/40 hover:bg-zinc-900 transition-all cursor-pointer group flex flex-col"
                      >
                        <div className="flex items-center justify-between">
                          <span className="text-xs font-bold text-zinc-200 group-hover:text-red-400 transition-colors">
                            {child.title}
                          </span>
                          <ArrowRight className="w-3 h-3 text-zinc-600 group-hover:text-red-400 group-hover:translate-x-0.5 transition-all" />
                        </div>
                        {child.details && (
                          <span className="text-[11px] text-zinc-400 leading-snug mt-1 font-medium">
                            {child.details}
                          </span>
                        )}
                      </div>
                    ))}
                  </div>
                )}

                {/* Ask AI Tutor about this branch */}
                {onOpenChatWithPrompt && (
                  <button
                    type="button"
                    onClick={() =>
                      onOpenChatWithPrompt(
                        `Give me a complete study note and practice questions on the branch "${node.title}" for ${currentMindMap.topic}.`
                      )
                    }
                    className="mt-4 pt-2.5 border-t border-zinc-800/80 text-[11px] font-bold text-red-400 hover:text-red-300 flex items-center justify-center gap-1.5 cursor-pointer w-full text-center"
                  >
                    <BookOpen className="w-3 h-3" />
                    <span>Deep Dive on Branch with AI</span>
                  </button>
                )}
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
