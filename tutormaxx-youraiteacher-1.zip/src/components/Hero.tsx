import React, { useState } from 'react';
import { Send, GraduationCap, Terminal, BookOpen, Calculator, Atom } from 'lucide-react';

interface HeroProps {
  onOpenChat: (initialPrompt?: string) => void;
}

export const Hero: React.FC<HeroProps> = ({ onOpenChat }) => {
  const [heroPrompt, setHeroPrompt] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (heroPrompt.trim()) {
      onOpenChat(heroPrompt.trim());
      setHeroPrompt('');
    } else {
      onOpenChat();
    }
  };

  return (
    <section className="relative py-12 lg:py-16 bg-zinc-950 text-zinc-100 border-b border-zinc-800 red-grid">
      <div className="max-w-5xl mx-auto px-4 sm:px-6">
        <div className="flex flex-col items-center text-center max-w-3xl mx-auto">
          {/* Badge */}
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full border border-red-500/30 bg-red-950/40 text-red-400 text-xs font-bold mb-5">
            <GraduationCap className="w-4 h-4 text-red-500" />
            <span>Tutormaxx Student Project</span>
          </div>

          {/* Heading */}
          <h1 className="text-3xl sm:text-5xl font-extrabold tracking-tight mb-4 text-white">
            Simple AI Homework Assistant
          </h1>

          {/* Subtext */}
          <p className="text-xs sm:text-sm text-zinc-400 max-w-xl leading-relaxed mb-8">
            A minimalist AI tutor built for students. Select a subject below or type a homework question to get instant step-by-step guidance.
          </p>

          {/* Input Box */}
          <form onSubmit={handleSubmit} className="w-full max-w-xl mb-6">
            <div className="p-2 rounded-xl bg-zinc-900 border border-zinc-800 focus-within:border-red-500 focus-within:ring-1 focus-within:ring-red-500/30 transition-all flex items-center gap-2">
              <div className="pl-3 text-red-500">
                <Terminal className="w-4 h-4" />
              </div>
              <input
                type="text"
                value={heroPrompt}
                onChange={(e) => setHeroPrompt(e.target.value)}
                placeholder="Ask any homework question..."
                className="flex-1 bg-transparent text-xs sm:text-sm font-medium focus:outline-none placeholder-zinc-500 px-2 py-2 text-white"
              />
              <button
                type="submit"
                className="px-5 py-2.5 rounded-lg bg-red-600 hover:bg-red-500 text-white text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5 shrink-0"
              >
                <span>Ask AI</span>
                <Send className="w-3.5 h-3.5" />
              </button>
            </div>
          </form>

          {/* Quick Buttons */}
          <div className="flex flex-wrap items-center justify-center gap-2 text-xs text-zinc-400">
            <span className="font-semibold text-zinc-300 mr-1">Quick prompts:</span>
            <a
              href="#exam-active-recall-studio"
              className="px-3 py-1 rounded-lg border border-red-500/40 bg-red-950/60 hover:bg-red-900/60 text-red-300 text-[11px] font-extrabold transition-colors cursor-pointer flex items-center gap-1 shadow-sm"
            >
              <GraduationCap className="w-3.5 h-3.5 text-red-400" />
              <span>🎯 Exam & Active Recall Studio</span>
            </a>
            <button
              type="button"
              onClick={() => onOpenChat('Practice Tamil grammar and vocabulary.')}
              className="px-3 py-1 rounded-lg border border-zinc-800 bg-zinc-900 hover:border-red-500/50 hover:bg-zinc-800 text-zinc-300 text-[11px] font-medium transition-colors cursor-pointer flex items-center gap-1"
            >
              <BookOpen className="w-3 h-3 text-red-400" />
              <span>Tamil Practice</span>
            </button>
            <button
              type="button"
              onClick={() => onOpenChat('Practice Hindi sentence structure and grammar.')}
              className="px-3 py-1 rounded-lg border border-zinc-800 bg-zinc-900 hover:border-red-500/50 hover:bg-zinc-800 text-zinc-300 text-[11px] font-medium transition-colors cursor-pointer flex items-center gap-1"
            >
              <BookOpen className="w-3 h-3 text-red-400" />
              <span>Hindi Practice</span>
            </button>
            <button
              type="button"
              onClick={() => onOpenChat('Solve and explain: 2x + 15 = 45 step by step.')}
              className="px-3 py-1 rounded-lg border border-zinc-800 bg-zinc-900 hover:border-red-500/50 hover:bg-zinc-800 text-zinc-300 text-[11px] font-medium transition-colors cursor-pointer flex items-center gap-1"
            >
              <Calculator className="w-3 h-3 text-red-400" />
              <span>Algebra Solver</span>
            </button>
          </div>
        </div>
      </div>
    </section>
  );
};




