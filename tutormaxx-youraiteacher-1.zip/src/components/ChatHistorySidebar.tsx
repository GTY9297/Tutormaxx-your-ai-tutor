import React, { useState } from 'react';
import { ChatSession } from '../types';
import { Plus, MessageSquare, Trash2, Search, Sparkles, ChevronRight, X } from 'lucide-react';

interface ChatHistorySidebarProps {
  sessions: ChatSession[];
  activeSessionId: string;
  onSelectSession: (id: string) => void;
  onNewSession: () => void;
  onDeleteSession: (id: string) => void;
  onClearAllHistory: () => void;
  isMobileOpen: boolean;
  onCloseMobile: () => void;
}

export const ChatHistorySidebar: React.FC<ChatHistorySidebarProps> = ({
  sessions,
  activeSessionId,
  onSelectSession,
  onNewSession,
  onDeleteSession,
  onClearAllHistory,
  isMobileOpen,
  onCloseMobile,
}) => {
  const [searchTerm, setSearchTerm] = useState('');

  const filteredSessions = sessions.filter(
    (s) =>
      s.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      s.messages.some((m) => m.content.toLowerCase().includes(searchTerm.toLowerCase()))
  );

  const sidebarContent = (
    <div className="flex flex-col h-full bg-zinc-950 border-r border-zinc-800 text-zinc-100">
      {/* Sidebar Header */}
      <div className="p-4 border-b border-zinc-800 bg-zinc-900/80 flex flex-col gap-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-red-500" />
            <span className="font-extrabold text-xs uppercase tracking-wider text-white">
              Thread Memory
            </span>
          </div>
          <span className="px-2 py-0.5 rounded-full border border-red-500/30 text-[10px] font-mono font-bold text-red-400 bg-red-950/40">
            {sessions.length} Active
          </span>
        </div>

        {/* New Chat CTA Button */}
        <button
          onClick={onNewSession}
          className="w-full py-2.5 px-3 rounded-xl bg-red-600 hover:bg-red-500 text-white text-xs font-bold transition-all shadow-md shadow-red-600/30 cursor-pointer flex items-center justify-center gap-2 active:scale-98"
        >
          <Plus className="w-4 h-4" />
          <span>New Chat Thread</span>
        </button>

        {/* Search Bar */}
        <div className="relative mt-1">
          <Search className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-zinc-500" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Search threads..."
            className="w-full pl-9 pr-3 py-1.5 rounded-lg bg-zinc-950 border border-zinc-800 text-xs font-semibold focus:outline-none focus:border-red-500 text-white placeholder-zinc-500"
          />
        </div>
      </div>

      {/* History Thread List */}
      <div className="flex-1 overflow-y-auto p-3 space-y-2">
        {filteredSessions.length === 0 ? (
          <div className="p-6 text-center text-zinc-500 text-xs font-medium border border-dashed border-zinc-800 rounded-xl my-4">
            No saved threads found
          </div>
        ) : (
          filteredSessions.map((session) => {
            const isActive = session.id === activeSessionId;
            const lastMsg = session.messages[session.messages.length - 1];
            const msgCount = session.messages.length;

            return (
              <div
                key={session.id}
                onClick={() => {
                  onSelectSession(session.id);
                  onCloseMobile();
                }}
                className={`group relative p-3 rounded-xl border transition-all cursor-pointer flex flex-col justify-between ${
                  isActive
                    ? 'bg-red-950/40 border-red-500/60 text-white'
                    : 'bg-zinc-900/60 border-zinc-800 text-zinc-300 hover:bg-zinc-800/80 hover:border-zinc-700'
                }`}
              >
                <div className="flex items-start justify-between gap-2">
                  <div className="flex items-center gap-2 min-w-0">
                    <MessageSquare
                      className={`w-3.5 h-3.5 shrink-0 ${
                        isActive ? 'text-red-400' : 'text-zinc-500'
                      }`}
                    />
                    <span
                      className={`text-xs font-extrabold truncate ${
                        isActive ? 'text-white' : 'text-zinc-200'
                      }`}
                    >
                      {session.title || 'Untitled Session'}
                    </span>
                  </div>

                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      onDeleteSession(session.id);
                    }}
                    title="Delete thread"
                    className="p-1 opacity-0 group-hover:opacity-100 transition-opacity cursor-pointer hover:text-red-400 text-zinc-500"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>

                <div className="mt-2 flex items-center justify-between text-[10px] font-mono text-zinc-500">
                  <span className="truncate max-w-[140px] font-medium">
                    {lastMsg ? lastMsg.content.slice(0, 30) + '...' : 'Empty prompt'}
                  </span>
                  <span
                    className={`px-1.5 py-0.5 rounded border text-[9px] font-mono font-bold ${
                      isActive
                        ? 'border-red-500/40 bg-red-950/60 text-red-300'
                        : 'border-zinc-800 bg-zinc-950 text-zinc-500'
                    }`}
                  >
                    {msgCount} msgs
                  </span>
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* Sidebar Footer */}
      {sessions.length > 0 && (
        <div className="p-3 border-t border-zinc-800 bg-zinc-900/80">
          <button
            onClick={onClearAllHistory}
            className="w-full py-2 px-3 rounded-lg border border-zinc-800 hover:border-red-600/50 text-zinc-400 hover:text-red-400 text-xs font-semibold transition-colors cursor-pointer flex items-center justify-center gap-1.5"
          >
            <Trash2 className="w-3.5 h-3.5" />
            <span>Clear Thread History</span>
          </button>
        </div>
      )}
    </div>
  );

  return (
    <>
      {/* Desktop Persistent Left History Sidebar */}
      <aside className="hidden lg:block w-72 shrink-0 h-[calc(100vh-4rem)] sticky top-16 z-20">
        {sidebarContent}
      </aside>

      {/* Mobile Drawer Overlay */}
      {isMobileOpen && (
        <div className="lg:hidden fixed inset-0 z-50 flex">
          <div
            className="fixed inset-0 bg-slate-950/80 backdrop-blur-md"
            onClick={onCloseMobile}
          />
          <div className="relative w-80 max-w-[85vw] h-full z-10">
            {sidebarContent}
          </div>
        </div>
      )}
    </>
  );
};

