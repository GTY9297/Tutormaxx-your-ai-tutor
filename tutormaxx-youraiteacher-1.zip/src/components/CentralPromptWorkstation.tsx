import React, { useState, useRef, useEffect } from 'react';
import { PRESET_PROMPTS } from '../data';
import { ChatMessage } from '../types';
import {
  Send,
  Sparkles,
  Copy,
  Check,
  Code2,
  Terminal,
  RotateCcw,
  History,
  MessageSquare,
  Cpu,
  Layers,
  ArrowRight,
  Mic,
  MicOff,
  Volume2,
  VolumeX,
  Download,
  Sliders,
  ShieldAlert,
  FileText,
  Workflow,
  Zap,
  BookOpen,
  Calculator,
  Atom,
  Globe,
  BrainCircuit,
  HeartHandshake,
  GraduationCap,
  Award,
  HelpCircle,
  Lightbulb,
  Network,
  Minimize2,
  Maximize2,
  ChevronDown,
  ChevronUp,
} from 'lucide-react';
import { MindMapGenerator } from './MindMapGenerator';

interface CentralPromptWorkstationProps {
  messages: ChatMessage[];
  isLoading: boolean;
  onSendMessage: (
    prompt: string,
    mode?: string,
    temperature?: number,
    customInstruction?: string
  ) => void;
  onToggleMobileHistory: () => void;
  onClearCurrentThread: () => void;
  activeSessionTitle: string;
}

export type SubjectTab =
  | 'languages'
  | 'maths'
  | 'science'
  | 'social'
  | 'gk'
  | 'cs'
  | 'mindmap';

export const CentralPromptWorkstation: React.FC<CentralPromptWorkstationProps> = ({
  messages,
  isLoading,
  onSendMessage,
  onToggleMobileHistory,
  onClearCurrentThread,
  activeSessionTitle,
}) => {
  const [promptText, setPromptText] = useState('');
  const [activeSubject, setActiveSubject] = useState<SubjectTab>('languages');
  const [temperature, setTemperature] = useState<number>(0.7);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [isRecording, setIsRecording] = useState(false);
  const [speakingMsgId, setSpeakingMsgId] = useState<string | null>(null);

  // Subject-Specific Tool Input States
  const [langInput, setLangInput] = useState('');
  const [langTool, setLangTool] = useState('Essay Helper');

  const [mathInput, setMathInput] = useState('');
  const [mathTool, setMathTool] = useState('Step-by-Step Solver');

  const [scienceInput, setScienceInput] = useState('');
  const [scienceTopic, setScienceTopic] = useState('Physics Concept');

  const [socialInput, setSocialInput] = useState('');
  const [socialCategory, setSocialCategory] = useState('History Timeline');

  const [gkCategory, setGkCategory] = useState('World Quiz');

  const [csCode, setCsCode] = useState('');
  const [csTask, setCsTask] = useState('Explain Code');

  const [skillCategory, setSkillCategory] = useState('Classroom Manners & Rules');

  const [isTeacherMode, setIsTeacherMode] = useState(false);
  const [teacherTopicInput, setTeacherTopicInput] = useState('');

  const [isSimpleMode, setIsSimpleMode] = useState(false);
  const [simpleTopicInput, setSimpleTopicInput] = useState('');

  // Expand / Collapse Answer State for Long Messages
  const [expandedMsgIds, setExpandedMsgIds] = useState<Record<string, boolean>>({});
  const [globalCollapsed, setGlobalCollapsed] = useState(false);

  const toggleMsgExpand = (id: string) => {
    setExpandedMsgIds((prev) => ({
      ...prev,
      [id]: !prev[id],
    }));
  };

  const handleShortenAnswer = (msgContent: string) => {
    const shortenPrompt = `[SHORTEN RESPONSE]\n\nPlease summarize this explanation into a concise 3-bullet summary under 50 words:\n\n"${msgContent.slice(0, 1000)}"`;
    onSendMessage(
      shortenPrompt,
      'Shorten Mode',
      0.3,
      'You are Tutormaxx. Summarize the provided explanation into 3 concise bullet points under 50 words. Be super fast to read.'
    );
  };

  const TEACHER_MODE_INSTRUCTION = `You are Tutormaxx acting in TEACHER MODE. Provide a brief, highly structured, bite-sized teacher explanation for the provided topic or question.
Strict response structure to follow:
1. 💡 **Core Summary** (1-2 clear, simple sentences)
2. 📌 **Key Points** (3-4 concise bullet points highlighting essential takeaways)
3. 🏫 **Real-World Analogy / Example** (1 short paragraph)
4. ❓ **Quick Self-Check Question** (1 sentence to test understanding)

Keep explanations brief, highly engaging, and easy to retain.`;

  const SIMPLE_MODE_INSTRUCTION = `You are Tutormaxx acting in SIMPLE MODE (ELI5 - Explain Like I'm 5).
Your mission is to take tough, complex, or intimidating questions and explain them in super simple, crystal-clear, everyday plain language that anyone can easily understand.

Strict response structure to follow:
1. 🎈 **The Everyday Analogy** (Use a relatable real-world metaphor like LEGO bricks, pizza slices, playground games, or traffic lights).
2. 🧩 **Step-by-Step Breakdown** (3 ultra-simple steps using plain English with zero confusing technical jargon).
3. 💡 **Easy Takeaway** (1 short sentence summarizing the core idea in plain words).

Avoid dense academic jargon, complex formulas without plain explanations, or overly technical language. Focus on clarity, warmth, and simplicity.`;

  const handleExecuteTeacherMode = (topicToUse?: string) => {
    const topic = topicToUse || teacherTopicInput;
    if (!topic.trim() || isLoading) return;

    const prompt = `[TEACHER MODE BRIEF EXPLANATION]\n\nPlease provide a brief teacher explanation for the topic: "${topic.trim()}"`;
    onSendMessage(prompt, 'Teacher Mode', 0.5, TEACHER_MODE_INSTRUCTION);
    if (!topicToUse) setTeacherTopicInput('');
  };

  const handleExecuteSimpleMode = (topicToUse?: string) => {
    const topic = topicToUse || simpleTopicInput;
    if (!topic.trim() || isLoading) return;

    const prompt = `[SIMPLE MODE EASY EXPLANATION]\n\nPlease explain this complex problem/topic simply in easy-to-understand words: "${topic.trim()}"`;
    onSendMessage(prompt, 'Simple Mode', 0.4, SIMPLE_MODE_INSTRUCTION);
    if (!topicToUse) setSimpleTopicInput('');
  };

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const recognitionRef = useRef<any>(null);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isLoading]);

  // Handle Speech Recognition (Voice Dictation)
  const toggleVoiceRecording = () => {
    if (isRecording) {
      if (recognitionRef.current) recognitionRef.current.stop();
      setIsRecording(false);
      return;
    }

    const SpeechRecognition =
      (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;

    if (!SpeechRecognition) {
      alert('Speech Recognition is not supported in this browser version.');
      return;
    }

    try {
      const recognition = new SpeechRecognition();
      recognition.continuous = false;
      recognition.interimResults = false;
      recognition.lang = 'en-US';

      recognition.onstart = () => setIsRecording(true);
      recognition.onresult = (event: any) => {
        const transcript = event.results[0][0].transcript;
        if (transcript) {
          setPromptText((prev) => (prev ? `${prev} ${transcript}` : transcript));
        }
      };
      recognition.onerror = () => setIsRecording(false);
      recognition.onend = () => setIsRecording(false);

      recognitionRef.current = recognition;
      recognition.start();
    } catch (e) {
      console.error('Failed to start speech recognition:', e);
      setIsRecording(false);
    }
  };

  // Handle Text-To-Speech (TTS)
  const toggleTextToSpeech = (msgId: string, text: string) => {
    if (!('speechSynthesis' in window)) {
      alert('Text-To-Speech is not supported in your browser.');
      return;
    }

    if (speakingMsgId === msgId) {
      window.speechSynthesis.cancel();
      setSpeakingMsgId(null);
      return;
    }

    window.speechSynthesis.cancel();
    const cleanText = text.replace(/[*_#`~]/g, '');
    const utterance = new SpeechSynthesisUtterance(cleanText);
    utterance.rate = 1.0;
    utterance.onend = () => setSpeakingMsgId(null);
    utterance.onerror = () => setSpeakingMsgId(null);

    setSpeakingMsgId(msgId);
    window.speechSynthesis.speak(utterance);
  };

  // Export Thread File
  const exportThread = (format: 'markdown' | 'json') => {
    if (messages.length === 0) return;

    let content = '';
    let mimeType = 'text/plain';
    let extension = 'txt';

    if (format === 'markdown') {
      mimeType = 'text/markdown';
      extension = 'md';
      content = `# Tutormaxx Study Thread: ${activeSessionTitle}\n\nExported on: ${new Date().toLocaleString()}\n\n---\n\n`;
      messages.forEach((m) => {
        content += `### ${m.role === 'user' ? '👤 Student' : '🎓 Tutormaxx AI'} (${m.timestamp})\n\n${m.content}\n\n---\n\n`;
      });
    } else {
      mimeType = 'application/json';
      extension = 'json';
      content = JSON.stringify(
        {
          title: activeSessionTitle,
          exportedAt: new Date().toISOString(),
          messages,
        },
        null,
        2
      );
    }

    const blob = new Blob([content], { type: mimeType });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `tutormaxx-study-notes-${Date.now()}.${extension}`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const subjectTabsConfig: { id: SubjectTab; label: string; icon: any; color: string }[] = [
    { id: 'languages', label: 'Languages', icon: BookOpen, color: 'text-indigo-400' },
    { id: 'maths', label: 'Maths', icon: Calculator, color: 'text-emerald-400' },
    { id: 'science', label: 'Science', icon: Atom, color: 'text-purple-400' },
    { id: 'social', label: 'Social Studies', icon: Globe, color: 'text-amber-400' },
    { id: 'gk', label: 'General Knowledge', icon: BrainCircuit, color: 'text-pink-400' },
    { id: 'cs', label: 'Computer Science', icon: Code2, color: 'text-cyan-400' },
    { id: 'mindmap', label: 'Mind Map Generator', icon: Network, color: 'text-rose-400' },
  ];

  const handleSubmit = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!promptText.trim() || isLoading) return;

    if (isSimpleMode) {
      onSendMessage(promptText, 'Simple Mode', 0.4, SIMPLE_MODE_INSTRUCTION);
    } else if (isTeacherMode) {
      onSendMessage(promptText, 'Teacher Mode', 0.5, TEACHER_MODE_INSTRUCTION);
    } else {
      onSendMessage(promptText, activeSubject, temperature);
    }
    setPromptText('');
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSubmit();
    }
  };

  const copyToClipboard = (id: string, text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  // Subject Tool Handlers
  const handleExecuteLanguages = () => {
    if (!langInput.trim()) return;
    let customInst =
      'You are Tutormaxx Language Specialist. Help students write better essays, correct grammar, enhance vocabulary, and practice foreign and regional languages cleanly.';
    if (langTool === 'Tamil Practice') {
      customInst =
        'You are Tutormaxx Tamil Language & Literature Specialist. Help students learn Tamil (தமிழ்), practice grammar, sentence building, vocabulary, literary concepts, and offer Tamil script along with clear English transliteration and translation.';
    } else if (langTool === 'Hindi Practice') {
      customInst =
        'You are Tutormaxx Hindi Language Specialist. Help students learn Hindi (हिंदी), practice grammar (व्याकरण), vocabulary (शब्दावली), essay writing, and offer Devanagari script along with clear English transliteration and translation.';
    }

    const prompt = `[Language Tutor - ${langTool}]\n\nPlease assist with the following task:\n"${langInput}"\n\nProvide clear feedback, vocabulary suggestions, and polished structure.`;
    onSendMessage(prompt, 'Languages', 0.6, customInst);
    setLangInput('');
  };

  const handleExecuteMaths = () => {
    if (!mathInput.trim()) return;
    const prompt = `[Math Tutor - ${mathTool}]\n\nPlease solve and explain step-by-step:\n"${mathInput}"\n\nFormat requirements:\n1. Key Concepts / Formulas\n2. Step-by-Step Breakdown\n3. Final Answer\n4. Practice Quiz Question for reinforcement`;
    onSendMessage(
      prompt,
      'Maths',
      0.2,
      'You are Tutormaxx Math Genius. Always break down equations step-by-step with simple algebraic or geometric reasoning so the student learns the method.'
    );
    setMathInput('');
  };

  const handleExecuteScience = () => {
    if (!scienceInput.trim()) return;
    const prompt = `[Science Tutor - ${scienceTopic}]\n\nExplain or solve:\n"${scienceInput}"\n\nProvide:\n- Clear definition\n- Real-world analogy\n- Key scientific formulas or laws\n- Why it matters in everyday life`;
    onSendMessage(
      prompt,
      'Science',
      0.4,
      'You are Tutormaxx Science Mentor. Explain physics, chemistry, biology, and environmental science with engaging analogies and accurate scientific facts.'
    );
    setScienceInput('');
  };

  const handleExecuteSocial = () => {
    if (!socialInput.trim()) return;
    const prompt = `[Social Studies Tutor - ${socialCategory}]\n\nExplain or summarize:\n"${socialInput}"\n\nInclude:\n- Key Historical/Geographical Context\n- Important Dates / Maps / Figures\n- Primary Causes & Consequences\n- Summary in 3 bullet points`;
    onSendMessage(
      prompt,
      'Social Studies',
      0.5,
      'You are Tutormaxx Social Studies Expert. Teach History, Geography, Civics, and Economics in a memorable story-driven and structured manner.'
    );
    setSocialInput('');
  };

  const handleExecuteGK = () => {
    const prompt = `[General Knowledge Quizmaster - ${gkCategory}]\n\nGenerate a fun 5-question trivia quiz with multiple choices (A, B, C, D) covering ${gkCategory}. Place the answer key at the very bottom with quick explanations for each answer.`;
    onSendMessage(
      prompt,
      'General Knowledge',
      0.7,
      'You are Tutormaxx Quizmaster. Generate high-quality world facts, trivia, and engaging educational quizzes for students.'
    );
  };

  const handleExecuteCS = () => {
    if (!csCode.trim()) return;
    const prompt = `[Computer Science Tutor - ${csTask}]\n\nSnippet/Question:\n\`\`\`\n${csCode}\n\`\`\`\n\nProvide:\n1. Code Explanation / Logic\n2. Corrected/Refactored Code\n3. Complexity Analysis (Big-O)\n4. Common mistakes to avoid`;
    onSendMessage(
      prompt,
      'Computer Science',
      0.2,
      'You are Tutormaxx CS Instructor. Help students learn coding (Python, JS, C++, Java), algorithms, data structures, and debugging techniques.'
    );
    setCsCode('');
  };

  const handleExecuteBasicSkills = () => {
    const prompt = `[Basic Skills & Manners Guide - ${skillCategory}]\n\nPlease teach students essential rules, manners, active study habits, and life skills regarding:\n"${skillCategory}"\n\nInclude:\n1. Golden Rules of Respect & Etiquette\n2. Step-by-Step Daily Habit Guide\n3. Common Student Mistakes to Avoid\n4. Positive Real-World Scenarios`;
    onSendMessage(
      prompt,
      'Basic Skills',
      0.5,
      'You are Tutormaxx Student Life Skills & Etiquette Coach. Guide students on classroom manners, respectful behavior, active listening, time management, and positive study habits.'
    );
  };

  const renderFormattedContent = (content: string) => {
    const lines = content.split('\n');
    let inCodeBlock = false;
    let codeBuffer: string[] = [];
    const elements: React.ReactNode[] = [];

    lines.forEach((line, index) => {
      if (line.trim().startsWith('```')) {
        if (inCodeBlock) {
          const codeString = codeBuffer.join('\n');
          elements.push(
            <div key={`code-${index}`} className="my-3 rounded-xl border border-slate-800 bg-slate-950 overflow-hidden font-mono text-xs shadow-lg">
              <div className="flex items-center justify-between px-4 py-2 bg-slate-900 border-b border-slate-800 text-slate-400">
                <span className="text-[10px] font-mono text-indigo-400">Solution / Code</span>
                <button
                  type="button"
                  onClick={() => copyToClipboard(`code-${index}`, codeString)}
                  className="hover:text-white transition-colors cursor-pointer flex items-center gap-1 text-[11px]"
                >
                  {copiedId === `code-${index}` ? (
                    <>
                      <Check className="w-3.5 h-3.5 text-emerald-400" /> Copied
                    </>
                  ) : (
                    <>
                      <Copy className="w-3.5 h-3.5" /> Copy Code
                    </>
                  )}
                </button>
              </div>
              <pre className="p-4 overflow-x-auto text-slate-200 leading-relaxed font-mono">
                <code>{codeString}</code>
              </pre>
            </div>
          );
          codeBuffer = [];
          inCodeBlock = false;
        } else {
          inCodeBlock = true;
        }
      } else if (inCodeBlock) {
        codeBuffer.push(line);
      } else {
        if (line.trim()) {
          elements.push(
            <p key={`p-${index}`} className="leading-relaxed text-slate-200">
              {line}
            </p>
          );
        }
      }
    });

    return elements;
  };

  return (
    <section id="subject-workstations" className="py-12 bg-zinc-950 min-h-screen text-zinc-100">
      <div className="max-w-6xl mx-auto px-4 sm:px-6">
        {/* Workstation Top Action Bar */}
        <div className="p-4 rounded-2xl bg-zinc-900 border border-zinc-800 mb-8 flex flex-wrap items-center justify-between gap-4 shadow-sm">
          <div className="flex items-center gap-3">
            <button
              onClick={onToggleMobileHistory}
              className="lg:hidden p-2 rounded-xl bg-zinc-800 text-zinc-300 hover:text-white transition-colors flex items-center gap-2 text-xs font-semibold"
            >
              <History className="w-4 h-4 text-red-500" />
              <span>History</span>
            </button>

            <div className="flex items-center gap-2.5">
              <GraduationCap className="w-5 h-5 text-red-500" />
              <span className="font-extrabold text-sm text-white tracking-wide">
                {activeSessionTitle || 'Tutormaxx Student Workstation'}
              </span>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-3 text-xs font-mono">
            {/* Teacher Mode Feature Switch */}
            <button
              type="button"
              onClick={() => {
                const next = !isTeacherMode;
                setIsTeacherMode(next);
                if (next) setIsSimpleMode(false);
              }}
              className={`px-3 py-1.5 rounded-xl border text-xs font-bold transition-all flex items-center gap-2 cursor-pointer ${
                isTeacherMode
                  ? 'bg-red-600 border-red-500 text-white shadow-md shadow-red-600/30'
                  : 'bg-zinc-950 border-zinc-800 text-zinc-300 hover:text-white hover:bg-zinc-800'
              }`}
              title="Toggle Teacher Mode for brief, structured topic explanations"
            >
              <GraduationCap className={`w-4 h-4 ${isTeacherMode ? 'text-white animate-bounce' : 'text-red-500'}`} />
              <span>Teacher Mode: {isTeacherMode ? 'ON' : 'OFF'}</span>
            </button>

            {/* Simple Mode Feature Switch */}
            <button
              type="button"
              onClick={() => {
                const next = !isSimpleMode;
                setIsSimpleMode(next);
                if (next) setIsTeacherMode(false);
              }}
              className={`px-3 py-1.5 rounded-xl border text-xs font-bold transition-all flex items-center gap-2 cursor-pointer ${
                isSimpleMode
                  ? 'bg-amber-600 border-amber-500 text-white shadow-md shadow-amber-600/30'
                  : 'bg-zinc-950 border-zinc-800 text-zinc-300 hover:text-white hover:bg-zinc-800'
              }`}
              title="Toggle Simple Mode to explain tough, complex problems in simple language"
            >
              <Lightbulb className={`w-4 h-4 ${isSimpleMode ? 'text-white animate-pulse' : 'text-amber-400'}`} />
              <span>Simple Mode: {isSimpleMode ? 'ON' : 'OFF'}</span>
            </button>

            <span className="hidden sm:inline-block px-3 py-1 rounded-full border border-zinc-800 bg-zinc-950 font-bold text-zinc-400">
              Engine: Gemini 3.6 Flash
            </span>

            {/* Export Thread Controls */}
            {messages.length > 0 && (
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => exportThread('markdown')}
                  className="px-3 py-1 rounded-xl border border-zinc-800 bg-zinc-950 hover:bg-zinc-800 text-zinc-300 transition-colors flex items-center gap-1.5 cursor-pointer text-xs font-semibold"
                  title="Export study notes as Markdown file"
                >
                  <Download className="w-3.5 h-3.5 text-red-500" />
                  <span>.MD Notes</span>
                </button>
                <button
                  type="button"
                  onClick={() => exportThread('json')}
                  className="px-3 py-1 rounded-xl border border-zinc-800 bg-zinc-950 hover:bg-zinc-800 text-zinc-300 transition-colors flex items-center gap-1.5 cursor-pointer text-xs font-semibold"
                  title="Export thread as JSON file"
                >
                  <Download className="w-3.5 h-3.5 text-red-500" />
                  <span>.JSON</span>
                </button>
                <button
                  type="button"
                  onClick={onClearCurrentThread}
                  className="p-1.5 rounded-xl border border-zinc-800 bg-zinc-950 hover:bg-red-950/50 hover:border-red-600/50 text-zinc-400 hover:text-red-400 transition-colors cursor-pointer"
                  title="Clear study thread"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                </button>
              </div>
            )}
          </div>
        </div>

        {/* 7 Subject Tabs Bar */}
        <div className="flex items-center gap-2 mb-8 overflow-x-auto pb-2 scrollbar-none">
          {subjectTabsConfig.map((sub) => {
            const Icon = sub.icon;
            const isSelected = activeSubject === sub.id;
            return (
              <button
                key={sub.id}
                type="button"
                onClick={() => setActiveSubject(sub.id)}
                className={`px-4 py-3 rounded-2xl border text-xs font-extrabold flex items-center gap-2 transition-all shrink-0 cursor-pointer ${
                  isSelected
                    ? 'bg-red-600 border-red-600 text-white shadow-md shadow-red-600/30'
                    : 'bg-zinc-900 border-zinc-800 text-zinc-300 hover:text-white hover:bg-zinc-800'
                }`}
              >
                <Icon className={`w-4 h-4 ${isSelected ? 'text-white' : 'text-red-400'}`} />
                <span>{sub.label}</span>
              </button>
            );
          })}
        </div>

        {/* TAB 1: LANGUAGES */}
        {activeSubject === 'languages' && (
          <div className="p-6 sm:p-8 rounded-3xl bg-white border border-slate-200/90 mb-10 shadow-lg shadow-emerald-950/5">
            <div className="flex items-center gap-2 text-indigo-600 text-xs font-mono font-bold mb-2 uppercase tracking-widest">
              <BookOpen className="w-4 h-4" />
              <span>LANGUAGES & LITERATURE TUTOR</span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 mb-2">
              Language, Grammar & Essay Studio
            </h2>
            <p className="text-xs sm:text-sm text-slate-600 mb-6 font-medium">
              Generate essay outlines, fix grammar, expand vocabulary, and practice Tamil, Hindi, Spanish, French, and German.
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-4">
              <div>
                <label className="block text-xs font-extrabold text-slate-800 mb-1.5">
                  Language Tool:
                </label>
                <select
                  value={langTool}
                  onChange={(e) => setLangTool(e.target.value)}
                  className="w-full p-3 rounded-xl bg-slate-50 border border-slate-300 text-xs font-semibold text-slate-900 focus:outline-none focus:border-emerald-500 focus:bg-white"
                >
                  <option value="Essay Helper">Essay Outline Generator</option>
                  <option value="Grammar & Vocab Corrector">Grammar & Vocab Enhancer</option>
                  <option value="Poetry & Speech Writer">Speech & Poetry Coach</option>
                  <option value="Tamil Practice">Tamil Practice (தமிழ்)</option>
                  <option value="Hindi Practice">Hindi Practice (हिंदी)</option>
                  <option value="Spanish Practice">Spanish Practice</option>
                  <option value="French Practice">French Practice</option>
                  <option value="German Practice">German Practice</option>
                </select>
              </div>

              <div className="sm:col-span-2">
                <label className="block text-xs font-extrabold text-slate-800 mb-1.5">
                  Essay Topic / Sentence / Text to Review:
                </label>
                <input
                  type="text"
                  value={langInput}
                  onChange={(e) => setLangInput(e.target.value)}
                  placeholder="e.g. Practice Tamil grammar or write an essay outline..."
                  className="w-full p-3 rounded-xl bg-slate-50 border border-slate-300 text-xs font-medium text-slate-900 focus:outline-none focus:border-emerald-500 focus:bg-white"
                />
              </div>
            </div>

            <div className="flex items-center justify-between pt-2">
              <span className="text-xs font-mono font-bold text-slate-500">
                Model Temp: {temperature} (Languages)
              </span>
              <button
                type="button"
                onClick={handleExecuteLanguages}
                disabled={!langInput.trim() || isLoading}
                className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-emerald-600 via-teal-600 to-indigo-600 hover:from-emerald-500 hover:to-indigo-500 text-white text-xs font-bold transition-all cursor-pointer flex items-center gap-2 shadow-md shadow-emerald-600/30"
              >
                <span>Generate Language Help</span>
                <Send className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        )}

        {/* TAB 2: MATHEMATICS */}
        {activeSubject === 'maths' && (
          <div className="p-6 sm:p-8 rounded-3xl bg-white border border-slate-200/90 mb-10 shadow-lg shadow-emerald-950/5">
            <div className="flex items-center gap-2 text-emerald-600 text-xs font-mono font-bold mb-2 uppercase tracking-widest">
              <Calculator className="w-4 h-4" />
              <span>MATHEMATICS & ALGEBRA WORKSTATION</span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 mb-2">
              Step-by-Step Math Problem Solver
            </h2>
            <p className="text-xs sm:text-sm text-slate-600 mb-6 font-medium">
              Solve algebra, geometry, calculus, and arithmetic word problems with complete step-by-step logic.
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-4">
              <div>
                <label className="block text-xs font-extrabold text-slate-800 mb-1.5">
                  Math Category:
                </label>
                <select
                  value={mathTool}
                  onChange={(e) => setMathTool(e.target.value)}
                  className="w-full p-3 rounded-xl bg-slate-50 border border-slate-300 text-xs font-semibold text-slate-900 focus:outline-none focus:border-emerald-500 focus:bg-white"
                >
                  <option value="Step-by-Step Solver">Step-by-Step Problem Solver</option>
                  <option value="Algebra Breakdown">Algebra Equation Solver</option>
                  <option value="Geometry Proof">Geometry & Trigonometry</option>
                  <option value="Calculus Derivative/Integral">Calculus & Graphs</option>
                  <option value="Word Problem Helper">Real-World Word Problems</option>
                </select>
              </div>

              <div className="sm:col-span-2">
                <label className="block text-xs font-extrabold text-slate-800 mb-1.5">
                  Enter Math Equation or Word Problem:
                </label>
                <input
                  type="text"
                  value={mathInput}
                  onChange={(e) => setMathInput(e.target.value)}
                  placeholder="e.g. Find the roots of x^2 - 5x + 6 = 0 or calculate area of a circle with radius 7..."
                  className="w-full p-3 rounded-xl bg-slate-50 border border-slate-300 text-xs font-medium text-slate-900 focus:outline-none focus:border-emerald-500 focus:bg-white"
                />
              </div>
            </div>

            <div className="flex items-center justify-between pt-2">
              <span className="text-xs font-mono font-bold text-slate-500">
                Model Temp: 0.2 (High Precision Math Reasoning)
              </span>
              <button
                type="button"
                onClick={handleExecuteMaths}
                disabled={!mathInput.trim() || isLoading}
                className="px-6 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold transition-all cursor-pointer flex items-center gap-2 shadow-md shadow-emerald-600/30"
              >
                <span>Solve Step-by-Step</span>
                <Calculator className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}

        {/* TAB 3: SCIENCE */}
        {activeSubject === 'science' && (
          <div className="p-6 sm:p-8 rounded-3xl bg-white border border-slate-200/90 mb-10 shadow-lg shadow-emerald-950/5">
            <div className="flex items-center gap-2 text-purple-600 text-xs font-mono font-bold mb-2 uppercase tracking-widest">
              <Atom className="w-4 h-4" />
              <span>SCIENCE & EXPERIMENT LAB</span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 mb-2">
              Physics, Chemistry & Biology Explainer
            </h2>
            <p className="text-xs sm:text-sm text-slate-600 mb-6 font-medium">
              Learn physical laws, chemical equations, cellular biology, and lab report structures easily.
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-4">
              <div>
                <label className="block text-xs font-extrabold text-slate-800 mb-1.5">
                  Science Domain:
                </label>
                <select
                  value={scienceTopic}
                  onChange={(e) => setScienceTopic(e.target.value)}
                  className="w-full p-3 rounded-xl bg-slate-50 border border-slate-300 text-xs font-semibold text-slate-900 focus:outline-none focus:border-purple-500 focus:bg-white"
                >
                  <option value="Physics Concept">Physics (Laws, Forces, Energy)</option>
                  <option value="Chemistry Reactions">Chemistry (Periodic Table, Reactions)</option>
                  <option value="Biology Systems">Biology (Cells, Genetics, Ecosystems)</option>
                  <option value="Environmental Science">Environmental Science & Earth</option>
                  <option value="Lab Experiment Helper">Lab Report Structure & Hypothesis</option>
                </select>
              </div>

              <div className="sm:col-span-2">
                <label className="block text-xs font-extrabold text-slate-800 mb-1.5">
                  Topic or Homework Question:
                </label>
                <input
                  type="text"
                  value={scienceInput}
                  onChange={(e) => setScienceInput(e.target.value)}
                  placeholder="e.g. Explain how DNA replication works or balance H2 + O2 -> H2O..."
                  className="w-full p-3 rounded-xl bg-slate-50 border border-slate-300 text-xs font-medium text-slate-900 focus:outline-none focus:border-purple-500 focus:bg-white"
                />
              </div>
            </div>

            <div className="flex items-center justify-between pt-2">
              <span className="text-xs font-mono font-bold text-slate-500">
                Model Temp: 0.4 (Scientific Accuracy)
              </span>
              <button
                type="button"
                onClick={handleExecuteScience}
                disabled={!scienceInput.trim() || isLoading}
                className="px-6 py-2.5 rounded-xl bg-purple-600 hover:bg-purple-700 text-white text-xs font-bold transition-all cursor-pointer flex items-center gap-2 shadow-md shadow-purple-600/30"
              >
                <span>Explain Science Concept</span>
                <Atom className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}

        {/* TAB 4: SOCIAL STUDIES */}
        {activeSubject === 'social' && (
          <div className="p-6 sm:p-8 rounded-3xl bg-white border border-slate-200/90 mb-10 shadow-lg shadow-emerald-950/5">
            <div className="flex items-center gap-2 text-amber-600 text-xs font-mono font-bold mb-2 uppercase tracking-widest">
              <Globe className="w-4 h-4" />
              <span>SOCIAL STUDIES & HISTORY EXPLORER</span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 mb-2">
              History, Geography, Civics & Economics
            </h2>
            <p className="text-xs sm:text-sm text-slate-600 mb-6 font-medium">
              Explore historical timelines, world geography facts, government systems, and economic principles.
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-4">
              <div>
                <label className="block text-xs font-extrabold text-slate-800 mb-1.5">
                  Subject Area:
                </label>
                <select
                  value={socialCategory}
                  onChange={(e) => setSocialCategory(e.target.value)}
                  className="w-full p-3 rounded-xl bg-slate-50 border border-slate-300 text-xs font-semibold text-slate-900 focus:outline-none focus:border-amber-500 focus:bg-white"
                >
                  <option value="History Timeline">World History & Timelines</option>
                  <option value="Geography & Maps">World Geography & Climate Zones</option>
                  <option value="Civics & Government">Civics, Rights & Democracy</option>
                  <option value="Economics Principles">Supply, Demand & Global Trade</option>
                </select>
              </div>

              <div className="sm:col-span-2">
                <label className="block text-xs font-extrabold text-slate-800 mb-1.5">
                  Historical Event, Country or Concept:
                </label>
                <input
                  type="text"
                  value={socialInput}
                  onChange={(e) => setSocialInput(e.target.value)}
                  placeholder="e.g. World War II timeline, Causes of French Revolution, How United Nations works..."
                  className="w-full p-3 rounded-xl bg-slate-50 border border-slate-300 text-xs font-medium text-slate-900 focus:outline-none focus:border-amber-500 focus:bg-white"
                />
              </div>
            </div>

            <div className="flex items-center justify-between pt-2">
              <span className="text-xs font-mono font-bold text-slate-500">
                Model Temp: 0.5 (Historical Context)
              </span>
              <button
                type="button"
                onClick={handleExecuteSocial}
                disabled={!socialInput.trim() || isLoading}
                className="px-6 py-2.5 rounded-xl bg-amber-600 hover:bg-amber-700 text-white text-xs font-bold transition-all cursor-pointer flex items-center gap-2 shadow-md shadow-amber-600/30"
              >
                <span>Explore Social Studies</span>
                <Globe className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}

        {/* TAB 5: GENERAL KNOWLEDGE (GK) */}
        {activeSubject === 'gk' && (
          <div className="p-6 sm:p-8 rounded-3xl bg-white border border-slate-200/90 mb-10 shadow-lg shadow-emerald-950/5">
            <div className="flex items-center gap-2 text-pink-600 text-xs font-mono font-bold mb-2 uppercase tracking-widest">
              <BrainCircuit className="w-4 h-4" />
              <span>GENERAL KNOWLEDGE & TRIVIA QUIZMASTER</span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 mb-2">
              World Trivia, Facts & Practice Quiz
            </h2>
            <p className="text-xs sm:text-sm text-slate-600 mb-6 font-medium">
              Test your knowledge with custom generated multiple-choice quizzes across world facts, space, inventions, and culture.
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-6">
              <div>
                <label className="block text-xs font-extrabold text-slate-800 mb-1.5">
                  Choose Trivia Theme:
                </label>
                <select
                  value={gkCategory}
                  onChange={(e) => setGkCategory(e.target.value)}
                  className="w-full p-3 rounded-xl bg-slate-50 border border-slate-300 text-xs font-semibold text-slate-900 focus:outline-none focus:border-pink-500 focus:bg-white"
                >
                  <option value="World Capitals & Flags">World Capitals & Flags</option>
                  <option value="Famous Inventions & Discoveries">Famous Inventions & Discoveries</option>
                  <option value="Space Exploration & Planets">Space Exploration & Planets</option>
                  <option value="Human Body Trivia">Human Body & Health Facts</option>
                  <option value="Current World Records">World Records & Fun Facts</option>
                </select>
              </div>

              <div className="flex items-end">
                <button
                  type="button"
                  onClick={handleExecuteGK}
                  disabled={isLoading}
                  className="w-full py-3 rounded-xl bg-pink-600 hover:bg-pink-700 text-white text-xs font-bold transition-all cursor-pointer flex items-center justify-center gap-2 shadow-md shadow-pink-600/30"
                >
                  <Sparkles className="w-4 h-4" />
                  <span>Generate GK Quizmaster Challenge</span>
                </button>
              </div>
            </div>
          </div>
        )}

        {/* TAB 6: COMPUTER SCIENCE (CS) */}
        {activeSubject === 'cs' && (
          <div className="p-6 sm:p-8 rounded-3xl bg-white border border-slate-200/90 mb-10 shadow-lg shadow-emerald-950/5">
            <div className="flex items-center gap-2 text-cyan-600 text-xs font-mono font-bold mb-2 uppercase tracking-widest">
              <Code2 className="w-4 h-4" />
              <span>COMPUTER SCIENCE & CODING TUTOR</span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 mb-2">
              Code Debugger, Algorithm & Logic Assistant
            </h2>
            <p className="text-xs sm:text-sm text-slate-600 mb-6 font-medium">
              Learn Python, JavaScript, HTML/CSS, C++, Data Structures, and fix syntax bugs with clean explanation.
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-4">
              <div>
                <label className="block text-xs font-extrabold text-slate-800 mb-1.5">
                  Coding Task:
                </label>
                <select
                  value={csTask}
                  onChange={(e) => setCsTask(e.target.value)}
                  className="w-full p-3 rounded-xl bg-slate-50 border border-slate-300 text-xs font-semibold text-slate-900 focus:outline-none focus:border-cyan-500 focus:bg-white"
                >
                  <option value="Explain Code">Explain Code Line-by-Line</option>
                  <option value="Fix Bugs & Syntax">Fix Syntax Errors & Debug</option>
                  <option value="Algorithms & Data Structures">Algorithms & Data Structures</option>
                  <option value="Python Tutor">Python Loops & Functions</option>
                  <option value="Web Development">HTML / CSS / JavaScript</option>
                </select>
              </div>

              <div className="sm:col-span-2">
                <label className="block text-xs font-extrabold text-slate-800 mb-1.5">
                  Code Snippet or Question:
                </label>
                <textarea
                  value={csCode}
                  onChange={(e) => setCsCode(e.target.value)}
                  placeholder="Paste code snippet or question (e.g. How to reverse an array in Python?)"
                  rows={3}
                  className="w-full p-3 rounded-xl bg-slate-50 border border-slate-300 font-mono text-xs text-slate-900 focus:outline-none focus:border-cyan-500 focus:bg-white resize-none"
                />
              </div>
            </div>

            <div className="flex items-center justify-between pt-2">
              <span className="text-xs font-mono font-bold text-slate-500">
                Model Temp: 0.2 (Precise Coding)
              </span>
              <button
                type="button"
                onClick={handleExecuteCS}
                disabled={!csCode.trim() || isLoading}
                className="px-6 py-2.5 rounded-xl bg-cyan-600 hover:bg-cyan-700 text-white text-xs font-bold transition-all cursor-pointer flex items-center gap-2 shadow-md shadow-cyan-600/30"
              >
                <span>Run CS Tutor</span>
                <Code2 className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}

        {/* TAB 7: MIND MAP GENERATOR */}
        {activeSubject === 'mindmap' && (
          <MindMapGenerator
            onOpenChatWithPrompt={(prompt) => onSendMessage(prompt, 'Mind Map', 0.5)}
          />
        )}



        {/* SIMPLE MODE FEATURE — EASY EXPLAINER STUDIO */}
        <div className="p-6 sm:p-8 rounded-3xl bg-zinc-900 border border-zinc-800 mb-8 shadow-lg relative overflow-hidden">
          <div className="absolute top-0 right-0 w-64 h-64 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />

          <div className="flex flex-wrap items-center justify-between gap-3 mb-4 pb-3 border-b border-zinc-800">
            <div className="flex items-center gap-2.5">
              <div className="p-2 rounded-xl bg-amber-950/60 border border-amber-500/40 text-amber-400">
                <Lightbulb className="w-5 h-5" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <span className="font-extrabold text-sm sm:text-base text-white">Simple Mode — Complex Problem Easy Explainer (ELI5)</span>
                  <span className="px-2 py-0.5 rounded-full border border-amber-500/40 bg-amber-950/60 text-amber-400 text-[10px] font-mono font-bold uppercase tracking-wider">
                    Feature Mode
                  </span>
                </div>
                <p className="text-xs text-zinc-400 mt-0.5 font-medium">
                  Have a tough, complex problem or intimidating topic? Simple Mode translates it into plain English with everyday analogies & simple words.
                </p>
              </div>
            </div>

            <button
              type="button"
              onClick={() => {
                const next = !isSimpleMode;
                setIsSimpleMode(next);
                if (next) setIsTeacherMode(false);
              }}
              className={`px-3 py-1.5 rounded-xl border text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
                isSimpleMode
                  ? 'bg-amber-600 border-amber-500 text-white shadow-md shadow-amber-600/30'
                  : 'bg-zinc-950 border-zinc-800 text-zinc-400 hover:text-white'
              }`}
            >
              <Lightbulb className="w-3.5 h-3.5 text-amber-400" />
              <span>{isSimpleMode ? 'Simple Mode Enabled' : 'Enable Simple Mode'}</span>
            </button>
          </div>

          <form onSubmit={(e) => { e.preventDefault(); handleExecuteSimpleMode(); }} className="mb-4">
            <div className="flex flex-col sm:flex-row items-center gap-3">
              <div className="relative flex-1 w-full">
                <input
                  type="text"
                  value={simpleTopicInput}
                  onChange={(e) => setSimpleTopicInput(e.target.value)}
                  placeholder="Paste any tough question or topic (e.g., Schrödinger's Cat, Inflation, Quantum Entanglement, Recursion, Calculus Derivatives)..."
                  className="w-full px-4 py-3 rounded-2xl bg-zinc-950 border border-zinc-800 text-xs sm:text-sm font-semibold text-white placeholder-zinc-500 focus:outline-none focus:border-amber-500 transition-all"
                />
              </div>

              <button
                type="submit"
                disabled={!simpleTopicInput.trim() || isLoading}
                className="w-full sm:w-auto px-6 py-3 rounded-2xl bg-amber-600 hover:bg-amber-500 text-white text-xs font-extrabold transition-all disabled:opacity-40 disabled:cursor-not-allowed shadow-md shadow-amber-600/30 flex items-center justify-center gap-2 cursor-pointer shrink-0"
              >
                <Sparkles className="w-4 h-4" />
                <span>Explain Simply (ELI5)</span>
              </button>
            </div>
          </form>

          {/* Quick Popular Sample Tough Topics */}
          <div>
            <div className="text-[11px] font-mono font-bold text-zinc-400 uppercase tracking-wider mb-2">
              Try Simple Mode on Complex Problems:
            </div>
            <div className="flex flex-wrap items-center gap-2">
              {[
                "Schrödinger's Cat",
                'Dividing by Zero',
                'How Inflation Works',
                'Quantum Entanglement',
                'Recursion in Coding',
                'General Relativity',
                'NFTs & Blockchain',
                'Stock Market Shorting',
              ].map((topic, sIdx) => (
                <button
                  key={sIdx}
                  type="button"
                  onClick={() => handleExecuteSimpleMode(topic)}
                  className="px-3 py-1.5 rounded-xl border border-zinc-800 bg-zinc-950 hover:border-amber-500/50 hover:bg-zinc-900 text-zinc-300 hover:text-white text-xs font-semibold transition-all cursor-pointer flex items-center gap-1.5"
                >
                  <Lightbulb className="w-3 h-3 text-amber-400" />
                  <span>{topic}</span>
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* TEACHER MODE FEATURE — BRIEF TOPIC EXPLAINER STUDIO */}
        <div className="p-6 sm:p-8 rounded-3xl bg-zinc-900 border border-zinc-800 mb-8 shadow-lg relative overflow-hidden">
          <div className="absolute top-0 right-0 w-64 h-64 bg-red-600/10 rounded-full blur-3xl pointer-events-none" />

          <div className="flex flex-wrap items-center justify-between gap-3 mb-4 pb-3 border-b border-zinc-800">
            <div className="flex items-center gap-2.5">
              <div className="p-2 rounded-xl bg-red-950/60 border border-red-500/40 text-red-400">
                <GraduationCap className="w-5 h-5" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <span className="font-extrabold text-sm sm:text-base text-white">Teacher Mode — Brief Topic Explainer</span>
                  <span className="px-2 py-0.5 rounded-full border border-red-500/40 bg-red-950/60 text-red-400 text-[10px] font-mono font-bold uppercase tracking-wider">
                    Feature Mode
                  </span>
                </div>
                <p className="text-xs text-zinc-400 mt-0.5 font-medium">
                  Enter any topic or concept to receive a brief, 4-step teacher breakdown (Summary, Key Points, Analogy & Self-Check Question).
                </p>
              </div>
            </div>

            <button
              type="button"
              onClick={() => {
                const next = !isTeacherMode;
                setIsTeacherMode(next);
                if (next) setIsSimpleMode(false);
              }}
              className={`px-3 py-1.5 rounded-xl border text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
                isTeacherMode
                  ? 'bg-red-600 border-red-500 text-white shadow-md shadow-red-600/30'
                  : 'bg-zinc-950 border-zinc-400 hover:text-white'
              }`}
            >
              <GraduationCap className="w-3.5 h-3.5 text-red-400" />
              <span>{isTeacherMode ? 'Teacher Mode Enabled' : 'Enable Teacher Mode'}</span>
            </button>
          </div>

          <form onSubmit={(e) => { e.preventDefault(); handleExecuteTeacherMode(); }} className="mb-4">
            <div className="flex flex-col sm:flex-row items-center gap-3">
              <div className="relative flex-1 w-full">
                <input
                  type="text"
                  value={teacherTopicInput}
                  onChange={(e) => setTeacherTopicInput(e.target.value)}
                  placeholder="Enter any topic (e.g., Photosynthesis, Pythagorean Theorem, Relativity, Binary Trees, French Revolution)..."
                  className="w-full px-4 py-3 rounded-2xl bg-zinc-950 border border-zinc-800 text-xs sm:text-sm font-semibold text-white placeholder-zinc-500 focus:outline-none focus:border-red-500 transition-all"
                />
              </div>

              <button
                type="submit"
                disabled={!teacherTopicInput.trim() || isLoading}
                className="w-full sm:w-auto px-6 py-3 rounded-2xl bg-red-600 hover:bg-red-500 text-white text-xs font-extrabold transition-all disabled:opacity-40 disabled:cursor-not-allowed shadow-md shadow-red-600/30 flex items-center justify-center gap-2 cursor-pointer shrink-0"
              >
                <Sparkles className="w-4 h-4" />
                <span>Get Brief Teacher Explanation</span>
              </button>
            </div>
          </form>

          {/* Quick Popular Sample Topics */}
          <div>
            <div className="text-[11px] font-mono font-bold text-zinc-400 uppercase tracking-wider mb-2">
              Popular Topics to Try in Teacher Mode:
            </div>
            <div className="flex flex-wrap items-center gap-2">
              {[
                'Photosynthesis',
                'Pythagorean Theorem',
                'Quantum Computing',
                'French Revolution',
                "Newton's Laws of Motion",
                'Black Holes',
                'DNA Replication',
                'Supply and Demand',
              ].map((topic, tIdx) => (
                <button
                  key={tIdx}
                  type="button"
                  onClick={() => handleExecuteTeacherMode(topic)}
                  className="px-3 py-1.5 rounded-xl border border-zinc-800 bg-zinc-950 hover:border-red-500/50 hover:bg-zinc-900 text-zinc-300 hover:text-white text-xs font-semibold transition-all cursor-pointer flex items-center gap-1.5"
                >
                  <Award className="w-3 h-3 text-red-500" />
                  <span>{topic}</span>
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Freeform Prompt Box */}
        <div className="p-6 rounded-3xl bg-zinc-900 border border-zinc-800 mb-10 shadow-lg">
          <div className="flex items-center gap-2 text-xs font-mono font-bold text-red-500 mb-2 uppercase tracking-widest">
            <Zap className="w-3.5 h-3.5" />
            <span>FREEFORM STUDENT PROMPT INPUT</span>
          </div>

          {isSimpleMode && (
            <div className="mb-3 px-3.5 py-2 rounded-xl bg-amber-950/50 border border-amber-500/40 text-amber-300 text-xs font-semibold flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Lightbulb className="w-4 h-4 text-amber-400 animate-pulse" />
                <span><strong>Simple Mode Active:</strong> Complex problems will be explained simply in plain, easy language.</span>
              </div>
              <button
                type="button"
                onClick={() => setIsSimpleMode(false)}
                className="text-[10px] font-mono font-bold text-amber-400 hover:underline cursor-pointer"
              >
                Turn Off
              </button>
            </div>
          )}

          {isTeacherMode && (
            <div className="mb-3 px-3.5 py-2 rounded-xl bg-red-950/50 border border-red-500/40 text-red-300 text-xs font-semibold flex items-center justify-between">
              <div className="flex items-center gap-2">
                <GraduationCap className="w-4 h-4 text-red-400 animate-pulse" />
                <span><strong>Teacher Mode Active:</strong> Prompts will generate brief, 4-step teacher explanations.</span>
              </div>
              <button
                type="button"
                onClick={() => setIsTeacherMode(false)}
                className="text-[10px] font-mono font-bold text-red-400 hover:underline cursor-pointer"
              >
                Turn Off
              </button>
            </div>
          )}

          <form onSubmit={handleSubmit}>
            <div className="p-4 rounded-2xl bg-zinc-950 border border-zinc-800 focus-within:border-red-500 transition-all">
              <textarea
                ref={textareaRef}
                value={promptText}
                onChange={(e) => setPromptText(e.target.value)}
                onKeyDown={handleKeyDown}
                placeholder={`Ask Tutormaxx any freeform homework question in ${activeSubject.toUpperCase()}...`}
                rows={3}
                className="w-full bg-transparent text-xs sm:text-sm font-medium focus:outline-none placeholder-zinc-500 text-white resize-none"
              />

              <div className="flex flex-wrap items-center justify-between gap-3 pt-3 border-t border-zinc-800">
                <div className="flex items-center gap-3">
                  <button
                    type="button"
                    onClick={toggleVoiceRecording}
                    className={`px-3 py-1.5 rounded-xl border text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer ${
                      isRecording
                        ? 'bg-red-950/80 border-red-500 text-red-400 animate-pulse'
                        : 'bg-zinc-900 border-zinc-800 text-zinc-300 hover:bg-zinc-800'
                    }`}
                    title="Dictate prompt with microphone"
                  >
                    {isRecording ? <MicOff className="w-3.5 h-3.5 text-red-500" /> : <Mic className="w-3.5 h-3.5 text-red-400" />}
                    <span>{isRecording ? 'Listening...' : 'Voice Input'}</span>
                  </button>

                  <div className="hidden sm:flex items-center gap-1.5 text-xs font-mono text-zinc-500 font-medium">
                    <Terminal className="w-3 h-3 text-red-500" />
                    <span>Shift+Enter for newline</span>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  {promptText && (
                    <button
                      type="button"
                      onClick={() => setPromptText('')}
                      className="px-3 py-1.5 rounded-xl border border-zinc-800 bg-zinc-900 text-zinc-400 text-xs font-semibold hover:bg-zinc-800 transition-colors"
                    >
                      Clear
                    </button>
                  )}
                  <button
                    type="submit"
                    disabled={!promptText.trim() || isLoading}
                    className="px-6 py-2 rounded-xl bg-red-600 hover:bg-red-500 text-white text-xs font-bold transition-all disabled:opacity-40 disabled:cursor-not-allowed shadow-md shadow-red-600/30 flex items-center gap-2 cursor-pointer"
                  >
                    <span>Ask AI Tutor</span>
                    <Send className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            </div>
          </form>

          {/* Quick Preset Cards */}
          <div className="mt-6 pt-6 border-t border-zinc-800">
            <div className="text-xs font-extrabold text-zinc-400 mb-3 uppercase tracking-wider">
              Popular Homework Prompts:
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
              {PRESET_PROMPTS.slice(0, 6).map((item) => (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => onSendMessage(item.prompt, activeSubject, temperature)}
                  className="p-3.5 rounded-2xl border border-zinc-800 bg-zinc-950 hover:border-red-500/50 hover:bg-zinc-900 text-left transition-all cursor-pointer group shadow-2xs"
                >
                  <div className="flex items-center justify-between text-[11px] font-extrabold text-red-400 mb-1">
                    <span>{item.title}</span>
                    <ArrowRight className="w-3 h-3 group-hover:translate-x-1 transition-transform" />
                  </div>
                  <div className="text-[11px] text-zinc-400 line-clamp-2 mt-0.5 font-medium">
                    "{item.prompt}"
                  </div>
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Conversation Output Stream */}
        <div className="p-6 sm:p-8 rounded-3xl bg-zinc-900 border border-zinc-800 shadow-lg">
          <div className="flex flex-wrap items-center justify-between pb-4 mb-6 border-b border-zinc-800 gap-2">
            <div className="flex items-center gap-2">
              <MessageSquare className="w-4 h-4 text-red-500" />
              <span className="font-extrabold text-sm text-white uppercase tracking-wider">
                Tutormaxx Learning Stream
              </span>
            </div>

            <div className="flex items-center gap-3">
              {messages.length > 0 && (
                <button
                  type="button"
                  onClick={() => setGlobalCollapsed(!globalCollapsed)}
                  className="px-3 py-1 rounded-xl border border-zinc-800 bg-zinc-950 hover:bg-zinc-800 text-zinc-300 text-xs font-semibold transition-colors flex items-center gap-1.5 cursor-pointer"
                  title="Collapse long answers to avoid scrolling down"
                >
                  {globalCollapsed ? (
                    <>
                      <Maximize2 className="w-3.5 h-3.5 text-emerald-400" />
                      <span>Expand All Answers</span>
                    </>
                  ) : (
                    <>
                      <Minimize2 className="w-3.5 h-3.5 text-amber-400" />
                      <span>Collapse Long Answers</span>
                    </>
                  )}
                </button>
              )}

              <span className="text-xs font-mono font-bold text-zinc-500">
                {messages.length} Messages
              </span>
            </div>
          </div>

          {messages.length === 0 ? (
            <div className="py-16 text-center">
              <div className="w-12 h-12 rounded-2xl bg-zinc-950 border border-zinc-800 flex items-center justify-center mx-auto mb-4 text-red-500">
                <GraduationCap className="w-6 h-6 animate-pulse" />
              </div>
              <div className="text-sm font-extrabold text-white">
                Ready to help with your studies!
              </div>
              <p className="text-xs text-zinc-400 mt-1 max-w-sm mx-auto font-medium">
                Choose a subject tab above or type a homework question to generate explanations with Tutormaxx.
              </p>
            </div>
          ) : (
            <div className="space-y-6">
              {messages.map((msg) => {
                const isUser = msg.role === 'user';
                const isLong = msg.content.length > 280;
                const isExpanded = expandedMsgIds[msg.id] ?? !globalCollapsed;

                return (
                  <div
                    key={msg.id}
                    className={`p-5 rounded-2xl border transition-all ${
                      isUser
                        ? 'bg-zinc-950 border-zinc-800 text-zinc-100'
                        : 'bg-zinc-950/80 border-red-900/40 text-zinc-100 shadow-sm'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-3 pb-2 border-b border-zinc-800">
                      <div className="flex items-center gap-2.5">
                        <div
                          className={`w-6 h-6 rounded-lg flex items-center justify-center font-bold text-xs ${
                            isUser ? 'bg-zinc-800 text-zinc-200' : 'bg-red-600 text-white'
                          }`}
                        >
                          {isUser ? 'S' : '🎓'}
                        </div>
                        <span className="font-extrabold text-xs text-white">
                          {isUser ? 'Student' : 'Tutormaxx AI'}
                        </span>
                      </div>

                      <div className="flex items-center gap-2">
                        {isLong && (
                          <button
                            type="button"
                            onClick={() => toggleMsgExpand(msg.id)}
                            className="text-[10px] font-bold text-amber-400 hover:text-amber-300 flex items-center gap-1 bg-amber-950/40 px-2 py-0.5 rounded-lg border border-amber-500/30 cursor-pointer"
                          >
                            {isExpanded ? (
                              <>
                                <ChevronUp className="w-3 h-3" /> Collapse
                              </>
                            ) : (
                              <>
                                <ChevronDown className="w-3 h-3" /> Expand
                              </>
                            )}
                          </button>
                        )}

                        <span className="text-[10px] font-mono font-medium text-zinc-500">
                          {msg.timestamp}
                        </span>
                      </div>
                    </div>

                    {/* Content Area with Collapsible Clamping */}
                    <div className="relative">
                      {!isExpanded && isLong ? (
                        <div className="relative">
                          <div className="max-h-32 overflow-hidden space-y-2 text-xs sm:text-sm font-medium leading-relaxed opacity-80">
                            {renderFormattedContent(msg.content)}
                          </div>
                          <div className="absolute inset-x-0 bottom-0 h-20 bg-gradient-to-t from-zinc-950 via-zinc-950/90 to-transparent flex items-end justify-center pb-0.5">
                            <button
                              type="button"
                              onClick={() => toggleMsgExpand(msg.id)}
                              className="px-4 py-1 rounded-full bg-red-600 hover:bg-red-500 text-white text-xs font-extrabold shadow-md flex items-center gap-1.5 transition-all cursor-pointer"
                            >
                              <ChevronDown className="w-3.5 h-3.5" />
                              <span>Show Full Answer (Expand)</span>
                            </button>
                          </div>
                        </div>
                      ) : (
                        <div className="space-y-2 text-xs sm:text-sm font-medium leading-relaxed">
                          {renderFormattedContent(msg.content)}
                          {isLong && (
                            <div className="pt-2 flex justify-end">
                              <button
                                type="button"
                                onClick={() => toggleMsgExpand(msg.id)}
                                className="text-[11px] font-semibold text-zinc-400 hover:text-white flex items-center gap-1 cursor-pointer"
                              >
                                <ChevronUp className="w-3.5 h-3.5 text-amber-400" />
                                <span>Show Less (Collapse)</span>
                              </button>
                            </div>
                          )}
                        </div>
                      )}
                    </div>

                    {!isUser && (
                      <div className="mt-4 pt-3 border-t border-zinc-800 flex flex-wrap items-center justify-between gap-2">
                        <div className="text-[10px] font-mono font-bold text-red-400 flex items-center gap-2">
                          <span>GEMINI_STUDENT_TUTOR // OK</span>
                        </div>

                        <div className="flex items-center gap-3">
                          <button
                            type="button"
                            onClick={() => handleShortenAnswer(msg.content)}
                            className="text-[11px] font-extrabold text-amber-400 hover:text-amber-300 flex items-center gap-1 cursor-pointer transition-colors px-2 py-1 rounded-lg bg-amber-950/40 border border-amber-500/30"
                            title="Ask AI to condense this answer into 3 quick bullet points"
                          >
                            <Zap className="w-3.5 h-3.5 text-amber-400" />
                            <span>⚡ Shorten Answer</span>
                          </button>

                          <button
                            type="button"
                            onClick={() => toggleTextToSpeech(msg.id, msg.content)}
                            className={`text-[11px] font-semibold flex items-center gap-1 cursor-pointer transition-colors ${
                              speakingMsgId === msg.id
                                ? 'text-red-400 font-bold animate-pulse'
                                : 'text-zinc-400 hover:text-white'
                            }`}
                            title="Read explanation aloud"
                          >
                            {speakingMsgId === msg.id ? (
                              <>
                                <VolumeX className="w-3.5 h-3.5" /> Stop Audio
                              </>
                            ) : (
                              <>
                                <Volume2 className="w-3.5 h-3.5" /> Listen
                              </>
                            )}
                          </button>

                          <button
                            type="button"
                            onClick={() => copyToClipboard(msg.id, msg.content)}
                            className="text-[11px] font-extrabold text-red-400 hover:text-red-300 flex items-center gap-1.5 cursor-pointer"
                          >
                            {copiedId === msg.id ? (
                              <>
                                <Check className="w-3.5 h-3.5 text-emerald-600" /> Copied
                              </>
                            ) : (
                              <>
                                <Copy className="w-3.5 h-3.5" /> Copy Notes
                              </>
                            )}
                          </button>
                        </div>
                      </div>
                    )}
                  </div>
                );
              })}

              {isLoading && (
                <div className="p-5 rounded-2xl bg-emerald-50 border border-emerald-200 flex items-center gap-3 text-emerald-800 font-mono text-xs font-bold">
                  <Cpu className="w-4 h-4 animate-spin text-emerald-600" />
                  <span>Tutormaxx is thinking and generating step-by-step answer...</span>
                </div>
              )}

              <div ref={messagesEndRef} />
            </div>
          )}
        </div>
      </div>
    </section>
  );
};

