import React, { useState, useEffect } from 'react';
import { Sparkles, Menu, X, BookOpen, GraduationCap, Zap } from 'lucide-react';

interface NavbarProps {
  onOpenChat: (initialPrompt?: string) => void;
}

export const Navbar: React.FC<NavbarProps> = ({ onOpenChat }) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [apiOnline, setApiOnline] = useState<boolean | null>(null);

  useEffect(() => {
    fetch('/api/health')
      .then((res) => res.json())
      .then((data) => {
        setApiOnline(data.status === 'ok');
      })
      .catch(() => setApiOnline(false));
  }, []);

  return (
    <header className="h-16 border-b border-zinc-800/80 flex items-center justify-between px-4 sm:px-8 lg:px-12 bg-zinc-950/90 backdrop-blur-xl sticky top-0 z-40">
      {/* Brand Logo - Tutormaxx */}
      <div className="flex items-center gap-3">
        <div className="relative flex items-center justify-center w-9 h-9 rounded-xl bg-gradient-to-br from-red-600 to-rose-700 p-[1px] shadow-sm shadow-red-600/30">
          <div className="w-full h-full bg-zinc-950 rounded-[11px] flex items-center justify-center">
            <GraduationCap className="w-5 h-5 text-red-500" />
          </div>
        </div>
        <div className="flex items-center gap-2">
          <span className="font-extrabold text-lg sm:text-xl tracking-tight text-white">
            Tutor<span className="text-red-500">maxx</span>
          </span>
          <span className="px-2 py-0.5 rounded-full border border-red-500/30 text-[10px] font-mono font-bold text-red-400 bg-red-950/40">
            Student AI
          </span>
        </div>
      </div>

      {/* Desktop Navigation Links */}
      <nav className="hidden md:flex items-center gap-6 text-xs font-semibold text-zinc-400">
        <a
          href="#exam-active-recall-studio"
          className="hover:text-red-400 transition-colors py-1 text-red-400 font-extrabold flex items-center gap-1.5"
        >
          <GraduationCap className="w-3.5 h-3.5 text-red-500" />
          <span>Exam & Active Recall Studio</span>
        </a>
        <a
          href="#subject-workstations"
          className="hover:text-red-400 transition-colors py-1 text-zinc-300 hover:text-white"
        >
          Subject Workstations
        </a>
        <a
          href="#basic-skills"
          className="hover:text-red-400 transition-colors py-1 text-zinc-300 hover:text-white"
        >
          Life Skills & Etiquette
        </a>
        <a
          href="#faq"
          className="hover:text-white transition-colors"
        >
          FAQ
        </a>
      </nav>

      {/* Action Controls */}
      <div className="flex items-center gap-3">
        {/* Backend Health Status Badge */}
        <div
          className="hidden lg:flex items-center gap-2 px-3 py-1.5 rounded-xl border border-zinc-800 bg-zinc-900 text-[11px] font-mono text-zinc-300"
          title={apiOnline === true ? 'Gemini Student Tutor Engine Online' : 'Connecting server...'}
        >
          <div
            className={`w-2 h-2 rounded-full ${
              apiOnline === true ? 'bg-red-500 shadow-[0_0_8px_rgba(239,68,68,0.8)]' : 'bg-amber-500 animate-pulse'
            }`}
          />
          <span className="font-bold text-xs">{apiOnline === true ? 'TUTOR READY' : 'CONNECTING...'}</span>
        </div>

        {/* Launch AI Tutor Copilot CTA */}
        <button
          onClick={() => onOpenChat()}
          className="px-4 py-2 rounded-xl bg-red-600 hover:bg-red-500 text-white text-xs font-bold tracking-wide transition-all shadow-md shadow-red-600/30 active:scale-95 cursor-pointer flex items-center gap-2"
        >
          <Zap className="w-3.5 h-3.5 text-red-200" />
          <span>Ask AI Tutor</span>
        </button>

        {/* Mobile Hamburger Menu Toggle */}
        <button
          onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          className="md:hidden p-2 rounded-lg border border-zinc-800 text-zinc-300 hover:text-white hover:bg-zinc-900 transition-colors"
        >
          {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
        </button>
      </div>

      {/* Mobile Menu Dropdown */}
      {mobileMenuOpen && (
        <div className="md:hidden absolute top-16 left-0 right-0 bg-zinc-950/95 border-b border-zinc-800 p-6 flex flex-col gap-4 text-xs font-medium text-zinc-300 backdrop-blur-2xl shadow-2xl z-50">
          <a
            href="#subject-workstations"
            onClick={() => setMobileMenuOpen(false)}
            className="p-2.5 rounded-lg hover:bg-zinc-900 hover:text-white"
          >
            Subject Workstations
          </a>
          <a
            href="#basic-skills"
            onClick={() => setMobileMenuOpen(false)}
            className="p-2.5 rounded-lg bg-red-950/40 border border-red-500/30 text-red-400 font-bold"
          >
            Basic Life Skills & Etiquette
          </a>
          <a
            href="#faq"
            onClick={() => setMobileMenuOpen(false)}
            className="p-2.5 rounded-lg hover:bg-zinc-900 hover:text-white"
          >
            FAQ
          </a>
          <button
            onClick={() => {
              setMobileMenuOpen(false);
              onOpenChat();
            }}
            className="w-full mt-2 py-3 rounded-xl bg-red-600 text-white font-bold text-xs shadow-md shadow-red-600/30"
          >
            Open AI Tutor Copilot
          </button>
        </div>
      )}
    </header>
  );
};




