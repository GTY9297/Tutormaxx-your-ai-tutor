import React from 'react';
import {
  ShieldCheck,
  Zap,
  Layers,
  Unlock,
  Check,
  X,
  Sparkles,
  Bot,
  Globe,
  Cpu,
  MessageSquare,
} from 'lucide-react';

interface WhyChooseUsProps {
  onOpenChat: (initialPrompt?: string) => void;
}

export const WhyChooseUs: React.FC<WhyChooseUsProps> = ({ onOpenChat }) => {
  const comparisonData = [
    {
      feature: 'In-App Workspace Integration',
      aura: 'Native embedded UI & real-time context directly inside your web app',
      chatgpt: 'Isolated external tab; requires manual copy-pasting',
      geminiWeb: 'External Google tab; disconnected from your app state',
    },
    {
      feature: 'API Key Security & Privacy',
      aura: 'Server-side Express proxy protects keys & prevents data leaks',
      chatgpt: 'Browser extensions or client keys expose API credentials',
      geminiWeb: 'Tied to individual personal Google consumer accounts',
    },
    {
      feature: 'Pre-Tuned Reasoning Modes',
      aura: 'Pre-loaded Code Engineer, Architect & Creative Assistant prompts',
      chatgpt: 'Requires writing long custom setup instructions every chat',
      geminiWeb: 'Requires repetitive prompt priming in every session',
    },
    {
      feature: 'End-User Access & Pricing',
      aura: 'Zero paywalls for your users — served via backend usage quotas',
      chatgpt: '$20/month per user subscription required for ChatGPT Plus',
      geminiWeb: '$19.99/month Advanced subscription required for top tier',
    },
    {
      feature: 'Multi-Thread History',
      aura: 'Local room state & thread sidebar with zero account lock-in',
      chatgpt: 'Saves on OpenAI servers; lost if account is suspended',
      geminiWeb: 'Saved in Google activity logs with privacy tracking',
    },
  ];

  const keyReasons = [
    {
      icon: Layers,
      title: 'Context-Aware App Integration',
      description:
        'Unlike standalone ChatGPT or Gemini web apps that live in separate browser tabs, Aura AI is natively embedded directly into your application workflow.',
    },
    {
      icon: ShieldCheck,
      title: 'Enterprise Server-Side Security',
      description:
        'All AI requests pass through a secure Node.js/Express proxy, preventing API key exposure and ensuring strict compliance without client-side key leakage.',
    },
    {
      icon: Cpu,
      title: 'Domain-Tailored System Prompting',
      description:
        'Aura AI comes pre-configured with custom reasoning modes (Code Engineer, System Architect, Creative) optimized for your application’s exact business rules.',
    },
    {
      icon: Unlock,
      title: 'Zero Paywalls for Your End Users',
      description:
        'Empower your website visitors with intelligent AI capabilities without forcing them to pay $20/month for external ChatGPT or Gemini Advanced subscriptions.',
    },
  ];

  return (
    <section id="why-aura" className="py-20 bg-slate-950 text-slate-100 border-b border-slate-800/80">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-12">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full border border-indigo-500/30 bg-indigo-500/10 text-indigo-300 text-xs font-mono uppercase tracking-widest mb-3">
            <Sparkles className="w-3.5 h-3.5 text-indigo-400" />
            <span>Competitive Matrix</span>
          </div>
          <h2 className="text-3xl sm:text-5xl font-extrabold text-white tracking-tight">
            Why Aura AI Over Standalone Chatbots?
          </h2>
          <p className="mt-4 text-xs sm:text-sm text-slate-400 leading-relaxed">
            See how an embedded, server-proxied AI workstation outperforms generic web chatbots.
          </p>
        </div>

        {/* 4 Core Value Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-16">
          {keyReasons.map((item, index) => {
            const Icon = item.icon;
            return (
              <div
                key={index}
                className="p-6 rounded-3xl bg-slate-900/60 border border-slate-800 ai-glass-card transition-all flex flex-col justify-between"
              >
                <div>
                  <div className="w-10 h-10 rounded-xl bg-indigo-600/20 border border-indigo-500/30 text-indigo-400 flex items-center justify-center font-bold mb-4">
                    <Icon className="w-5 h-5 text-indigo-400" />
                  </div>
                  <h3 className="text-base font-bold text-white mb-2">
                    {item.title}
                  </h3>
                  <p className="text-xs text-slate-400 leading-relaxed">
                    {item.description}
                  </p>
                </div>
                <div className="mt-6 pt-4 border-t border-slate-800/80">
                  <span className="text-[10px] font-mono text-indigo-400 uppercase tracking-widest">
                    ADVANTAGE 0{index + 1}
                  </span>
                </div>
              </div>
            );
          })}
        </div>

        {/* Deep Feature Comparison Matrix Table */}
        <div className="rounded-3xl border border-slate-800 bg-slate-900/80 ai-glass-card overflow-hidden shadow-2xl">
          <div className="p-6 bg-slate-900 border-b border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <div className="text-[10px] font-mono text-indigo-400 uppercase tracking-widest mb-1">
                Capability Breakdown
              </div>
              <h3 className="text-lg font-extrabold text-white">
                Aura AI vs Standalone AI Platforms
              </h3>
            </div>
            <button
              type="button"
              onClick={() => onOpenChat('Explain why Aura AI is a better choice than ChatGPT or Gemini for my web app.')}
              className="px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold transition-all cursor-pointer shadow-md shadow-indigo-600/30 flex items-center gap-2 self-start sm:self-auto"
            >
              <MessageSquare className="w-3.5 h-3.5" />
              <span>Ask AI For Comparison</span>
            </button>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="bg-slate-950/80 border-b border-slate-800 text-[11px] font-mono text-slate-400">
                  <th className="p-4 border-r border-slate-800">Capability</th>
                  <th className="p-4 border-r border-slate-800 bg-indigo-950/30 text-indigo-300 font-bold">
                    ⚡ Aura AI Platform
                  </th>
                  <th className="p-4 border-r border-slate-800">ChatGPT (OpenAI)</th>
                  <th className="p-4">Gemini Web Portal</th>
                </tr>
              </thead>
              <tbody className="text-xs">
                {comparisonData.map((row, idx) => (
                  <tr
                    key={idx}
                    className="border-b border-slate-800/60 hover:bg-slate-800/40 transition-colors"
                  >
                    <td className="p-4 border-r border-slate-800 font-semibold text-slate-200">
                      {row.feature}
                    </td>
                    <td className="p-4 border-r border-slate-800 bg-indigo-950/20 font-medium text-slate-100">
                      <div className="flex items-start gap-2">
                        <Check className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                        <span>{row.aura}</span>
                      </div>
                    </td>
                    <td className="p-4 border-r border-slate-800 text-slate-400">
                      <div className="flex items-start gap-2">
                        <X className="w-4 h-4 text-amber-500 shrink-0 mt-0.5" />
                        <span>{row.chatgpt}</span>
                      </div>
                    </td>
                    <td className="p-4 text-slate-400">
                      <div className="flex items-start gap-2">
                        <X className="w-4 h-4 text-amber-500 shrink-0 mt-0.5" />
                        <span>{row.geminiWeb}</span>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </section>
  );
};

