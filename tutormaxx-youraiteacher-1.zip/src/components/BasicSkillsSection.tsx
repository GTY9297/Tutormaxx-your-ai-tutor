import React, { useState } from 'react';
import { HeartHandshake, Award, BookOpen, Clock, Shield, Mic, CheckCircle2, ArrowRight } from 'lucide-react';

interface BasicSkillsSectionProps {
  onOpenChat: (prompt?: string) => void;
}

export const BasicSkillsSection: React.FC<BasicSkillsSectionProps> = ({ onOpenChat }) => {
  const [selectedTopic, setSelectedTopic] = useState('Classroom Manners & School Rules');

  const topicOptions = [
    {
      title: 'Classroom Manners & School Rules',
      icon: HeartHandshake,
      description: 'Punctuality, raising hands, respecting teacher instructions, maintaining clean desk space, and classroom decorum.',
      prompt: 'Please teach essential classroom manners, school rules, and proper classroom etiquette for students with golden rules and examples.',
    },
    {
      title: 'Active Listening & Peer Respect',
      icon: BookOpen,
      description: 'Listening without interrupting, respectful group discussions, teamwork skills, and showing empathy to classmates.',
      prompt: 'Explain active listening techniques, respectful communication, and how students can show respect to peers and teachers during class.',
    },
    {
      title: 'Effective Study Habits & Time Management',
      icon: Clock,
      description: 'Daily study routines, homework scheduling, managing distractions, desk setup, and preventing procrastination.',
      prompt: 'Provide a step-by-step guide for effective daily study habits, time management techniques, and overcoming procrastination.',
    },
    {
      title: 'Digital Safety & Cyber Ethics',
      icon: Shield,
      description: 'Safe web browsing, protecting personal info online, polite online communication, and avoiding cyberbullying.',
      prompt: 'Explain digital etiquette, safe web browsing rules for students, and guidelines for responsible online communication.',
    },
    {
      title: 'Public Speaking & Confidence',
      icon: Mic,
      description: 'Overcoming stage fright, organizing speech notes, maintaining eye contact, and presenting projects with clarity.',
      prompt: 'Give actionable advice for students to build confidence in public speaking, class presentations, and group discussions.',
    },
    {
      title: 'Exam Preparation & Stress Management',
      icon: CheckCircle2,
      description: 'Active recall study methods, revision timelines, healthy sleep habits, and managing exam anxiety.',
      prompt: 'How can students prepare for exams effectively while managing test anxiety, maintaining good sleep, and using active recall?',
    },
  ];

  const handleLaunchTopic = (prompt: string) => {
    onOpenChat(prompt);
  };

  const handleCustomSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const topicObj = topicOptions.find((t) => t.title === selectedTopic);
    const promptToSend = topicObj
      ? topicObj.prompt
      : `Teach students essential rules and skills about: ${selectedTopic}`;
    onOpenChat(promptToSend);
  };

  return (
    <section id="basic-skills" className="py-16 bg-zinc-950 text-zinc-100 border-b border-zinc-800 red-grid relative">
      <div className="max-w-6xl mx-auto px-4 sm:px-6">
        {/* Header */}
        <div className="flex flex-col items-center text-center max-w-2xl mx-auto mb-12">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full border border-red-500/30 bg-red-950/40 text-red-400 text-xs font-bold mb-3">
            <HeartHandshake className="w-4 h-4 text-red-500" />
            <span>Standalone Life Skills Module</span>
          </div>
          <h2 className="text-2xl sm:text-4xl font-extrabold tracking-tight text-white mb-3">
            Basic Skills, Manners & Rules Guide
          </h2>
          <p className="text-xs sm:text-sm text-zinc-400 font-medium leading-relaxed">
            Essential life habits every student needs — from classroom decorum and active listening to effective time management and exam stress control.
          </p>
        </div>

        {/* Topic Grid Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mb-10">
          {topicOptions.map((topic, index) => {
            const Icon = topic.icon;
            return (
              <div
                key={index}
                onClick={() => handleLaunchTopic(topic.prompt)}
                className="p-5 rounded-2xl bg-zinc-900 border border-zinc-800 hover:border-red-500/60 hover:bg-zinc-900/90 transition-all cursor-pointer group flex flex-col justify-between shadow-sm"
              >
                <div>
                  <div className="flex items-center justify-between mb-3">
                    <div className="w-9 h-9 rounded-xl bg-zinc-950 border border-zinc-800 flex items-center justify-center text-red-500 group-hover:border-red-500/40 transition-colors">
                      <Icon className="w-4 h-4" />
                    </div>
                    <span className="text-[10px] font-mono font-bold text-red-400/80 bg-red-950/30 border border-red-900/40 px-2 py-0.5 rounded-full">
                      Module 0{index + 1}
                    </span>
                  </div>
                  <h3 className="text-sm font-extrabold text-white mb-1.5 group-hover:text-red-400 transition-colors">
                    {topic.title}
                  </h3>
                  <p className="text-xs text-zinc-400 line-clamp-3 leading-relaxed mb-4">
                    {topic.description}
                  </p>
                </div>

                <div className="pt-3 border-t border-zinc-800/80 flex items-center justify-between text-xs font-bold text-red-400">
                  <span>Learn Guidelines</span>
                  <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
                </div>
              </div>
            );
          })}
        </div>

        {/* Quick Dropdown Interactive Bar */}
        <div className="p-6 rounded-2xl bg-zinc-900 border border-zinc-800 flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-3 w-full md:w-auto">
            <Award className="w-5 h-5 text-red-500 shrink-0" />
            <div>
              <div className="text-xs font-extrabold text-white">Select Custom Skills Topic</div>
              <div className="text-[11px] text-zinc-400">Get step-by-step guidance from Tutormaxx</div>
            </div>
          </div>

          <form onSubmit={handleCustomSubmit} className="flex flex-col sm:flex-row items-center gap-3 w-full md:w-auto">
            <select
              value={selectedTopic}
              onChange={(e) => setSelectedTopic(e.target.value)}
              className="w-full sm:w-64 p-2.5 rounded-xl bg-zinc-950 border border-zinc-800 text-xs font-semibold text-white focus:outline-none focus:border-red-500"
            >
              {topicOptions.map((t, idx) => (
                <option key={idx} value={t.title}>
                  {t.title}
                </option>
              ))}
            </select>
            <button
              type="submit"
              className="w-full sm:w-auto px-5 py-2.5 rounded-xl bg-red-600 hover:bg-red-500 text-white text-xs font-bold transition-all shadow-md shadow-red-600/20 cursor-pointer shrink-0 flex items-center justify-center gap-2"
            >
              <span>Ask Basic Skills Tutor</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </form>
        </div>
      </div>
    </section>
  );
};
