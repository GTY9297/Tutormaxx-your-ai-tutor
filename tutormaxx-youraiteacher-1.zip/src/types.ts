export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: string;
  isError?: boolean;
  isFallback?: boolean;
}

export interface ChatSession {
  id: string;
  title: string;
  messages: ChatMessage[];
  createdAt: string;
  updatedAt: string;
}

export interface PresetPrompt {
  id: string;
  title: string;
  prompt: string;
  category: 'Website' | 'Coding' | 'Knowledge' | 'Creative' | 'Comparison';
  icon: string;
}

export interface FeatureItem {
  id: string;
  title: string;
  description: string;
  badge: string;
  icon: string;
}

export interface FAQItem {
  id: string;
  question: string;
  answer: string;
  category: string;
}

