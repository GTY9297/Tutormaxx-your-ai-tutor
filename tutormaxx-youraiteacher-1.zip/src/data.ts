import { FAQItem, FeatureItem, PresetPrompt } from './types';

export const PRESET_PROMPTS: PresetPrompt[] = [
  {
    id: 'p1',
    title: 'Languages: Essay Helper',
    prompt: 'Help me outline a 5-paragraph argumentative essay on the impact of artificial intelligence in education. Include thesis statement, key arguments, and conclusion.',
    category: 'Website', // mapped to Languages in UI
    icon: 'PenTool',
  },
  {
    id: 'p2',
    title: 'Maths: Step-by-Step Solver',
    prompt: 'Solve and explain step-by-step: Solve 3x + 12 = 45 and show the algebraic reasoning.',
    category: 'Coding', // mapped to Maths
    icon: 'Calculator',
  },
  {
    id: 'p3',
    title: 'Science: Photosynthesis Explained',
    prompt: 'Explain the process of photosynthesis in simple terms with key chemical formulas and real-world analogies.',
    category: 'Knowledge', // mapped to Science
    icon: 'Atom',
  },
  {
    id: 'p4',
    title: 'Social: Cause of Industrial Revolution',
    prompt: 'Summarize the primary social and technological causes of the 18th-century Industrial Revolution in 4 bullet points.',
    category: 'Knowledge', // mapped to Social
    icon: 'Globe',
  },
  {
    id: 'p5',
    title: 'GK: World Quizmaster',
    prompt: 'Generate a 5-question multiple choice trivia quiz about world capitals, inventions, and space exploration with answers hidden at the bottom.',
    category: 'Knowledge', // mapped to GK
    icon: 'BrainCircuit',
  },
  {
    id: 'p6',
    title: 'CS: Python Loops Tutor',
    prompt: 'Explain for loops and while loops in Python with runnable code snippets and common pitfall warnings.',
    category: 'Coding', // mapped to CS
    icon: 'Code2',
  },
  {
    id: 'p7',
    title: 'Basic Skills: Good Classroom Manners',
    prompt: 'What are the top 7 essential classroom manners, active listening habits, and respect rules every student should practice?',
    category: 'Creative', // mapped to Basic Skills
    icon: 'Sparkles',
  },
];

export const FEATURES: FeatureItem[] = [
  {
    id: 'f1',
    title: 'Subject-Specific Tutor Workstations',
    description: 'Dedicated interactive tabs for Languages, Maths, Science, Social Studies, General Knowledge, Computer Science, and Essential Basic Skills.',
    badge: 'Multi-Subject',
    icon: 'BookOpen',
  },
  {
    id: 'f2',
    title: 'Basic Skills & Etiquette Guide',
    description: 'Interactive guidance on rules, manners, active study habits, time management, and student life skills.',
    badge: 'Life Skills',
    icon: 'Award',
  },
  {
    id: 'f3',
    title: 'Step-by-Step Problem Breakdown',
    description: 'Detailed step-by-step explanations for mathematical equations, physics formulas, and logic problems.',
    badge: 'Step-By-Step',
    icon: 'BrainCircuit',
  },
  {
    id: 'f4',
    title: 'Voice Input & Text-to-Speech',
    description: 'Dictate your questions via microphone or listen to Tutormaxx explain complex concepts out loud.',
    badge: 'Audio Learning',
    icon: 'Zap',
  },
  {
    id: 'f5',
    title: 'Practice Quiz & Schema Generator',
    description: 'Instantly generate custom study flashcards, multiple-choice practice quizzes, and essay outlines.',
    badge: 'Quiz Engine',
    icon: 'Database',
  },
  {
    id: 'f6',
    title: 'Secure Express API Proxy',
    description: 'Gemini 3.6 Flash engine running strictly server-side for ultra-fast, safe, and private student interactions.',
    badge: 'Server Proxy',
    icon: 'ShieldCheck',
  },
];

export const FAQS: FAQItem[] = [
  {
    id: 'faq-0',
    category: 'Overview',
    question: 'What is Tutormaxx and how does it help students?',
    answer: 'Tutormaxx is a comprehensive AI tutoring platform that provides specialized assistance across 7 core domains: Languages, Mathematics, Science, Social Studies, General Knowledge, Computer Science, and Basic Life Skills.',
  },
  {
    id: 'faq-1',
    category: 'Life Skills',
    question: 'How does the Basic Skills tab work?',
    answer: 'The Basic Skills module teaches students key behavioral rules, classroom etiquette, respectful manners, time management techniques, exam prep strategies, and active listening habits necessary for academic success.',
  },
  {
    id: 'faq-2',
    category: 'Maths',
    question: 'Can Tutormaxx solve math problems step by step?',
    answer: 'Yes! In the Mathematics workstation, Tutormaxx breaks down algebraic equations, geometry proofs, and arithmetic word problems into clear step-by-step explanations rather than just giving raw answers.',
  },
  {
    id: 'faq-3',
    category: 'General',
    question: 'Is Tutormaxx free to use for students?',
    answer: 'Yes, Tutormaxx runs directly in your web browser powered by a secure server-side proxy so students can ask unlimited questions with zero client API key configuration.',
  },
  {
    id: 'faq-4',
    category: 'Features',
    question: 'Can I listen to explanations out loud?',
    answer: 'Yes! Every response includes a "Listen" audio button using Text-to-Speech, plus microphone voice input so students can talk directly to Tutormaxx.',
  },
];

