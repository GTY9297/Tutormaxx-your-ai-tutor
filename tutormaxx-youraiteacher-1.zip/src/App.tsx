import React, { useState, useEffect } from 'react';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { FAQ } from './components/FAQ';
import { FloatingChatWidget } from './components/FloatingChatWidget';
import { ChatHistorySidebar } from './components/ChatHistorySidebar';
import { CentralPromptWorkstation } from './components/CentralPromptWorkstation';
import { BasicSkillsSection } from './components/BasicSkillsSection';
import { ExamActiveRecallStudio } from './components/ExamActiveRecallStudio';
import { ChatSession, ChatMessage } from './types';

const LOCAL_STORAGE_KEY = 'aura_ai_chat_sessions_v1';

export default function App() {
  const [chatOpen, setChatOpen] = useState(false);
  const [mobileHistoryOpen, setMobileHistoryOpen] = useState(false);
  const [pendingPrompt, setPendingPrompt] = useState<string | null>(null);

  // Load chat sessions from localStorage or initialize with default session
  const [sessions, setSessions] = useState<ChatSession[]>(() => {
    try {
      const saved = localStorage.getItem(LOCAL_STORAGE_KEY);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) {
          return parsed;
        }
      }
    } catch (e) {
      console.error('Failed to parse chat sessions from storage:', e);
    }

    const defaultSession: ChatSession = {
      id: 'session-1',
      title: 'Platform Introduction',
      messages: [
        {
          id: 'welcome-msg',
          role: 'assistant',
          content:
            'Hello! I am **Aura AI**, your embedded website assistant. Type any prompt in the central workstation below, select a reasoning mode, or pick a preset topic to test real-time Gemini AI inference.',
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        },
      ],
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    return [defaultSession];
  });

  const [activeSessionId, setActiveSessionId] = useState<string>(() => sessions[0]?.id || 'session-1');
  const [isLoading, setIsLoading] = useState(false);

  // Save sessions to localStorage
  useEffect(() => {
    try {
      localStorage.setItem(LOCAL_STORAGE_KEY, JSON.stringify(sessions));
    } catch (e) {
      console.error('Failed to save sessions:', e);
    }
  }, [sessions]);

  // Active session object
  const activeSession = sessions.find((s) => s.id === activeSessionId) || sessions[0];

  // Create new session
  const handleNewSession = () => {
    const newSession: ChatSession = {
      id: `session-${Date.now()}`,
      title: 'New Chat Thread',
      messages: [
        {
          id: `msg-${Date.now()}`,
          role: 'assistant',
          content: 'New chat thread created. What question or task would you like to process?',
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        },
      ],
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    setSessions((prev) => [newSession, ...prev]);
    setActiveSessionId(newSession.id);
  };

  // Delete specific session
  const handleDeleteSession = (id: string) => {
    setSessions((prev) => {
      const filtered = prev.filter((s) => s.id !== id);
      if (filtered.length === 0) {
        const fresh: ChatSession = {
          id: `session-${Date.now()}`,
          title: 'New Chat Thread',
          messages: [
            {
              id: `msg-${Date.now()}`,
              role: 'assistant',
              content: 'Ready for your next request. How can I help you?',
              timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
            },
          ],
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString(),
        };
        setActiveSessionId(fresh.id);
        return [fresh];
      }
      if (activeSessionId === id) {
        setActiveSessionId(filtered[0].id);
      }
      return filtered;
    });
  };

  // Clear all history
  const handleClearAllHistory = () => {
    const fresh: ChatSession = {
      id: `session-${Date.now()}`,
      title: 'Fresh Chat Thread',
      messages: [
        {
          id: `msg-${Date.now()}`,
          role: 'assistant',
          content: 'Chat history cleared. How can I assist you today?',
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        },
      ],
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    setSessions([fresh]);
    setActiveSessionId(fresh.id);
  };

  // Send message to Gemini backend for active session
  const handleSendMessage = async (
    promptText: string,
    mode: string = 'General',
    temperature: number = 0.7,
    customInstruction?: string
  ) => {
    if (!promptText.trim() || isLoading) return;

    const userMsg: ChatMessage = {
      id: `msg-user-${Date.now()}`,
      role: 'user',
      content: promptText.trim(),
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    // Current session messages
    const currentMsgs = activeSession ? activeSession.messages : [];
    const updatedMsgs = [...currentMsgs, userMsg];

    // Auto update title if still default
    let updatedTitle = activeSession?.title || 'Chat Thread';
    if (updatedTitle === 'New Chat Thread' || updatedTitle === 'Platform Introduction' || updatedTitle === 'Fresh Chat Thread') {
      updatedTitle = promptText.trim().slice(0, 24) + (promptText.length > 24 ? '...' : '');
    }

    // Update session state locally with user message
    setSessions((prev) =>
      prev.map((s) => {
        if (s.id === activeSessionId) {
          return {
            ...s,
            title: updatedTitle,
            messages: updatedMsgs,
            updatedAt: new Date().toISOString(),
          };
        }
        return s;
      })
    );

    setIsLoading(true);

    try {
      const historyPayload = updatedMsgs.map((m) => ({
        role: m.role,
        text: m.content,
      }));

      const sysInst = customInstruction
        ? customInstruction
        : `You are Aura AI, an intelligent embedded website assistant and situational workstation. Mode: ${mode}. Temperature: ${temperature}. Be concise, articulate, and highly accurate.`;

      const res = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: promptText,
          history: historyPayload,
          systemInstruction: sysInst,
          temperature,
          mode,
        }),
      });

      const data = await res.json();

      const assistantMsg: ChatMessage = {
        id: `msg-ast-${Date.now()}`,
        role: 'assistant',
        content: data.reply || data.error || 'No response received.',
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        isError: !data.success,
        isFallback: data.isFallback,
      };

      setSessions((prev) =>
        prev.map((s) => {
          if (s.id === activeSessionId) {
            return {
              ...s,
              messages: [...s.messages, assistantMsg],
              updatedAt: new Date().toISOString(),
            };
          }
          return s;
        })
      );
    } catch (err: any) {
      console.error('Chat error:', err);
      const errorMsg: ChatMessage = {
        id: `msg-err-${Date.now()}`,
        role: 'assistant',
        content: '⚠️ Unable to connect to the server-side Gemini API route. Please verify backend status.',
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        isError: true,
      };

      setSessions((prev) =>
        prev.map((s) => {
          if (s.id === activeSessionId) {
            return {
              ...s,
              messages: [...s.messages, errorMsg],
              updatedAt: new Date().toISOString(),
            };
          }
          return s;
        })
      );
    } finally {
      setIsLoading(false);
    }
  };

  const handleOpenChat = (prompt?: string) => {
    if (prompt) {
      handleSendMessage(prompt);
      const workspaceEl = document.getElementById('prompt-workspace');
      if (workspaceEl) {
        workspaceEl.scrollIntoView({ behavior: 'smooth' });
      }
    } else {
      setChatOpen(true);
    }
  };

  return (
    <div className="flex flex-col min-h-screen bg-zinc-950 text-zinc-100 font-sans selection:bg-red-600 selection:text-white">
      {/* Top Header Navigation */}
      <Navbar onOpenChat={handleOpenChat} />

      {/* Main Workspace Layout Grid: Left Sidebar + Central Prompt Theme Canvas */}
      <div className="flex-1 flex min-w-0">
        {/* Left Chat History Sidebar */}
        <ChatHistorySidebar
          sessions={sessions}
          activeSessionId={activeSessionId}
          onSelectSession={(id) => setActiveSessionId(id)}
          onNewSession={handleNewSession}
          onDeleteSession={handleDeleteSession}
          onClearAllHistory={handleClearAllHistory}
          isMobileOpen={mobileHistoryOpen}
          onCloseMobile={() => setMobileHistoryOpen(false)}
        />

        {/* Central Content Area */}
        <div className="flex-1 flex flex-col min-w-0">
          <main className="flex-1">
            {/* Hero Introduction */}
            <Hero onOpenChat={handleOpenChat} />

            {/* Killer Feature: AI Exam & Active Recall Studio */}
            <ExamActiveRecallStudio />

            {/* Central Prompt Workstation (Main Theme) */}
            <CentralPromptWorkstation
              messages={activeSession?.messages || []}
              isLoading={isLoading}
              onSendMessage={handleSendMessage}
              onToggleMobileHistory={() => setMobileHistoryOpen(true)}
              onClearCurrentThread={() => {
                setSessions((prev) =>
                  prev.map((s) => (s.id === activeSessionId ? { ...s, messages: [] } : s))
                );
              }}
              activeSessionTitle={activeSession?.title || 'Active Session'}
            />

            {/* Basic Skills, Manners & Rules Standalone Section */}
            <BasicSkillsSection onOpenChat={handleOpenChat} />

            {/* System FAQ */}
            <FAQ onOpenChat={handleOpenChat} />
          </main>
        </div>
      </div>

      {/* Floating AI Chatbot Widget */}
      <FloatingChatWidget
        isOpen={chatOpen}
        onToggle={() => setChatOpen(!chatOpen)}
        pendingPrompt={pendingPrompt}
        onClearPendingPrompt={() => setPendingPrompt(null)}
      />
    </div>
  );
}
