# Aura AI — Website with Embedded Floating AI Chatbot Assistant

A full-stack web application featuring an interactive landing page layout and an embedded, floating AI chatbot assistant powered by Google Gemini (via `@google/genai` SDK) and Express.

---

## 🌟 Key Features

1. **Interactive Website Landing Page**:
   - Modern, high-contrast dark theme with glowing aura effects.
   - Interactive prompt playground with click-to-send preset queries.
   - Core feature cards, pricing tiers, and expandable FAQ accordions.
   - Direct prompt search bar in the hero section that opens the floating chatbot immediately.

2. **Embedded Floating AI Chatbot Widget**:
   - Collapsible floating action button (FAB) in the bottom-right corner.
   - Resizable & expandable chat window with custom quick-topic chips.
   - Real-time animated typing indicator and auto-scrolling message area.
   - Formatted markdown and code block rendering with response copy button.
   - Unread message badge and clean history reset options.

3. **Secure Full-Stack Architecture**:
   - Node.js / Express backend route (`/api/chat`) proxying requests to Google Gemini server-side.
   - Zero client-side API key exposure for maximum security.
   - Graceful fallback error handling when `GEMINI_API_KEY` is not set or network issues occur.

---

## 🏗️ Architecture & Technology Stack

- **Frontend**: React 19, TypeScript, Tailwind CSS v4, Lucide Icons, Motion.
- **Backend**: Express 4, Node.js (`server.ts`), Vite middleware in development.
- **AI SDK**: `@google/genai` (`gemini-3.6-flash` model).

---

## 🚀 Getting Started

### 1. Installation

Install dependencies:
```bash
npm install
```

### 2. Environment Configuration

Copy `.env.example` to `.env` and set your Gemini API key:
```env
GEMINI_API_KEY="your_actual_gemini_api_key_here"
```

*Note: In Google AI Studio Build environments, `GEMINI_API_KEY` is injected automatically via Secrets settings.*

### 3. Development Server

Start the full-stack Express + Vite development server on port 3000:
```bash
npm run dev
```

The application will run at `http://localhost:3000`.

### 4. Production Build

Build the client static bundle and esbuild-bundled CJS server:
```bash
npm run build
npm start
```

---

## 🔌 API Endpoints

- `GET /api/health`: Health check and API key status confirmation.
- `POST /api/chat`: Receives `{ message: string, history?: Array<{role: string, text: string}> }` and returns `{ reply: string, isFallback: boolean }`.

---

## 📝 License

Apache License 2.0
