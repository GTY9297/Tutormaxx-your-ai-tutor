import express from "express";
import path from "path";
import { GoogleGenAI } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

const app = express();
const PORT = process.env.PORT ? parseInt(process.env.PORT, 10) : 3000;

app.use(express.json({ limit: "10mb" }));

// System instruction for Aura AI Assistant
const AURA_SYSTEM_INSTRUCTION = `You are "Aura AI", a smart, friendly, and context-aware floating AI chatbot assistant embedded directly on the official Aura AI Technologies website.

YOUR IDENTITY & ROLE:
1. Primary Persona: You are the resident AI guide on the Aura AI landing page. You represent Aura AI — a next-generation AI automation and intelligence platform built to help businesses and developers build, automate, and scale with cutting-edge artificial intelligence.
2. Capability: You are fully capable of answering ANY query a user asks — whether it's specific questions about this website, pricing, features, API integrations, technical documentation, or general questions (coding, science, creative writing, history, troubleshooting, math, logic, productivity tips, etc.).
3. Tone: Professional, welcoming, concise, empathetic, and highly clear. Use clean formatting with bullet points, brief bold highlights, and code blocks when helpful.

WEBSITE & PLATFORM KNOWLEDGE BASE:
- Platform Name: Aura AI Automation Engine
- Core Capabilities:
  • Multimodal Agent Processing (Text, Image, Code, Audio analysis)
  • Embedded Floating Assistant Integration (Plug-and-play UI widgets)
  • Real-time Knowledge Base Sync & Web Grounding
  • Custom Enterprise Workflow Orchestration with 99.99% SLA
- Product Tier Pricing:
  • Starter Plan: $29/month — Up to 10k messages, standard response latency, basic analytics.
  • Pro Plan: $79/month — Unlimited messages, custom knowledge base sync, priority Gemini models, team seats.
  • Enterprise Plan: Custom — Dedicated infrastructure, custom SLAs, SOC-2 compliance, 24/7 dedicated support.
- Technology Stack: Powered by server-side Google Gemini 2.5 Flash / 3.6 Flash models with ultra-low latency.
- Contact & Support: support@aura-ai.example.com, or through this embedded live chat widget!

INSTRUCTIONS FOR RESPONDING:
- Direct & Useful: Keep responses structured, easy to read, and directly focused on solving the user's prompt.
- General Knowledge: If the user asks general questions (e.g., "Write a Python script", "Explain relativity", "How do I make sourdough bread?"), answer thoroughly and accurately.
- Website Specifics: If asked about pricing, features, or how to get started with Aura AI, use the knowledge base above.
- Formatting: Use markdown formatting (bolding, lists, code blocks) to make information scannable inside the floating chat widget.`;

// Lazy helper for Gemini AI client
function getGeminiClient(): GoogleGenAI {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey || apiKey === "MY_GEMINI_API_KEY") {
    throw new Error("GEMINI_API_KEY is not configured in environment variables.");
  }
  return new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        "User-Agent": "aistudio-build",
      },
    },
  });
}

// API Routes
app.get("/api/health", (req, res) => {
  const apiKeyPresent = Boolean(process.env.GEMINI_API_KEY && process.env.GEMINI_API_KEY !== "MY_GEMINI_API_KEY");
  res.json({
    status: "ok",
    service: "Aura AI Backend Service",
    apiKeyConfigured: apiKeyPresent,
    timestamp: new Date().toISOString(),
  });
});

app.post("/api/chat", async (req, res) => {
  try {
    const { message, history, temperature, systemInstruction, mode } = req.body;

    if (!message || typeof message !== "string" || !message.trim()) {
      return res.status(400).json({ error: "Message content is required." });
    }

    // Check key availability
    let ai: GoogleGenAI;
    try {
      ai = getGeminiClient();
    } catch (keyErr: any) {
      console.warn("Gemini API key missing or invalid:", keyErr.message);
      return res.status(200).json({
        reply: "⚠️ **Gemini API Key Notice**: The AI assistant endpoint is running, but `GEMINI_API_KEY` is not set or configured yet. Please configure your key in **Settings > Secrets** or `.env` file.\n\n*In the meantime, feel free to explore the interactive features on the website landing page!*",
        isFallback: true,
      });
    }

    // Format chat history into Gemini contents structure
    const contents: Array<{ role: "user" | "model"; parts: Array<{ text: string }> }> = [];

    if (Array.isArray(history)) {
      for (const item of history) {
        if (item.text && (item.role === "user" || item.role === "model" || item.role === "assistant")) {
          const role = item.role === "user" ? "user" : "model";
          contents.push({
            role,
            parts: [{ text: item.text }],
          });
        }
      }
    }

    // Append latest user message
    contents.push({
      role: "user",
      parts: [{ text: message.trim() }],
    });

    const activeTemp = typeof temperature === "number" && temperature >= 0 && temperature <= 1 ? temperature : 0.7;
    const finalSystemInstruction = systemInstruction || AURA_SYSTEM_INSTRUCTION;

    // Call Gemini API server-side using gemini-3.6-flash
    const response = await ai.models.generateContent({
      model: "gemini-3.6-flash",
      contents,
      config: {
        systemInstruction: finalSystemInstruction,
        temperature: activeTemp,
      },
    });

    const replyText = response.text || "I'm sorry, I couldn't generate a response. Please try asking again.";

    return res.json({
      reply: replyText,
      timestamp: new Date().toISOString(),
      isFallback: false,
    });
  } catch (error: any) {
    console.error("Error in /api/chat route:", error);
    return res.status(500).json({
      error: "Failed to generate AI response.",
      details: error.message || "An unexpected error occurred while communicating with Gemini API.",
    });
  }
});

// Dedicated endpoint for Exam / Quiz Generation
app.post("/api/exam/generate", async (req, res) => {
  try {
    const { topic, difficulty = "Medium", count = 5 } = req.body;
    if (!topic || typeof topic !== "string") {
      return res.status(400).json({ error: "Topic is required" });
    }

    let ai: GoogleGenAI;
    try {
      ai = getGeminiClient();
    } catch (e: any) {
      return res.status(200).json({
        isFallback: true,
        examTitle: `${topic} Practice Test`,
        timeLimitMinutes: 10,
        questions: [
          {
            id: "q1",
            question: `What is the primary significance of ${topic}?`,
            options: [
              "Option A: Core foundational principle in this study field",
              "Option B: Secondary observational effect",
              "Option C: Unrelated historical milestone",
              "Option D: Theoretical exception only"
            ],
            correctAnswer: 0,
            hint: "Focus on the definition and fundamental purpose.",
            explanation: "The core foundational principle defines the primary mechanism of this concept."
          },
          {
            id: "q2",
            question: `Which key factor directly influences ${topic}?`,
            options: [
              "Option A: Primary variable input",
              "Option B: Static temperature",
              "Option C: Random noise",
              "Option D: Irrelevant external data"
            ],
            correctAnswer: 0,
            hint: "Think about the primary input variable.",
            explanation: "The primary variable input directly alters the equilibrium of the system."
          }
        ]
      });
    }

    const sysPrompt = `You are an expert academic exam creator. Create a high-quality practice test for the topic "${topic}" (Difficulty: ${difficulty}).
Return ONLY raw, valid JSON with this exact schema (no markdown backticks, no extra text):
{
  "examTitle": "${topic} Exam Practice",
  "timeLimitMinutes": 10,
  "questions": [
    {
      "id": "q1",
      "question": "Clear, challenging question statement",
      "options": ["Option A", "Option B", "Option C", "Option D"],
      "correctAnswer": 0,
      "hint": "Socratic clue that guides the student without revealing the exact option",
      "explanation": "Detailed explanation of why Option A is correct and why others are wrong"
    }
  ]
}`;

    const response = await ai.models.generateContent({
      model: "gemini-3.6-flash",
      contents: [{ role: "user", parts: [{ text: `Generate ${count} exam questions for: ${topic}` }] }],
      config: {
        systemInstruction: sysPrompt,
        temperature: 0.3,
      },
    });

    const rawText = response.text || "";
    const cleanJson = rawText.replace(/```json/g, "").replace(/```/g, "").trim();
    const data = JSON.parse(cleanJson);
    return res.json(data);
  } catch (err: any) {
    console.error("Error generating exam:", err);
    return res.status(500).json({ error: "Failed to generate exam questions." });
  }
});

// Dedicated endpoint for Active Recall Flashcards Generation
app.post("/api/flashcards/generate", async (req, res) => {
  try {
    const { topic, count = 6 } = req.body;
    if (!topic || typeof topic !== "string") {
      return res.status(400).json({ error: "Topic is required" });
    }

    let ai: GoogleGenAI;
    try {
      ai = getGeminiClient();
    } catch (e: any) {
      return res.status(200).json({
        topic,
        flashcards: [
          {
            id: "fc-1",
            front: `What is the core definition of ${topic}?`,
            back: `${topic} refers to the foundational subject concept examined in academic curricula.`,
            hint: "Think about the primary definition.",
            category: "Core Concept"
          },
          {
            id: "fc-2",
            front: `Why is ${topic} essential for exams?`,
            back: "It forms the prerequisite logic for solving advanced applied problems.",
            hint: "Focus on application.",
            category: "Exam Scope"
          }
        ]
      });
    }

    const sysPrompt = `You are a cognitive memory & active recall specialist. Generate ${count} study flashcards for "${topic}".
Return ONLY raw, valid JSON with this exact schema (no markdown backticks):
{
  "topic": "${topic}",
  "flashcards": [
    {
      "id": "fc-1",
      "front": "Clear question, key term, or concept challenge",
      "back": "Concise, precise explanation or definition to memorize",
      "hint": "A subtle memory prompt or trick",
      "category": "Key Concept / Formula / Definition"
    }
  ]
}`;

    const response = await ai.models.generateContent({
      model: "gemini-3.6-flash",
      contents: [{ role: "user", parts: [{ text: `Create flashcards for topic: ${topic}` }] }],
      config: {
        systemInstruction: sysPrompt,
        temperature: 0.4,
      },
    });

    const rawText = response.text || "";
    const cleanJson = rawText.replace(/```json/g, "").replace(/```/g, "").trim();
    const data = JSON.parse(cleanJson);
    return res.json(data);
  } catch (err: any) {
    console.error("Error generating flashcards:", err);
    return res.status(500).json({ error: "Failed to generate flashcards." });
  }
});

// Dedicated endpoint for Essay & Homework Rubric Evaluation
app.post("/api/essay/evaluate", async (req, res) => {
  try {
    const { content, promptType = "Essay" } = req.body;
    if (!content || typeof content !== "string") {
      return res.status(400).json({ error: "Content is required" });
    }

    let ai: GoogleGenAI;
    try {
      ai = getGeminiClient();
    } catch (e: any) {
      return res.status(200).json({
        predictedGrade: "B+",
        overallScore: 88,
        summary: "Solid academic effort with clear argument structure and good vocabulary.",
        rubric: [
          { criteria: "Structure & Thesis", score: 85, feedback: "Clear thesis statement and good paragraph transitions." },
          { criteria: "Argumentation & Evidence", score: 90, feedback: "Strong supporting points provided throughout." },
          { criteria: "Grammar & Academic Tone", score: 88, feedback: "Formal tone maintained with minor stylistic fixes." }
        ],
        strengths: ["Clear logical flow and engaging opening", "Effective use of topic sentences"],
        areasToImprove: ["Provide more specific citations and textual evidence", "Strengthen concluding call-to-action"],
        actionableRewrite: "Consider refining your conclusion: 'In summary, synthesizing these empirical findings underscores the critical necessity for policy reform.'"
      });
    }

    const sysPrompt = `You are a strict academic reviewer and professor. Evaluate the student's submission below based on standard academic rubrics.
Return ONLY raw, valid JSON matching this exact structure:
{
  "predictedGrade": "A / B+ / B / C / D",
  "overallScore": 88,
  "summary": "1-2 sentence overall professor critique",
  "rubric": [
    { "criteria": "Structure & Clarity", "score": 90, "feedback": "Detailed observation" },
    { "criteria": "Depth of Knowledge", "score": 85, "feedback": "Detailed observation" },
    { "criteria": "Grammar & Academic Tone", "score": 92, "feedback": "Detailed observation" }
  ],
  "strengths": ["Strength 1", "Strength 2"],
  "areasToImprove": ["Improvement 1", "Improvement 2"],
  "actionableRewrite": "Improved / polished version of key excerpts to elevate the grade"
}`;

    const response = await ai.models.generateContent({
      model: "gemini-3.6-flash",
      contents: [{ role: "user", parts: [{ text: `Evaluate this student text:\n\n${content}` }] }],
      config: {
        systemInstruction: sysPrompt,
        temperature: 0.3,
      },
    });

    const rawText = response.text || "";
    const cleanJson = rawText.replace(/```json/g, "").replace(/```/g, "").trim();
    const data = JSON.parse(cleanJson);
    return res.json(data);
  } catch (err: any) {
    console.error("Error evaluating essay:", err);
    return res.status(500).json({ error: "Failed to evaluate text." });
  }
});

// Start dev server with Vite middleware or static dist
async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const { createServer: createViteServer } = await import("vite");
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`[Aura AI Server] Running on http://0.0.0.0:${PORT}`);
  });
}

// Export Express app for serverless platforms like Vercel
export default app;

startServer();
